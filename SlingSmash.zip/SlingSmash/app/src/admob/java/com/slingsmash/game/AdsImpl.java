package com.slingsmash.game;

import android.app.Activity;

import com.google.android.gms.ads.AdError;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.FullScreenContentCallback;
import com.google.android.gms.ads.LoadAdError;
import com.google.android.gms.ads.MobileAds;
import com.google.android.gms.ads.OnUserEarnedRewardListener;
import com.google.android.gms.ads.initialization.InitializationStatus;
import com.google.android.gms.ads.initialization.OnInitializationCompleteListener;
import com.google.android.gms.ads.rewarded.RewardItem;
import com.google.android.gms.ads.rewarded.RewardedAd;
import com.google.android.gms.ads.rewarded.RewardedAdLoadCallback;

/** Google AdMob rewarded videos. */
final class AdsImpl implements Ads {
    /** Google's official TEST rewarded unit. Replace with your own unit id before publishing. */
    private static final String UNIT = "ca-app-pub-3940256099942544/5224354917";

    private final Activity act;
    private RewardedAd ad;
    private boolean loading;

    private AdsImpl(Activity a) {
        act = a;
        try {
            MobileAds.initialize(a, new OnInitializationCompleteListener() {
                @Override
                public void onInitializationComplete(InitializationStatus status) {
                    load();
                }
            });
        } catch (Throwable ignored) {
        }
    }

    static Ads create(Activity a) {
        try {
            return new AdsImpl(a);
        } catch (Throwable t) {
            return null;
        }
    }

    private void load() {
        if (loading || ad != null) return;
        loading = true;
        try {
            RewardedAd.load(act, UNIT, new AdRequest.Builder().build(), new RewardedAdLoadCallback() {
                @Override
                public void onAdLoaded(RewardedAd r) {
                    ad = r;
                    loading = false;
                }

                @Override
                public void onAdFailedToLoad(LoadAdError e) {
                    ad = null;
                    loading = false;
                }
            });
        } catch (Throwable t) {
            loading = false;
        }
    }

    @Override
    public boolean ready() {
        if (ad == null) load();
        return ad != null;
    }

    @Override
    public void show(final Runnable reward, final Runnable closed) {
        RewardedAd r = ad;
        ad = null;
        if (r == null) {
            load();
            closed.run();
            return;
        }
        r.setFullScreenContentCallback(new FullScreenContentCallback() {
            @Override
            public void onAdDismissedFullScreenContent() {
                load();
                closed.run();
            }

            @Override
            public void onAdFailedToShowFullScreenContent(AdError e) {
                load();
                closed.run();
            }
        });
        r.show(act, new OnUserEarnedRewardListener() {
            @Override
            public void onUserEarnedReward(RewardItem item) {
                reward.run();
            }
        });
    }
}
