package com.slingsmash.game;

/** Rewarded video ads. The implementation lives in the build flavor (admob / offline). */
interface Ads {
    /** True when a video can be shown right now. */
    boolean ready();

    /** Shows a rewarded video. {@code reward} runs if the player watched it, {@code closed} always runs at the end. */
    void show(Runnable reward, Runnable closed);
}
