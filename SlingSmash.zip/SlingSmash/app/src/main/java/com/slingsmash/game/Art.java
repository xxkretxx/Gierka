package com.slingsmash.game;

import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RadialGradient;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.Typeface;

import org.jbox2d.common.Vec2;

/** Everything that is drawn in the game world (metres, y up). */
final class Art {
    final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);
    final Paint stroke = new Paint(Paint.ANTI_ALIAS_FLAG);
    final Paint grad = new Paint(Paint.ANTI_ALIAS_FLAG);
    final Paint text = new Paint(Paint.ANTI_ALIAS_FLAG);
    final RectF r = new RectF();
    final Path path = new Path();
    private final Path tmpPath = new Path();

    // per theme: skyTop, skyBottom, sun, farHill, nearHill, grass, dirtTop, dirtBottom, cloud
    static final int[][] THEMES = {
            {0xFF2F7FD6, 0xFFB5E3F7, 0xFFFFF4C2, 0xFF8EC0B4, 0xFF68A878, 0xFF6CC04A, 0xFF8A5A3B, 0xFF4E321F, 0xF0FFFFFF},
            {0xFF2B2160, 0xFFFF9A6A, 0xFFFFD27A, 0xFF7B4E7F, 0xFF55365F, 0xFF4F8A3C, 0xFF5A3A2E, 0xFF2E1D17, 0xD8FFC4B0},
            {0xFF050922, 0xFF2A3570, 0xFFEFF3FF, 0xFF1F2A52, 0xFF161E3D, 0xFF2D5C3C, 0xFF2B1E19, 0xFF140E0B, 0x6C5A6A9E},
            {0xFF7FAAD6, 0xFFE8F3FB, 0xFFFFFFF0, 0xFFC7DAEA, 0xFFA9C3DA, 0xFFF4F8FC, 0xFFA8BDD0, 0xFF6F879E, 0xE0FFFFFF},
            {0xFF3E95D6, 0xFFF7DCA6, 0xFFFFF0B0, 0xFFE6BE7E, 0xFFD39C58, 0xFFE9C47E, 0xFFC28C4B, 0xFF8A5A2C, 0xC8FFFFFF},
    };

    final Typeface bold = Typeface.create("sans-serif-black", Typeface.NORMAL);

    Art() {
        stroke.setStyle(Paint.Style.STROKE);
        stroke.setStrokeCap(Paint.Cap.ROUND);
        stroke.setStrokeJoin(Paint.Join.ROUND);
        text.setTypeface(bold);
        text.setTextAlign(Paint.Align.CENTER);
    }

    // ================================================================ background (screen space)

    Bitmap makeBackground(int w, int h, int theme, float horizonY, long seed) {
        Bitmap bm = Bitmap.createBitmap(Math.max(1, w), Math.max(1, h), Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(bm);
        int[] t = THEMES[theme];
        java.util.Random rnd = new java.util.Random(seed);
        grad.setShader(new LinearGradient(0, 0, 0, horizonY, t[0], t[1], Shader.TileMode.CLAMP));
        c.drawRect(0, 0, w, h, grad);
        grad.setShader(null);

        if (theme == Defs.T_NIGHT) {
            for (int i = 0; i < 140; i++) {
                float x = rnd.nextFloat() * w, y = rnd.nextFloat() * horizonY * 0.85f;
                fill.setColor(Defs.withAlpha(0xFFFFFFFF, 60 + rnd.nextInt(190)));
                c.drawCircle(x, y, 0.6f + rnd.nextFloat() * 1.8f * h / 1000f, fill);
            }
        }
        // sun / moon
        float sx, sy, sr;
        if (theme == Defs.T_SUNSET) { sx = w * 0.62f; sy = horizonY * 0.78f; sr = h * 0.11f; }
        else if (theme == Defs.T_NIGHT) { sx = w * 0.8f; sy = h * 0.17f; sr = h * 0.06f; }
        else { sx = w * 0.8f; sy = h * 0.16f; sr = h * 0.07f; }
        grad.setShader(new RadialGradient(sx, sy, sr * 4.5f, Defs.withAlpha(t[2], 140), Defs.withAlpha(t[2], 0), Shader.TileMode.CLAMP));
        c.drawCircle(sx, sy, sr * 4.5f, grad);
        grad.setShader(null);
        fill.setColor(t[2]);
        c.drawCircle(sx, sy, sr, fill);
        if (theme == Defs.T_NIGHT) {
            fill.setColor(0x22000000);
            c.drawCircle(sx - sr * 0.3f, sy - sr * 0.2f, sr * 0.22f, fill);
            c.drawCircle(sx + sr * 0.35f, sy + sr * 0.3f, sr * 0.15f, fill);
        }

        // far mountains / dunes
        hills(c, w, horizonY, h * 0.30f, h * 0.10f, t[3], rnd, theme == Defs.T_DESERT ? 3 : 5, theme != Defs.T_DESERT);
        if (theme == Defs.T_WINTER) snowCaps(c, w, horizonY, h);
        // city / trees silhouette
        if (theme == Defs.T_NIGHT || theme == Defs.T_SUNSET) city(c, w, horizonY, h, t[4], rnd, theme == Defs.T_NIGHT);
        hills(c, w, horizonY, h * 0.13f, h * 0.05f, t[4], rnd, 7, false);
        if (theme == Defs.T_DAY || theme == Defs.T_WINTER) trees(c, w, horizonY, h, Defs.shade(t[4], 0.8f), rnd);
        // haze at horizon
        grad.setShader(new LinearGradient(0, horizonY - h * 0.12f, 0, horizonY, Defs.withAlpha(t[1], 0), Defs.withAlpha(t[1], 90), Shader.TileMode.CLAMP));
        c.drawRect(0, horizonY - h * 0.12f, w, horizonY, grad);
        grad.setShader(null);
        return bm;
    }

    private void hills(Canvas c, int w, float base, float amp, float minH, int color, java.util.Random rnd, int bumps, boolean peaks) {
        path.reset();
        path.moveTo(0, base + 2);
        int n = 48;
        float[] ph = {rnd.nextFloat() * 6, rnd.nextFloat() * 6, rnd.nextFloat() * 6};
        for (int i = 0; i <= n; i++) {
            float x = w * i / (float) n;
            float u = i / (float) n;
            double v = Math.sin(u * bumps + ph[0]) * 0.5 + Math.sin(u * bumps * 2.3 + ph[1]) * 0.3 + Math.sin(u * bumps * 5.1 + ph[2]) * (peaks ? 0.2 : 0.05);
            float y = base - minH - (float) ((v + 1) / 2) * amp;
            path.lineTo(x, y);
        }
        path.lineTo(w, base + 2);
        path.close();
        fill.setColor(color);
        c.drawPath(path, fill);
    }

    private void snowCaps(Canvas c, int w, float base, int h) {
        grad.setShader(new LinearGradient(0, base - h * 0.42f, 0, base - h * 0.22f, 0xEEFFFFFF, 0x00FFFFFF, Shader.TileMode.CLAMP));
        c.drawPath(path, grad);
        grad.setShader(null);
    }

    private void city(Canvas c, int w, float base, int h, int color, java.util.Random rnd, boolean lights) {
        float x = -10;
        while (x < w) {
            float bw = h * (0.05f + rnd.nextFloat() * 0.07f);
            float bh = h * (0.08f + rnd.nextFloat() * 0.22f);
            fill.setColor(Defs.shade(color, 1.08f));
            c.drawRect(x, base - bh, x + bw, base, fill);
            if (rnd.nextFloat() < 0.25f) c.drawRect(x + bw * 0.45f, base - bh - h * 0.03f, x + bw * 0.55f, base - bh, fill);
            if (lights) {
                float ws = h * 0.008f;
                for (float yy = base - bh + ws * 2; yy < base - ws * 2; yy += ws * 3) {
                    for (float xx = x + ws * 1.5f; xx < x + bw - ws * 1.5f; xx += ws * 2.6f) {
                        if (rnd.nextFloat() < 0.35f) {
                            fill.setColor(rnd.nextFloat() < 0.7f ? 0xCCFFD877 : 0xAA9FD8FF);
                            c.drawRect(xx, yy, xx + ws, yy + ws * 1.3f, fill);
                        }
                    }
                }
            }
            x += bw + h * 0.004f;
        }
    }

    private void trees(Canvas c, int w, float base, int h, int color, java.util.Random rnd) {
        fill.setColor(color);
        float x = 0;
        while (x < w) {
            float s = h * (0.025f + rnd.nextFloat() * 0.035f);
            if (rnd.nextFloat() < 0.5f) {
                c.drawCircle(x, base - s * 1.3f, s, fill);
                c.drawRect(x - s * 0.12f, base - s * 0.5f, x + s * 0.12f, base, fill);
            } else {
                path.reset();
                path.moveTo(x - s * 0.8f, base);
                path.lineTo(x, base - s * 3f);
                path.lineTo(x + s * 0.8f, base);
                path.close();
                c.drawPath(path, fill);
            }
            x += s * (1.2f + rnd.nextFloat() * 3f);
        }
    }

    void drawClouds(Canvas c, int w, int h, int theme, float time) {
        int col = THEMES[theme][8];
        fill.setColor(col);
        for (int i = 0; i < 6; i++) {
            float speed = 6 + i * 3.5f;
            float span = w + h * 0.8f;
            float x = ((i * 0.37f * span + time * speed * h / 1000f) % span) - h * 0.4f;
            float y = h * (0.08f + (i % 3) * 0.09f + (i * 0.013f));
            float s = h * (0.035f + (i % 3) * 0.012f);
            c.drawCircle(x, y, s, fill);
            c.drawCircle(x + s * 1.1f, y - s * 0.45f, s * 1.25f, fill);
            c.drawCircle(x + s * 2.3f, y, s * 0.95f, fill);
            r.set(x - s * 0.2f, y - s * 0.2f, x + s * 2.9f, y + s * 0.85f);
            c.drawRoundRect(r, s * 0.5f, s * 0.5f, fill);
        }
    }

    // ================================================================ world space

    void drawGround(Canvas c, float left, float right, float bottom, int theme) {
        int[] t = THEMES[theme];
        grad.setShader(new LinearGradient(0, -0.3f, 0, bottom, t[6], t[7], Shader.TileMode.CLAMP));
        c.drawRect(left, -0.3f, right, bottom, grad);
        grad.setShader(null);
        // pebbles
        for (int i = 0; i < 60; i++) {
            float x = left + Defs.hash(91, i) * (right - left);
            float y = -0.6f - Defs.hash(92, i) * (-bottom - 0.6f);
            fill.setColor(Defs.withAlpha(Defs.shade(t[6], 0.7f + Defs.hash(93, i) * 0.6f), 160));
            c.drawCircle(x, y, 0.06f + Defs.hash(94, i) * 0.1f, fill);
        }
        fill.setColor(t[5]);
        c.drawRect(left, -0.35f, right, 0.02f, fill);
        fill.setColor(Defs.shade(t[5], 1.25f));
        c.drawRect(left, -0.08f, right, 0.02f, fill);
        fill.setColor(Defs.shade(t[5], 0.78f));
        c.drawRect(left, -0.42f, right, -0.33f, fill);
        // tufts
        int tuft = Defs.shade(t[5], theme == Defs.T_WINTER || theme == Defs.T_DESERT ? 0.92f : 0.85f);
        fill.setColor(tuft);
        for (float x = (float) Math.floor(left); x < right; x += 0.9f) {
            float hh = 0.12f + Defs.hash(7, (int) (x * 10)) * 0.2f;
            path.reset();
            path.moveTo(x - 0.12f, 0);
            path.lineTo(x - 0.05f, hh);
            path.lineTo(x + 0.02f, 0);
            path.lineTo(x + 0.09f, hh * 0.8f);
            path.lineTo(x + 0.16f, 0);
            path.close();
            c.drawPath(path, fill);
        }
    }

    /** Slingshot: back part (drawn before the projectile). */
    void drawSlingBack(Canvas c, float px, float py, boolean night) {
        // base stones
        fill.setColor(0xFF7D7A80);
        r.set(-1.5f, -0.2f, -0.2f, 0.55f);
        c.drawOval(r, fill);
        fill.setColor(0xFF8F8C93);
        r.set(0.1f, -0.2f, 1.4f, 0.48f);
        c.drawOval(r, fill);
        // trunk
        grad.setShader(new LinearGradient(-0.4f, 0, 0.4f, 0, 0xFF6B4423, 0xFFA8733F, Shader.TileMode.CLAMP));
        r.set(-0.4f, 0f, 0.4f, 4.0f);
        c.drawRoundRect(r, 0.15f, 0.15f, grad);
        grad.setShader(null);
        // back arm
        arm(c, -1, 0xFF6E4524);
        // back band
        stroke.setColor(0xFF3A1B12);
        stroke.setStrokeWidth(0.24f);
        c.drawLine(-1.05f, 6.0f, px, py, stroke);
        // pouch
        fill.setColor(0xFF5A2E1C);
        r.set(px - 0.38f, py - 0.32f, px + 0.38f, py + 0.32f);
        c.drawRoundRect(r, 0.2f, 0.2f, fill);
    }

    /** Slingshot: front part (drawn after the projectile). */
    void drawSlingFront(Canvas c, float px, float py) {
        stroke.setColor(0xFF4A2318);
        stroke.setStrokeWidth(0.26f);
        c.drawLine(1.05f, 6.0f, px, py, stroke);
        arm(c, 1, 0xFF9A6634);
        // lashings
        fill.setColor(0xFFE9D3A8);
        for (int s = -1; s <= 1; s += 2) {
            r.set(s * 1.05f - 0.3f, 5.7f, s * 1.05f + 0.3f, 5.88f);
            c.drawRoundRect(r, 0.05f, 0.05f, fill);
            r.set(s * 1.05f - 0.3f, 5.98f, s * 1.05f + 0.3f, 6.16f);
            c.drawRoundRect(r, 0.05f, 0.05f, fill);
        }
        r.set(-0.46f, 2.6f, 0.46f, 2.8f);
        c.drawRoundRect(r, 0.05f, 0.05f, fill);
        r.set(-0.46f, 2.95f, 0.46f, 3.15f);
        c.drawRoundRect(r, 0.05f, 0.05f, fill);
    }

    private void arm(Canvas c, int side, int color) {
        path.reset();
        path.moveTo(0, 3.6f);
        path.cubicTo(side * 0.2f, 4.6f, side * 1.05f, 4.8f, side * 1.05f, 6.3f);
        stroke.setColor(Defs.shade(color, 0.75f));
        stroke.setStrokeWidth(0.62f);
        c.drawPath(path, stroke);
        stroke.setColor(color);
        stroke.setStrokeWidth(0.48f);
        c.drawPath(path, stroke);
        stroke.setColor(Defs.withAlpha(0xFFFFFFFF, 50));
        stroke.setStrokeWidth(0.1f);
        c.save();
        c.translate(-0.08f * side, 0.04f);
        c.drawPath(path, stroke);
        c.restore();
    }

    // ---------------------------------------------------------------- blocks

    void drawBlock(Canvas c, GameWorld.Block b) {
        Vec2 p = b.body.getPosition();
        c.save();
        c.translate(p.x, p.y);
        c.rotate(b.body.getAngle() * 57.29578f);
        float dmg = 1f - b.hp / b.maxHp;
        if (b.verts == null) drawBoxMat(c, b.mat, b.w, b.h, b.seed, dmg, b.flash);
        else drawPolyMat(c, b.mat, b.verts, b.seed, dmg, b.flash);
        c.restore();
    }

    void drawBoxMat(Canvas c, int mat, float w, float h, int seed, float dmg, float flash) {
        float hw = w / 2f, hh = h / 2f;
        int base = Defs.MAT_COLOR[mat];
        float rad = Math.min(0.07f, Math.min(w, h) * 0.2f);
        r.set(-hw, -hh, hw, hh);
        boolean clear = mat == Defs.GLASS || mat == Defs.ICE;
        fill.setColor(clear ? Defs.withAlpha(base, mat == Defs.GLASS ? 150 : 205) : base);
        c.drawRoundRect(r, rad, rad, fill);

        c.save();
        c.clipRect(r);
        boolean horiz = w >= h;
        switch (mat) {
            case Defs.WOOD: {
                stroke.setColor(Defs.withAlpha(Defs.shade(base, 0.62f), 150));
                stroke.setStrokeWidth(0.035f);
                float span = horiz ? h : w;
                int n = Math.max(1, (int) (span / 0.2f));
                for (int i = 0; i < n; i++) {
                    float o = -span / 2 + span * (i + 0.5f) / n + (Defs.hash(seed, i) - 0.5f) * 0.05f;
                    if (horiz) c.drawLine(-hw + 0.05f, o, hw - 0.05f, o, stroke);
                    else c.drawLine(o, -hh + 0.05f, o, hh - 0.05f, stroke);
                }
                fill.setColor(Defs.withAlpha(Defs.shade(base, 0.55f), 170));
                int knots = (int) (w * h * 1.2f) + 1;
                for (int i = 0; i < knots; i++) {
                    float kx = (Defs.hash(seed, 20 + i) - 0.5f) * (w - 0.2f), ky = (Defs.hash(seed, 40 + i) - 0.5f) * (h - 0.2f);
                    r.set(kx - (horiz ? 0.1f : 0.04f), ky - (horiz ? 0.04f : 0.1f), kx + (horiz ? 0.1f : 0.04f), ky + (horiz ? 0.04f : 0.1f));
                    c.drawOval(r, fill);
                }
                break;
            }
            case Defs.BRICK: {
                stroke.setColor(0xB0EBD8C4);
                stroke.setStrokeWidth(0.04f);
                float rowH = 0.27f, bw = 0.55f;
                int j = 0;
                for (float y = -hh; y < hh; y += rowH, j++) {
                    if (y > -hh) c.drawLine(-hw, y, hw, y, stroke);
                    float off = (j % 2) * bw / 2 + Defs.hash(seed, 3) * bw;
                    for (float x = -hw + (off % bw); x < hw; x += bw)
                        if (x > -hw) c.drawLine(x, y, x, Math.min(hh, y + rowH), stroke);
                }
                fill.setColor(0x26000000);
                for (int i = 0; i < 4; i++) {
                    float kx = (Defs.hash(seed, 60 + i) - 0.5f) * w, ky = (Defs.hash(seed, 70 + i) - 0.5f) * h;
                    c.drawRect(kx, ky, kx + 0.25f, ky + 0.12f, fill);
                }
                break;
            }
            case Defs.GLASS: case Defs.ICE: {
                fill.setColor(mat == Defs.GLASS ? 0x70FFFFFF : 0x8CFFFFFF);
                float s = Math.min(w, h);
                path.reset();
                path.moveTo(-hw + s * 0.15f, -hh);
                path.lineTo(-hw + s * 0.45f, -hh);
                path.lineTo(-hw + s * 0.45f + h, hh);
                path.lineTo(-hw + s * 0.15f + h, hh);
                path.close();
                c.drawPath(path, fill);
                fill.setColor(0x40FFFFFF);
                path.reset();
                path.moveTo(-hw + s * 0.6f, -hh);
                path.lineTo(-hw + s * 0.7f, -hh);
                path.lineTo(-hw + s * 0.7f + h, hh);
                path.lineTo(-hw + s * 0.6f + h, hh);
                path.close();
                c.drawPath(path, fill);
                break;
            }
            case Defs.STONE: {
                int n = 3 + (int) (w * h);
                for (int i = 0; i < n && i < 12; i++) {
                    fill.setColor(Defs.withAlpha(Defs.hash(seed, 80 + i) < 0.5f ? 0xFF000000 : 0xFFFFFFFF, 26));
                    float kx = (Defs.hash(seed, 100 + i) - 0.5f) * w, ky = (Defs.hash(seed, 120 + i) - 0.5f) * h;
                    c.drawCircle(kx, ky, 0.08f + Defs.hash(seed, 140 + i) * 0.22f, fill);
                }
                stroke.setColor(0x30000000);
                stroke.setStrokeWidth(0.03f);
                float a = Defs.hash(seed, 9) - 0.5f;
                c.drawLine(-hw * 0.6f, hh * a, hw * 0.3f, hh * (a + 0.4f), stroke);
                break;
            }
            case Defs.CONCRETE: {
                stroke.setColor(0x22000000);
                stroke.setStrokeWidth(0.025f);
                if (horiz) for (float x = -hw + 0.8f; x < hw; x += 0.8f) c.drawLine(x, -hh, x, hh, stroke);
                else for (float y = -hh + 0.8f; y < hh; y += 0.8f) c.drawLine(-hw, y, hw, y, stroke);
                fill.setColor(0x33000000);
                for (int i = 0; i < 8; i++) {
                    c.drawCircle((Defs.hash(seed, 150 + i) - 0.5f) * w, (Defs.hash(seed, 160 + i) - 0.5f) * h, 0.03f, fill);
                }
                break;
            }
            case Defs.STEEL: {
                fill.setColor(0x30FFFFFF);
                if (horiz) c.drawRect(-hw, hh * 0.1f, hw, hh * 0.45f, fill);
                else c.drawRect(-hw * 0.45f, -hh, -hw * 0.1f, hh, fill);
                fill.setColor(0xFF4C5866);
                float rv = Math.min(0.06f, Math.min(w, h) * 0.15f);
                float ix = hw - rv * 2.2f, iy = hh - rv * 2.2f;
                if (ix > 0 && iy > 0) {
                    c.drawCircle(-ix, -iy, rv, fill);
                    c.drawCircle(ix, -iy, rv, fill);
                    c.drawCircle(-ix, iy, rv, fill);
                    c.drawCircle(ix, iy, rv, fill);
                }
                break;
            }
        }
        // bevel
        float bev = Math.min(0.11f, Math.min(w, h) * 0.2f);
        fill.setColor(0x38FFFFFF);
        c.drawRect(-hw, hh - bev, hw, hh, fill);
        fill.setColor(0x2C000000);
        c.drawRect(-hw, -hh, hw, -hh + bev, fill);
        // cracks
        if (dmg > 0.2f) cracks(c, hw, hh, seed, dmg);
        c.restore();

        r.set(-hw, -hh, hw, hh);
        stroke.setColor(clear ? 0xCCFFFFFF : Defs.shade(base, 0.55f));
        stroke.setStrokeWidth(0.05f);
        c.drawRoundRect(r, rad, rad, stroke);
        if (flash > 0) {
            fill.setColor(Defs.withAlpha(0xFFFFFFFF, (int) (flash * 150)));
            c.drawRoundRect(r, rad, rad, fill);
        }
    }

    private void cracks(Canvas c, float hw, float hh, int seed, float dmg) {
        stroke.setColor(0xB0201510);
        stroke.setStrokeWidth(0.035f);
        int n = 1 + (int) (dmg * 4);
        for (int k = 0; k < n; k++) {
            float t = Defs.hash(seed, 200 + k) * 4f;
            float x, y;
            if (t < 1) { x = -hw + t * 2 * hw; y = hh; }
            else if (t < 2) { x = hw; y = hh - (t - 1) * 2 * hh; }
            else if (t < 3) { x = hw - (t - 2) * 2 * hw; y = -hh; }
            else { x = -hw; y = -hh + (t - 3) * 2 * hh; }
            float tx = (Defs.hash(seed, 220 + k) - 0.5f) * hw, ty = (Defs.hash(seed, 230 + k) - 0.5f) * hh;
            tmpPath.reset();
            tmpPath.moveTo(x, y);
            for (int s = 1; s <= 3; s++) {
                float f = s / 3f * Math.min(1f, dmg * 1.3f);
                float jx = (Defs.hash(seed, 240 + k * 5 + s) - 0.5f) * 0.25f, jy = (Defs.hash(seed, 260 + k * 5 + s) - 0.5f) * 0.25f;
                tmpPath.lineTo(x + (tx - x) * f + jx, y + (ty - y) * f + jy);
            }
            c.drawPath(tmpPath, stroke);
        }
    }

    void drawPolyMat(Canvas c, int mat, float[] v, int seed, float dmg, float flash) {
        path.reset();
        path.moveTo(v[0], v[1]);
        for (int i = 2; i < v.length; i += 2) path.lineTo(v[i], v[i + 1]);
        path.close();
        int base = Defs.MAT_COLOR[mat];
        boolean clear = mat == Defs.GLASS || mat == Defs.ICE;
        fill.setColor(clear ? Defs.withAlpha(base, mat == Defs.GLASS ? 150 : 205) : base);
        c.drawPath(path, fill);
        c.save();
        c.clipPath(path);
        float minY = 1e9f, maxY = -1e9f, minX = 1e9f, maxX = -1e9f;
        for (int i = 0; i < v.length; i += 2) {
            minX = Math.min(minX, v[i]); maxX = Math.max(maxX, v[i]);
            minY = Math.min(minY, v[i + 1]); maxY = Math.max(maxY, v[i + 1]);
        }
        if (mat == Defs.BRICK) {
            // roof tiles
            stroke.setColor(Defs.withAlpha(Defs.shade(base, 0.6f), 170));
            stroke.setStrokeWidth(0.05f);
            int j = 0;
            for (float y = minY + 0.3f; y < maxY; y += 0.3f, j++) {
                c.drawLine(minX, y, maxX, y, stroke);
                for (float x = minX + (j % 2) * 0.3f; x < maxX; x += 0.6f) c.drawLine(x, y - 0.3f, x, y, stroke);
            }
        } else if (mat == Defs.WOOD) {
            stroke.setColor(Defs.withAlpha(Defs.shade(base, 0.6f), 150));
            stroke.setStrokeWidth(0.04f);
            for (float y = minY + 0.25f; y < maxY; y += 0.25f) c.drawLine(minX, y, maxX, y, stroke);
        } else if (clear) {
            fill.setColor(0x60FFFFFF);
            c.drawRect(minX + (maxX - minX) * 0.3f, minY, minX + (maxX - minX) * 0.42f, maxY, fill);
        } else {
            fill.setColor(0x22000000);
            for (int i = 0; i < 4; i++)
                c.drawCircle(minX + Defs.hash(seed, i) * (maxX - minX), minY + Defs.hash(seed, i + 9) * (maxY - minY) * 0.5f, 0.15f, fill);
        }
        fill.setColor(0x30000000);
        c.drawRect(minX, minY, maxX, minY + 0.1f, fill);
        if (dmg > 0.2f) cracks(c, (maxX - minX) / 3f, (maxY - minY) / 4f, seed, dmg);
        c.restore();
        stroke.setColor(clear ? 0xCCFFFFFF : Defs.shade(base, 0.55f));
        stroke.setStrokeWidth(0.05f);
        c.drawPath(path, stroke);
        if (flash > 0) {
            fill.setColor(Defs.withAlpha(0xFFFFFFFF, (int) (flash * 150)));
            c.drawPath(path, fill);
        }
    }

    /** Flat preview of a building (for the level cards). */
    void drawSpecFlat(Canvas c, Defs.Spec s) {
        int col = Defs.MAT_COLOR[s.mat];
        boolean clear = s.mat == Defs.GLASS || s.mat == Defs.ICE;
        fill.setColor(clear ? Defs.withAlpha(col, 190) : col);
        stroke.setColor(Defs.shade(col, 0.55f));
        stroke.setStrokeWidth(0.08f);
        if (s.verts == null) {
            r.set(s.x - s.w / 2, s.y - s.h / 2, s.x + s.w / 2, s.y + s.h / 2);
            c.drawRect(r, fill);
            c.drawRect(r, stroke);
        } else {
            path.reset();
            path.moveTo(s.x + s.verts[0], s.y + s.verts[1]);
            for (int i = 2; i < s.verts.length; i += 2) path.lineTo(s.x + s.verts[i], s.y + s.verts[i + 1]);
            path.close();
            c.drawPath(path, fill);
            c.drawPath(path, stroke);
        }
    }

    // ---------------------------------------------------------------- ammo (local coords, centred)

    void drawAmmo(Canvas c, int type) {
        float[] sz = Defs.AMMO_SIZE[type];
        switch (type) {
            case Defs.A_BRICK: {
                drawBoxMat(c, Defs.BRICK, sz[0] * 2, sz[1] * 2, 77, 0, 0);
                fill.setColor(0x55000000);
                r.set(-0.3f, -0.08f, -0.12f, 0.08f); c.drawRoundRect(r, 0.04f, 0.04f, fill);
                r.set(-0.09f, -0.08f, 0.09f, 0.08f); c.drawRoundRect(r, 0.04f, 0.04f, fill);
                r.set(0.12f, -0.08f, 0.3f, 0.08f); c.drawRoundRect(r, 0.04f, 0.04f, fill);
                break;
            }
            case Defs.A_BOWLING: {
                float rr = sz[0];
                grad.setShader(new RadialGradient(-rr * 0.35f, rr * 0.35f, rr * 1.4f, 0xFF4E6BD8, 0xFF141B45, Shader.TileMode.CLAMP));
                c.drawCircle(0, 0, rr, grad);
                grad.setShader(null);
                fill.setColor(0xFF0A0D20);
                c.drawCircle(-0.1f, 0.2f, 0.07f, fill);
                c.drawCircle(0.1f, 0.24f, 0.07f, fill);
                c.drawCircle(0.02f, 0.02f, 0.08f, fill);
                fill.setColor(0x66FFFFFF);
                r.set(-rr * 0.6f, rr * 0.3f, -rr * 0.15f, rr * 0.62f);
                c.drawOval(r, fill);
                break;
            }
            case Defs.A_MELON: {
                float rr = sz[0];
                fill.setColor(0xFF3E9B3A);
                c.drawCircle(0, 0, rr, fill);
                stroke.setColor(0xFF1E5E22);
                stroke.setStrokeWidth(0.1f);
                for (int i = -2; i <= 2; i++) {
                    r.set(-rr * 0.25f + i * rr * 0.32f - rr * 0.15f, -rr, rr * 0.25f + i * rr * 0.32f + rr * 0.15f, rr);
                    c.save();
                    c.clipRect(-rr, -rr, rr, rr);
                    c.drawArc(r, 90, 180, false, stroke);
                    c.restore();
                }
                stroke.setColor(0xFF1C4A1E);
                stroke.setStrokeWidth(0.05f);
                c.drawCircle(0, 0, rr - 0.02f, stroke);
                fill.setColor(0x55FFFFFF);
                r.set(-rr * 0.6f, rr * 0.25f, -rr * 0.1f, rr * 0.6f);
                c.drawOval(r, fill);
                break;
            }
            case Defs.A_ANVIL: {
                path.reset();
                float[] p = {-0.85f, 0.42f, 0.85f, 0.42f, 0.85f, 0.2f, 0.32f, 0.08f, 0.24f, -0.2f, 0.45f, -0.42f,
                        -0.45f, -0.42f, -0.24f, -0.2f, -0.32f, 0.08f, -0.62f, 0.16f, -0.85f, 0.32f};
                path.moveTo(p[0], p[1]);
                for (int i = 2; i < p.length; i += 2) path.lineTo(p[i], p[i + 1]);
                path.close();
                grad.setShader(new LinearGradient(0, 0.42f, 0, -0.42f, 0xFF7A828E, 0xFF2E333B, Shader.TileMode.CLAMP));
                c.drawPath(path, grad);
                grad.setShader(null);
                fill.setColor(0x80FFFFFF);
                c.drawRect(-0.8f, 0.34f, 0.8f, 0.42f, fill);
                stroke.setColor(0xFF1C1F24);
                stroke.setStrokeWidth(0.05f);
                c.drawPath(path, stroke);
                break;
            }
            case Defs.A_CAR: {
                float hw = sz[0];
                fill.setColor(0xFF1A1A1E);
                c.drawCircle(-0.78f, -0.24f, 0.25f, fill);
                c.drawCircle(0.78f, -0.24f, 0.25f, fill);
                fill.setColor(0xFFB8BCC4);
                c.drawCircle(-0.78f, -0.24f, 0.11f, fill);
                c.drawCircle(0.78f, -0.24f, 0.11f, fill);
                path.reset();
                path.moveTo(-0.62f, 0.1f);
                path.lineTo(-0.38f, 0.47f);
                path.lineTo(0.42f, 0.47f);
                path.lineTo(0.72f, 0.1f);
                path.close();
                fill.setColor(0xFFC7262E);
                c.drawPath(path, fill);
                fill.setColor(0xFFAEE3FF);
                path.reset();
                path.moveTo(-0.5f, 0.12f); path.lineTo(-0.33f, 0.4f); path.lineTo(0.0f, 0.4f); path.lineTo(0.0f, 0.12f); path.close();
                c.drawPath(path, fill);
                path.reset();
                path.moveTo(0.08f, 0.12f); path.lineTo(0.08f, 0.4f); path.lineTo(0.38f, 0.4f); path.lineTo(0.6f, 0.12f); path.close();
                c.drawPath(path, fill);
                grad.setShader(new LinearGradient(0, 0.15f, 0, -0.25f, 0xFFE8434B, 0xFF9C1820, Shader.TileMode.CLAMP));
                r.set(-hw, -0.25f, hw, 0.15f);
                c.drawRoundRect(r, 0.14f, 0.14f, grad);
                grad.setShader(null);
                fill.setColor(0xFFFFE680);
                r.set(hw - 0.16f, -0.05f, hw - 0.02f, 0.08f); c.drawRoundRect(r, 0.03f, 0.03f, fill);
                fill.setColor(0xFFFF5050);
                r.set(-hw + 0.02f, -0.05f, -hw + 0.13f, 0.08f); c.drawRoundRect(r, 0.03f, 0.03f, fill);
                fill.setColor(0x55FFFFFF);
                c.drawRect(-hw + 0.15f, 0.07f, hw - 0.2f, 0.12f, fill);
                break;
            }
            case Defs.A_PIANO: {
                float hw = sz[0], hh = sz[1];
                grad.setShader(new LinearGradient(0, hh, 0, -hh, 0xFF3A3A44, 0xFF0E0E12, Shader.TileMode.CLAMP));
                r.set(-hw, -hh + 0.12f, hw, hh);
                c.drawRoundRect(r, 0.08f, 0.08f, grad);
                grad.setShader(null);
                fill.setColor(0xFF0E0E12);
                c.drawRect(-hw + 0.08f, -hh, -hw + 0.2f, -hh + 0.14f, fill);
                c.drawRect(hw - 0.2f, -hh, hw - 0.08f, -hh + 0.14f, fill);
                fill.setColor(0xFFF8F4EA);
                c.drawRect(-hw + 0.06f, -0.08f, hw - 0.06f, 0.1f, fill);
                fill.setColor(0xFF111111);
                for (float x = -hw + 0.15f; x < hw - 0.1f; x += 0.13f) c.drawRect(x, 0.0f, x + 0.06f, 0.1f, fill);
                fill.setColor(0xFFD9B44A);
                c.drawRect(-0.12f, -hh + 0.2f, 0.12f, -hh + 0.26f, fill);
                fill.setColor(0x30FFFFFF);
                c.drawRect(-hw + 0.1f, 0.25f, hw - 0.1f, 0.33f, fill);
                c.drawRect(-hw + 0.1f, hh - 0.14f, hw - 0.1f, hh - 0.08f, fill);
                break;
            }
            case Defs.A_TNT: {
                float hw = sz[0], hh = sz[1];
                grad.setShader(new LinearGradient(-hw, 0, hw, 0, new int[]{0xFF9E1B14, 0xFFE8453A, 0xFF9E1B14}, null, Shader.TileMode.CLAMP));
                r.set(-hw, -hh, hw, hh);
                c.drawRoundRect(r, 0.14f, 0.14f, grad);
                grad.setShader(null);
                fill.setColor(0xFF3B2A22);
                c.drawRect(-hw, hh - 0.18f, hw, hh - 0.08f, fill);
                c.drawRect(-hw, -hh + 0.08f, hw, -hh + 0.18f, fill);
                fill.setColor(0xFFF3E6C8);
                c.drawRect(-hw + 0.06f, -0.17f, hw - 0.06f, 0.17f, fill);
                c.save();
                c.scale(1, -1);
                text.setTextSize(0.26f);
                text.setColor(0xFFB3150E);
                c.drawText("TNT", 0, 0.095f, text);
                c.restore();
                stroke.setColor(0xFF3B2A22);
                stroke.setStrokeWidth(0.05f);
                c.drawLine(0.1f, hh, 0.22f, hh + 0.2f, stroke);
                fill.setColor(0xFFFFC23B);
                c.drawCircle(0.24f, hh + 0.23f, 0.06f, fill);
                break;
            }
            case Defs.A_WRECK: {
                float rr = sz[0];
                stroke.setColor(0xFF5A5F66);
                stroke.setStrokeWidth(0.08f);
                r.set(-0.12f, rr - 0.05f, 0.12f, rr + 0.25f);
                c.drawOval(r, stroke);
                grad.setShader(new RadialGradient(-rr * 0.35f, rr * 0.35f, rr * 1.5f, 0xFF8D949E, 0xFF22262C, Shader.TileMode.CLAMP));
                c.drawCircle(0, 0, rr, grad);
                grad.setShader(null);
                fill.setColor(0x55FFFFFF);
                r.set(-rr * 0.6f, rr * 0.25f, -rr * 0.15f, rr * 0.6f);
                c.drawOval(r, fill);
                fill.setColor(0xFF3A3E45);
                c.drawCircle(0, rr * 0.92f, 0.14f, fill);
                break;
            }
            case Defs.A_FRIDGE: {
                float hw = sz[0], hh = sz[1];
                grad.setShader(new LinearGradient(-hw, 0, hw, 0, 0xFFF4F7FA, 0xFFC7D2DC, Shader.TileMode.CLAMP));
                r.set(-hw, -hh, hw, hh);
                c.drawRoundRect(r, 0.14f, 0.14f, grad);
                grad.setShader(null);
                stroke.setColor(0xFF9AA8B5);
                stroke.setStrokeWidth(0.04f);
                c.drawLine(-hw, 0.3f, hw, 0.3f, stroke);
                c.drawRoundRect(r, 0.14f, 0.14f, stroke);
                fill.setColor(0xFF8592A0);
                c.drawRect(hw - 0.17f, 0.42f, hw - 0.11f, 0.75f, fill);
                c.drawRect(hw - 0.17f, -0.2f, hw - 0.11f, 0.2f, fill);
                fill.setColor(0xFFFF6B6B);
                c.drawCircle(-0.2f, 0.62f, 0.07f, fill);
                fill.setColor(0xFF6BCBFF);
                c.drawRect(-0.32f, -0.1f, -0.16f, 0.05f, fill);
                break;
            }
            case Defs.A_BOULDER: {
                float[] p = Defs.BOULDER_POLY;
                path.reset();
                path.moveTo(p[0], p[1]);
                for (int i = 2; i < p.length; i += 2) path.lineTo(p[i], p[i + 1]);
                path.close();
                grad.setShader(new RadialGradient(-0.25f, 0.3f, 1.1f, 0xFFA9A49C, 0xFF56524D, Shader.TileMode.CLAMP));
                c.drawPath(path, grad);
                grad.setShader(null);
                stroke.setColor(0xFF3F3B37);
                stroke.setStrokeWidth(0.05f);
                c.drawPath(path, stroke);
                stroke.setColor(0x66302C28);
                c.drawLine(-0.3f, 0.1f, 0.1f, -0.2f, stroke);
                c.drawLine(0.2f, 0.4f, 0.4f, 0.1f, stroke);
                fill.setColor(0x447FA35A);
                c.drawCircle(-0.35f, -0.4f, 0.14f, fill);
                break;
            }
        }
    }

    private Paint strokeOf(int color, float w) {
        stroke.setColor(color);
        stroke.setStrokeWidth(w);
        return stroke;
    }

    // ---------------------------------------------------------------- particles

    void drawParticles(Canvas c, java.util.ArrayList<GameWorld.Particle> ps) {
        for (int i = 0, n = ps.size(); i < n; i++) {
            GameWorld.Particle p = ps.get(i);
            float k = p.life / p.max;
            switch (p.kind) {
                case GameWorld.P_CHUNK: {
                    fill.setColor(Defs.withAlpha(p.color, (int) (255 * Math.min(1, k * 2.5f))));
                    c.save();
                    c.translate(p.x, p.y);
                    c.rotate(p.rot);
                    c.drawRect(-p.size, -p.size * 0.7f, p.size, p.size * 0.7f, fill);
                    c.restore();
                    break;
                }
                case GameWorld.P_SHARD: {
                    fill.setColor(Defs.withAlpha(Defs.shade(p.color, 1.3f), (int) (220 * Math.min(1, k * 2.5f))));
                    c.save();
                    c.translate(p.x, p.y);
                    c.rotate(p.rot);
                    tmpPath.reset();
                    tmpPath.moveTo(-p.size, -p.size * 0.5f);
                    tmpPath.lineTo(p.size, -p.size * 0.2f);
                    tmpPath.lineTo(-p.size * 0.2f, p.size);
                    tmpPath.close();
                    c.drawPath(tmpPath, fill);
                    c.restore();
                    break;
                }
                case GameWorld.P_DUST:
                    fill.setColor(Defs.withAlpha(p.color, (int) (120 * k)));
                    c.drawCircle(p.x, p.y, p.size, fill);
                    break;
                case GameWorld.P_SMOKE:
                    fill.setColor(Defs.withAlpha(p.color, (int) (170 * k)));
                    c.drawCircle(p.x, p.y, p.size, fill);
                    break;
                case GameWorld.P_FIRE:
                    fill.setColor(Defs.withAlpha(p.color, (int) (255 * Math.min(1, k * 1.6f))));
                    c.drawCircle(p.x, p.y, p.size * (0.4f + k * 0.6f), fill);
                    break;
                case GameWorld.P_SPARK:
                    stroke.setColor(Defs.withAlpha(p.color, (int) (255 * k)));
                    stroke.setStrokeWidth(0.07f);
                    c.drawLine(p.x, p.y, p.x - p.vx * 0.03f, p.y - p.vy * 0.03f, stroke);
                    break;
                case GameWorld.P_JUICE:
                    fill.setColor(Defs.withAlpha(p.color, (int) (255 * Math.min(1, k * 2f))));
                    c.drawCircle(p.x, p.y, p.size, fill);
                    break;
            }
        }
    }
}
