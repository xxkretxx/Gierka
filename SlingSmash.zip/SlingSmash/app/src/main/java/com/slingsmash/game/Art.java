package com.slingsmash.game;

import android.graphics.Canvas;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RadialGradient;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.Typeface;

import org.jbox2d.common.Vec2;

import java.util.Random;

/** Everything drawn in the game world (metres, y up) plus the parallax backgrounds (pixels). */
final class Art {
    static final float DX = 0.42f, DY = 0.30f; // 2.5D extrusion direction (towards the back)

    final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);
    final Paint stroke = new Paint(Paint.ANTI_ALIAS_FLAG);
    final Paint grad = new Paint(Paint.ANTI_ALIAS_FLAG);
    final Paint text = new Paint(Paint.ANTI_ALIAS_FLAG);
    final RectF r = new RectF();
    final Path path = new Path();
    private final Path tmpPath = new Path();
    private final float[] wv = new float[16];
    final Typeface font;

    // per theme: skyTop, skyBottom, sun, farHill, nearHill, grass, dirtTop, dirtBottom, cloud, city
    static final int[][] THEMES = {
            {0xFF2F7FD6, 0xFFB5E3F7, 0xFFFFF4C2, 0xFF8EC0B4, 0xFF68A878, 0xFF6CC04A, 0xFF8A5A3B, 0xFF4E321F, 0xF0FFFFFF, 0xFF7FAE9C},
            {0xFF2B2160, 0xFFFF9A6A, 0xFFFFD27A, 0xFF7B4E7F, 0xFF55365F, 0xFF4F8A3C, 0xFF5A3A2E, 0xFF2E1D17, 0xD8FFC4B0, 0xFF5E3D68},
            {0xFF050922, 0xFF2A3570, 0xFFEFF3FF, 0xFF1F2A52, 0xFF161E3D, 0xFF2D5C3C, 0xFF2B1E19, 0xFF140E0B, 0x6C5A6A9E, 0xFF1C2448},
            {0xFF7FAAD6, 0xFFE8F3FB, 0xFFFFFFF0, 0xFFC7DAEA, 0xFFA9C3DA, 0xFFF4F8FC, 0xFFA8BDD0, 0xFF6F879E, 0xE0FFFFFF, 0xFFB5CBE0},
            {0xFF3E95D6, 0xFFF7DCA6, 0xFFFFF0B0, 0xFFE6BE7E, 0xFFD39C58, 0xFFE9C47E, 0xFFC28C4B, 0xFF8A5A2C, 0xC8FFFFFF, 0xFFC99A60},
            {0xFF1A0610, 0xFFB8351C, 0xFFFFB13B, 0xFF4A1A1A, 0xFF2E0F12, 0xFF5A2A1E, 0xFF3A1712, 0xFF1A0A08, 0x50FF8A5A, 0xFF3A1416},
    };

    Art(Typeface font) {
        this.font = font;
        stroke.setStyle(Paint.Style.STROKE);
        stroke.setStrokeCap(Paint.Cap.ROUND);
        stroke.setStrokeJoin(Paint.Join.ROUND);
        text.setTypeface(font);
        text.setTextAlign(Paint.Align.CENTER);
    }

    // ================================================================ parallax background (pixels)

    private int bgTheme = -1, bgW, bgH;
    private float bgHorizon;
    private final Path farPath = new Path(), nearPath = new Path(), cityPath = new Path(), treePath = new Path(), lavaPath = new Path();
    private float[] starXY, cityLights;
    private Shader skyShader, sunShader, hazeShader;
    private float sunX, sunY, sunR;
    // ambient particles (screen space)
    private final float[] ax = new float[70], ay = new float[70], av = new float[70], ap = new float[70];
    private boolean ambInit;

    private void buildBackground(int w, int h, int theme, float horizon) {
        bgTheme = theme; bgW = w; bgH = h; bgHorizon = horizon;
        int[] t = THEMES[theme];
        Random rnd = new Random(1234 + theme);
        skyShader = new LinearGradient(0, 0, 0, horizon, t[0], t[1], Shader.TileMode.CLAMP);
        if (theme == Defs.T_SUNSET || theme == Defs.T_LAVA) { sunX = w * 0.62f; sunY = horizon * 0.8f; sunR = h * 0.11f; }
        else if (theme == Defs.T_NIGHT) { sunX = w * 0.8f; sunY = h * 0.17f; sunR = h * 0.06f; }
        else { sunX = w * 0.8f; sunY = h * 0.16f; sunR = h * 0.07f; }
        sunShader = new RadialGradient(sunX, sunY, sunR * 4.5f, Defs.withAlpha(t[2], 150), Defs.withAlpha(t[2], 0), Shader.TileMode.CLAMP);
        hazeShader = new LinearGradient(0, horizon - h * 0.14f, 0, horizon, Defs.withAlpha(t[1], 0), Defs.withAlpha(t[1], 110), Shader.TileMode.CLAMP);
        // stars
        int ns = theme == Defs.T_NIGHT ? 150 : (theme == Defs.T_LAVA ? 70 : 0);
        starXY = new float[ns * 3];
        for (int i = 0; i < ns; i++) {
            starXY[i * 3] = rnd.nextFloat() * w;
            starXY[i * 3 + 1] = rnd.nextFloat() * horizon * 0.8f;
            starXY[i * 3 + 2] = 0.6f + rnd.nextFloat() * 1.8f * h / 1000f;
        }
        float x0 = -w, x1 = 2 * w;
        hillPath(farPath, x0, x1, horizon, h * 0.30f, h * 0.10f, theme == Defs.T_DESERT ? 3 : 5, theme != Defs.T_DESERT, rnd, w);
        hillPath(nearPath, x0, x1, horizon, h * 0.13f, h * 0.04f, 7, false, rnd, w);
        // volcanoes for lava world
        lavaPath.reset();
        if (theme == Defs.T_LAVA) {
            for (int i = 0; i < 4; i++) {
                float cx = x0 + (i + 0.5f) * (x1 - x0) / 4f, bw = h * 0.5f, hh = h * (0.3f + rnd.nextFloat() * 0.12f);
                lavaPath.moveTo(cx - bw, horizon);
                lavaPath.lineTo(cx - bw * 0.12f, horizon - hh);
                lavaPath.lineTo(cx + bw * 0.12f, horizon - hh);
                lavaPath.lineTo(cx + bw, horizon);
                lavaPath.close();
            }
        }
        // city skyline
        cityPath.reset();
        int nl = 0;
        float[] lights = new float[1600];
        if (theme == Defs.T_NIGHT || theme == Defs.T_SUNSET || theme == Defs.T_LAVA) {
            float x = x0;
            while (x < x1) {
                float bw = h * (0.05f + rnd.nextFloat() * 0.07f);
                float bh = h * (0.08f + rnd.nextFloat() * (theme == Defs.T_NIGHT ? 0.3f : 0.2f));
                cityPath.addRect(x, horizon - bh, x + bw, horizon + 2, Path.Direction.CW);
                if (rnd.nextFloat() < 0.25f) cityPath.addRect(x + bw * 0.45f, horizon - bh - h * 0.03f, x + bw * 0.55f, horizon - bh, Path.Direction.CW);
                if (theme == Defs.T_NIGHT) {
                    float ws = h * 0.008f;
                    for (float yy = horizon - bh + ws * 2; yy < horizon - ws * 2; yy += ws * 3)
                        for (float xx = x + ws * 1.5f; xx < x + bw - ws * 1.5f; xx += ws * 2.6f)
                            if (rnd.nextFloat() < 0.3f && nl < 398) {
                                lights[nl * 4] = xx; lights[nl * 4 + 1] = yy; lights[nl * 4 + 2] = ws; lights[nl * 4 + 3] = rnd.nextInt(3);
                                nl++;
                            }
                }
                x += bw + h * 0.004f;
            }
        }
        cityLights = new float[nl * 4];
        System.arraycopy(lights, 0, cityLights, 0, nl * 4);
        // trees
        treePath.reset();
        if (theme == Defs.T_DAY || theme == Defs.T_WINTER || theme == Defs.T_SUNSET) {
            float x = x0;
            while (x < x1) {
                float s = h * (0.025f + rnd.nextFloat() * 0.035f);
                if (theme == Defs.T_DAY && rnd.nextFloat() < 0.5f) {
                    treePath.addCircle(x, horizon - s * 1.3f, s, Path.Direction.CW);
                    treePath.addRect(x - s * 0.12f, horizon - s * 0.5f, x + s * 0.12f, horizon + 2, Path.Direction.CW);
                } else {
                    treePath.moveTo(x - s * 0.8f, horizon + 2);
                    treePath.lineTo(x, horizon - s * 3f);
                    treePath.lineTo(x + s * 0.8f, horizon + 2);
                    treePath.close();
                }
                x += s * (1.2f + rnd.nextFloat() * 3f);
            }
        }
    }

    private void hillPath(Path p, float x0, float x1, float base, float amp, float minH, int bumps, boolean peaks, Random rnd, int w) {
        p.reset();
        p.moveTo(x0, base + 2);
        int n = 120;
        float[] ph = {rnd.nextFloat() * 6, rnd.nextFloat() * 6, rnd.nextFloat() * 6};
        for (int i = 0; i <= n; i++) {
            float x = x0 + (x1 - x0) * i / (float) n;
            float u = x / w;
            double v = Math.sin(u * bumps + ph[0]) * 0.5 + Math.sin(u * bumps * 2.3 + ph[1]) * 0.3 + Math.sin(u * bumps * 5.1 + ph[2]) * (peaks ? 0.2 : 0.05);
            p.lineTo(x, base - minH - (float) ((v + 1) / 2) * amp);
        }
        p.lineTo(x1, base + 2);
        p.close();
    }

    /** camPx: camera offset in pixels relative to the default framing. */
    void drawBackground(Canvas c, int w, int h, int theme, float horizon, float camPx, float time) {
        if (theme != bgTheme || w != bgW || h != bgH || Math.abs(horizon - bgHorizon) > 1) buildBackground(w, h, theme, horizon);
        int[] t = THEMES[theme];
        grad.setShader(skyShader);
        c.drawRect(0, 0, w, h, grad);
        grad.setShader(null);
        for (int i = 0; i < starXY.length; i += 3) {
            float tw = 0.55f + 0.45f * (float) Math.sin(time * 2.5f + i);
            fill.setColor(Defs.withAlpha(0xFFFFFFFF, (int) (200 * tw)));
            c.drawCircle(starXY[i] - camPx * 0.03f, starXY[i + 1], starXY[i + 2], fill);
        }
        grad.setShader(sunShader);
        c.drawCircle(sunX, sunY, sunR * 4.5f, grad);
        grad.setShader(null);
        fill.setColor(t[2]);
        c.drawCircle(sunX, sunY, sunR, fill);
        if (theme == Defs.T_NIGHT) {
            fill.setColor(0x22000000);
            c.drawCircle(sunX - sunR * 0.3f, sunY - sunR * 0.2f, sunR * 0.22f, fill);
            c.drawCircle(sunX + sunR * 0.35f, sunY + sunR * 0.3f, sunR * 0.15f, fill);
        }
        drawClouds(c, w, h, theme, time, camPx * 0.08f);
        // far layer
        c.save();
        c.translate(-camPx * 0.15f, 0);
        if (theme == Defs.T_LAVA) {
            fill.setColor(0xFF2A0E10);
            c.drawPath(lavaPath, fill);
        }
        fill.setColor(t[3]);
        c.drawPath(farPath, fill);
        if (theme == Defs.T_WINTER) {
            grad.setShader(new LinearGradient(0, horizon - h * 0.42f, 0, horizon - h * 0.2f, 0xEEFFFFFF, 0x00FFFFFF, Shader.TileMode.CLAMP));
            c.drawPath(farPath, grad);
            grad.setShader(null);
        }
        c.restore();
        // city
        c.save();
        c.translate(-camPx * 0.3f, 0);
        fill.setColor(t[9]);
        c.drawPath(cityPath, fill);
        for (int i = 0; i < cityLights.length; i += 4) {
            int k = (int) cityLights[i + 3];
            boolean on = Math.sin(time * 0.7f + i * 1.7f) > -0.85f;
            if (!on) continue;
            fill.setColor(k == 0 ? 0xCCFFD877 : (k == 1 ? 0xBB9FD8FF : 0xBBFF7AE0));
            c.drawRect(cityLights[i], cityLights[i + 1], cityLights[i] + cityLights[i + 2], cityLights[i + 1] + cityLights[i + 2] * 1.3f, fill);
        }
        c.restore();
        // near layer
        c.save();
        c.translate(-camPx * 0.5f, 0);
        fill.setColor(t[4]);
        c.drawPath(nearPath, fill);
        fill.setColor(Defs.shade(t[4], theme == Defs.T_WINTER ? 0.85f : 0.8f));
        c.drawPath(treePath, fill);
        c.restore();
        grad.setShader(hazeShader);
        c.drawRect(0, horizon - h * 0.14f, w, horizon, grad);
        grad.setShader(null);
    }

    private void drawClouds(Canvas c, int w, int h, int theme, float time, float off) {
        int col = THEMES[theme][8];
        fill.setColor(col);
        for (int i = 0; i < 6; i++) {
            float speed = 6 + i * 3.5f;
            float span = w + h * 0.8f;
            float x = ((i * 0.37f * span + time * speed * h / 1000f - off) % span + span) % span - h * 0.4f;
            float y = h * (0.08f + (i % 3) * 0.09f + (i * 0.013f));
            float s = h * (0.035f + (i % 3) * 0.012f);
            c.drawCircle(x, y, s, fill);
            c.drawCircle(x + s * 1.1f, y - s * 0.45f, s * 1.25f, fill);
            c.drawCircle(x + s * 2.3f, y, s * 0.95f, fill);
            r.set(x - s * 0.2f, y - s * 0.2f, x + s * 2.9f, y + s * 0.85f);
            c.drawRoundRect(r, s * 0.5f, s * 0.5f, fill);
        }
    }

    /** Ambient life: snow, embers, fireflies, dust motes or birds. Screen space. */
    void drawAmbient(Canvas c, int w, int h, int theme, float dt, float time) {
        if (!ambInit) {
            Random rr = new Random(7);
            for (int i = 0; i < ax.length; i++) {
                ax[i] = rr.nextFloat(); ay[i] = rr.nextFloat(); av[i] = 0.5f + rr.nextFloat(); ap[i] = rr.nextFloat() * 6.28f;
            }
            ambInit = true;
        }
        int n;
        switch (theme) {
            case Defs.T_WINTER: n = 70; break;
            case Defs.T_LAVA: n = 45; break;
            case Defs.T_NIGHT: n = 22; break;
            case Defs.T_DESERT: n = 30; break;
            default: n = 6;
        }
        for (int i = 0; i < n; i++) {
            float x, y;
            switch (theme) {
                case Defs.T_WINTER:
                    ay[i] += dt * 0.06f * av[i];
                    ax[i] += dt * 0.012f * (float) Math.sin(time + ap[i]);
                    x = wrap(ax[i]) * w; y = wrap(ay[i]) * h;
                    fill.setColor(0xDDFFFFFF);
                    c.drawCircle(x, y, (1.5f + av[i] * 2f) * h / 720f, fill);
                    break;
                case Defs.T_LAVA:
                    ay[i] -= dt * 0.05f * av[i];
                    ax[i] += dt * 0.01f * (float) Math.sin(time * 2 + ap[i]);
                    x = wrap(ax[i]) * w; y = wrap(ay[i]) * h;
                    fill.setColor(Defs.withAlpha(i % 2 == 0 ? 0xFFFFB13B : 0xFFFF6A1F, (int) (150 + 100 * Math.sin(time * 6 + ap[i]))));
                    c.drawCircle(x, y, (1.2f + av[i] * 1.6f) * h / 720f, fill);
                    break;
                case Defs.T_NIGHT:
                    ax[i] += dt * 0.01f * (float) Math.sin(time * 0.7f + ap[i]);
                    x = wrap(ax[i]) * w; y = h * (0.55f + 0.3f * wrap(ay[i])) + (float) Math.sin(time + ap[i]) * h * 0.02f;
                    float a = 0.5f + 0.5f * (float) Math.sin(time * 3 + ap[i]);
                    fill.setColor(Defs.withAlpha(0xFFE8FF7A, (int) (200 * a)));
                    c.drawCircle(x, y, 2.4f * h / 720f, fill);
                    break;
                case Defs.T_DESERT:
                    ax[i] += dt * 0.03f * av[i];
                    x = wrap(ax[i]) * w; y = h * (0.35f + 0.5f * wrap(ay[i])) + (float) Math.sin(time * 2 + ap[i]) * h * 0.01f;
                    fill.setColor(0x66FFF0D0);
                    c.drawCircle(x, y, 1.6f * h / 720f, fill);
                    break;
                default: {
                    // a few birds gliding across the sky
                    ax[i] += dt * 0.025f * av[i];
                    x = wrap(ax[i]) * (w + 200) - 100;
                    y = h * (0.08f + 0.25f * ay[i]);
                    float s = (6 + av[i] * 5) * h / 720f;
                    float flap = (float) Math.sin(time * 9 + ap[i]) * s * 0.6f;
                    stroke.setColor(theme == Defs.T_SUNSET ? 0xAA2B1B40 : 0x993A4A5A);
                    stroke.setStrokeWidth(2.2f * h / 720f);
                    path.reset();
                    path.moveTo(x - s, y - flap);
                    path.quadTo(x - s * 0.4f, y - s * 0.3f, x, y);
                    path.quadTo(x + s * 0.4f, y - s * 0.3f, x + s, y - flap);
                    c.drawPath(path, stroke);
                }
            }
        }
    }

    private static float wrap(float v) {
        v = v % 1f;
        return v < 0 ? v + 1 : v;
    }

    // ================================================================ world space

    void drawGround(Canvas c, float left, float right, float bottom, int theme) {
        int[] t = THEMES[theme];
        grad.setShader(new LinearGradient(0, -0.15f, 0, bottom, t[6], t[7], Shader.TileMode.CLAMP));
        c.drawRect(left, -0.15f, right, bottom, grad);
        grad.setShader(null);
        for (int i = 0; i < 70; i++) {
            float x = left + Defs.hash(91, i) * (right - left);
            float y = -0.6f - Defs.hash(92, i) * (-bottom - 0.6f);
            fill.setColor(Defs.withAlpha(Defs.shade(t[6], 0.7f + Defs.hash(93, i) * 0.6f), 160));
            c.drawCircle(x, y, 0.06f + Defs.hash(94, i) * 0.1f, fill);
        }
        // top face (depth band)
        grad.setShader(new LinearGradient(0, 0, 0, DY, Defs.shade(t[5], 1.12f), Defs.shade(t[5], 0.82f), Shader.TileMode.CLAMP));
        c.drawRect(left, 0, right, DY + 0.01f, grad);
        grad.setShader(null);
        // front lip
        fill.setColor(t[5]);
        c.drawRect(left, -0.22f, right, 0.02f, fill);
        fill.setColor(Defs.shade(t[5], 0.75f));
        c.drawRect(left, -0.3f, right, -0.2f, fill);
        if (theme == Defs.T_LAVA) {
            // glowing cracks
            stroke.setColor(0xCCFF6A1F);
            stroke.setStrokeWidth(0.06f);
            for (float x = (float) Math.floor(left); x < right; x += 1.7f) {
                int hx = (int) (x * 10);
                float o = Defs.hash(5, hx) * 1.2f, y0 = -0.45f - Defs.hash(6, hx) * 1.2f;
                float a = (Defs.hash(8, hx) - 0.5f) * 0.9f, b = (Defs.hash(9, hx) - 0.5f) * 0.9f;
                c.drawLine(x + o, y0, x + o + a, y0 - 0.5f, stroke);
                c.drawLine(x + o + a, y0 - 0.5f, x + o + a + b, y0 - 0.9f, stroke);
            }
        }
        int tuft = Defs.shade(t[5], theme == Defs.T_WINTER || theme == Defs.T_DESERT ? 0.92f : 0.85f);
        fill.setColor(tuft);
        for (float x = (float) Math.floor(left); x < right; x += 0.9f) {
            float hh = 0.12f + Defs.hash(7, (int) (x * 10)) * 0.2f;
            path.reset();
            path.moveTo(x - 0.12f, 0);
            path.lineTo(x - 0.05f, hh);
            path.lineTo(x + 0.02f, 0);
            path.lineTo(x + 0.09f, hh * 0.8f);
            path.lineTo(x + 0.16f, 0);
            path.close();
            c.drawPath(path, fill);
        }
    }

    // ---------------------------------------------------------------- slingshot

    void drawSlingBack(Canvas c, float px, float py) {
        fill.setColor(0xFF6D6A70);
        r.set(-1.5f, -0.2f, -0.2f, 0.55f);
        c.drawOval(r, fill);
        fill.setColor(0xFF8F8C93);
        r.set(0.1f, -0.2f, 1.4f, 0.48f);
        c.drawOval(r, fill);
        // trunk with depth
        fill.setColor(0xFF4E3018);
        path.reset();
        path.moveTo(0.4f, 0f);
        path.lineTo(0.4f + DX * 0.6f, DY * 0.6f);
        path.lineTo(0.4f + DX * 0.6f, 4.0f + DY * 0.6f);
        path.lineTo(0.4f, 4.0f);
        path.close();
        c.drawPath(path, fill);
        grad.setShader(new LinearGradient(-0.4f, 0, 0.4f, 0, 0xFF6B4423, 0xFFA8733F, Shader.TileMode.CLAMP));
        r.set(-0.4f, 0f, 0.4f, 4.0f);
        c.drawRoundRect(r, 0.15f, 0.15f, grad);
        grad.setShader(null);
        arm(c, -1, 0xFF6E4524);
        stroke.setColor(0xFF3A1B12);
        stroke.setStrokeWidth(0.24f);
        c.drawLine(-1.05f, 6.0f, px, py, stroke);
        fill.setColor(0xFF5A2E1C);
        r.set(px - 0.38f, py - 0.32f, px + 0.38f, py + 0.32f);
        c.drawRoundRect(r, 0.2f, 0.2f, fill);
    }

    void drawSlingFront(Canvas c, float px, float py) {
        stroke.setColor(0xFF4A2318);
        stroke.setStrokeWidth(0.26f);
        c.drawLine(1.05f, 6.0f, px, py, stroke);
        arm(c, 1, 0xFF9A6634);
        fill.setColor(0xFFE9D3A8);
        for (int s = -1; s <= 1; s += 2) {
            r.set(s * 1.05f - 0.3f, 5.7f, s * 1.05f + 0.3f, 5.88f);
            c.drawRoundRect(r, 0.05f, 0.05f, fill);
            r.set(s * 1.05f - 0.3f, 5.98f, s * 1.05f + 0.3f, 6.16f);
            c.drawRoundRect(r, 0.05f, 0.05f, fill);
        }
        r.set(-0.46f, 2.6f, 0.46f, 2.8f);
        c.drawRoundRect(r, 0.05f, 0.05f, fill);
        r.set(-0.46f, 2.95f, 0.46f, 3.15f);
        c.drawRoundRect(r, 0.05f, 0.05f, fill);
    }

    private void arm(Canvas c, int side, int color) {
        path.reset();
        path.moveTo(0, 3.6f);
        path.cubicTo(side * 0.2f, 4.6f, side * 1.05f, 4.8f, side * 1.05f, 6.3f);
        // depth copy
        c.save();
        c.translate(DX * 0.45f, DY * 0.45f);
        stroke.setColor(Defs.shade(color, 0.5f));
        stroke.setStrokeWidth(0.5f);
        c.drawPath(path, stroke);
        c.restore();
        stroke.setColor(Defs.shade(color, 0.75f));
        stroke.setStrokeWidth(0.62f);
        c.drawPath(path, stroke);
        stroke.setColor(color);
        stroke.setStrokeWidth(0.48f);
        c.drawPath(path, stroke);
        stroke.setColor(Defs.withAlpha(0xFFFFFFFF, 50));
        stroke.setStrokeWidth(0.1f);
        c.save();
        c.translate(-0.08f * side, 0.04f);
        c.drawPath(path, stroke);
        c.restore();
    }

    // ---------------------------------------------------------------- 2.5D extrusion

    /** Writes the body's polygon in world space into wv and returns the vertex count. */
    private int worldPoly(Vec2 pos, float angle, float[] local, float hw, float hh) {
        float cs = (float) Math.cos(angle), sn = (float) Math.sin(angle);
        int n;
        if (local == null) {
            float[] q = {-hw, -hh, hw, -hh, hw, hh, -hw, hh};
            for (int i = 0; i < 4; i++) {
                wv[i * 2] = pos.x + q[i * 2] * cs - q[i * 2 + 1] * sn;
                wv[i * 2 + 1] = pos.y + q[i * 2] * sn + q[i * 2 + 1] * cs;
            }
            n = 4;
        } else {
            n = Math.min(8, local.length / 2);
            for (int i = 0; i < n; i++) {
                wv[i * 2] = pos.x + local[i * 2] * cs - local[i * 2 + 1] * sn;
                wv[i * 2 + 1] = pos.y + local[i * 2] * sn + local[i * 2 + 1] * cs;
            }
        }
        return n;
    }

    private void extrude(Canvas c, int n, int color, int alpha) {
        for (int i = 0; i < n; i++) {
            int j = (i + 1) % n;
            float x0 = wv[i * 2], y0 = wv[i * 2 + 1], x1 = wv[j * 2], y1 = wv[j * 2 + 1];
            float nx = y1 - y0, ny = -(x1 - x0);
            float len = (float) Math.sqrt(nx * nx + ny * ny);
            if (len < 1e-4f) continue;
            nx /= len; ny /= len;
            if (nx * DX + ny * DY <= 0) continue;
            float bright = 0.62f + 0.62f * Math.max(0, ny) + 0.05f * Math.max(0, -nx);
            fill.setColor(Defs.withAlpha(Defs.shade(color, bright), alpha));
            tmpPath.reset();
            tmpPath.moveTo(x0, y0);
            tmpPath.lineTo(x1, y1);
            tmpPath.lineTo(x1 + DX, y1 + DY);
            tmpPath.lineTo(x0 + DX, y0 + DY);
            tmpPath.close();
            c.drawPath(tmpPath, fill);
        }
    }

    void drawBlockDepth(Canvas c, GameWorld.Block b) {
        int n = worldPoly(b.body.getPosition(), b.body.getAngle(), b.verts, b.w / 2, b.h / 2);
        boolean clear = b.mat == Defs.GLASS || b.mat == Defs.ICE;
        extrude(c, n, Defs.MAT_COLOR[b.mat], clear ? 150 : 255);
    }

    void drawShotDepth(Canvas c, GameWorld.Shot s) {
        int t = s.type;
        int shape = Defs.AMMO_SHAPE[t];
        if (shape == Defs.SH_CIRCLE) {
            Vec2 p = s.body.getPosition();
            float rr = Defs.AMMO_SIZE[t][0];
            fill.setColor(0x55000000);
            c.drawCircle(p.x + DX * 0.5f, p.y + DY * 0.5f, rr, fill);
            return;
        }
        float[] local = shape == Defs.SH_POLY ? (t == Defs.A_ANVIL ? Defs.ANVIL_POLY : Defs.BOULDER_POLY) : null;
        float[] sz = Defs.AMMO_SIZE[t];
        int n = worldPoly(s.body.getPosition(), s.body.getAngle(), local, sz[0], shape == Defs.SH_BOX ? sz[1] : 0);
        extrude(c, n, AMMO_DEPTH_COLOR[t], 255);
    }

    static final int[] AMMO_DEPTH_COLOR = {0xFFB5472F, 0xFF2B3C9E, 0xFF3E9B3A, 0xFF4A4F57, 0xFFC7262E, 0xFF1A1A22,
            0xFFC7362B, 0xFF4A4F57, 0xFFD9E1EA, 0xFF7D7871, 0xFF2A2C31, 0xFF2B2B2F, 0xFF3E5A50, 0xFFE8E8E8, 0xFFE0A520,
            0xFF2F3540, 0xFFDADDE5, 0xFF7FD6FF, 0xFF2A0F4A, 0xFF8C3B1E, 0xFF2F3540};

    // ---------------------------------------------------------------- blocks (front faces)

    void drawBlock(Canvas c, GameWorld.Block b) {
        Vec2 p = b.body.getPosition();
        c.save();
        c.translate(p.x, p.y);
        c.rotate(b.body.getAngle() * 57.29578f);
        float dmg = 1f - b.hp / b.maxHp;
        if (b.verts == null) drawBoxMat(c, b.mat, b.w, b.h, b.seed, dmg, b.flash);
        else drawPolyMat(c, b.mat, b.verts, b.seed, dmg, b.flash);
        c.restore();
    }

    void drawBoxMat(Canvas c, int mat, float w, float h, int seed, float dmg, float flash) {
        float hw = w / 2f, hh = h / 2f;
        int base = Defs.MAT_COLOR[mat];
        float rad = Math.min(0.07f, Math.min(w, h) * 0.2f);
        r.set(-hw, -hh, hw, hh);
        boolean clear = mat == Defs.GLASS || mat == Defs.ICE;
        if (mat == Defs.GOLD) {
            grad.setShader(new LinearGradient(0, hh, 0, -hh, 0xFFFFF09A, 0xFFE59A00, Shader.TileMode.CLAMP));
            c.drawRoundRect(r, rad, rad, grad);
            grad.setShader(null);
        } else {
            fill.setColor(clear ? Defs.withAlpha(base, mat == Defs.GLASS ? 150 : 205) : base);
            c.drawRoundRect(r, rad, rad, fill);
        }

        c.save();
        c.clipRect(r);
        boolean horiz = w >= h;
        switch (mat) {
            case Defs.WOOD: {
                stroke.setColor(Defs.withAlpha(Defs.shade(base, 0.62f), 150));
                stroke.setStrokeWidth(0.035f);
                float span = horiz ? h : w;
                int n = Math.max(1, (int) (span / 0.2f));
                for (int i = 0; i < n; i++) {
                    float o = -span / 2 + span * (i + 0.5f) / n + (Defs.hash(seed, i) - 0.5f) * 0.05f;
                    if (horiz) c.drawLine(-hw + 0.05f, o, hw - 0.05f, o, stroke);
                    else c.drawLine(o, -hh + 0.05f, o, hh - 0.05f, stroke);
                }
                fill.setColor(Defs.withAlpha(Defs.shade(base, 0.55f), 170));
                int knots = (int) (w * h * 1.2f) + 1;
                for (int i = 0; i < knots && i < 8; i++) {
                    float kx = (Defs.hash(seed, 20 + i) - 0.5f) * (w - 0.2f), ky = (Defs.hash(seed, 40 + i) - 0.5f) * (h - 0.2f);
                    r.set(kx - (horiz ? 0.1f : 0.04f), ky - (horiz ? 0.04f : 0.1f), kx + (horiz ? 0.1f : 0.04f), ky + (horiz ? 0.04f : 0.1f));
                    c.drawOval(r, fill);
                }
                r.set(-hw, -hh, hw, hh);
                break;
            }
            case Defs.BRICK: {
                stroke.setColor(0xB0EBD8C4);
                stroke.setStrokeWidth(0.04f);
                float rowH = 0.27f, bw = 0.55f;
                int j = 0;
                for (float y = -hh; y < hh; y += rowH, j++) {
                    if (y > -hh) c.drawLine(-hw, y, hw, y, stroke);
                    float off = (j % 2) * bw / 2 + Defs.hash(seed, 3) * bw;
                    for (float x = -hw + (off % bw); x < hw; x += bw)
                        if (x > -hw) c.drawLine(x, y, x, Math.min(hh, y + rowH), stroke);
                }
                break;
            }
            case Defs.GLASS: case Defs.ICE: {
                fill.setColor(mat == Defs.GLASS ? 0x70FFFFFF : 0x8CFFFFFF);
                float s = Math.min(w, h);
                path.reset();
                path.moveTo(-hw + s * 0.15f, -hh);
                path.lineTo(-hw + s * 0.45f, -hh);
                path.lineTo(-hw + s * 0.45f + h, hh);
                path.lineTo(-hw + s * 0.15f + h, hh);
                path.close();
                c.drawPath(path, fill);
                fill.setColor(0x40FFFFFF);
                path.reset();
                path.moveTo(-hw + s * 0.6f, -hh);
                path.lineTo(-hw + s * 0.7f, -hh);
                path.lineTo(-hw + s * 0.7f + h, hh);
                path.lineTo(-hw + s * 0.6f + h, hh);
                path.close();
                c.drawPath(path, fill);
                break;
            }
            case Defs.STONE: {
                int n = 3 + (int) (w * h);
                for (int i = 0; i < n && i < 12; i++) {
                    fill.setColor(Defs.withAlpha(Defs.hash(seed, 80 + i) < 0.5f ? 0xFF000000 : 0xFFFFFFFF, 26));
                    float kx = (Defs.hash(seed, 100 + i) - 0.5f) * w, ky = (Defs.hash(seed, 120 + i) - 0.5f) * h;
                    c.drawCircle(kx, ky, 0.08f + Defs.hash(seed, 140 + i) * 0.22f, fill);
                }
                break;
            }
            case Defs.CONCRETE: {
                stroke.setColor(0x22000000);
                stroke.setStrokeWidth(0.025f);
                if (horiz) for (float x = -hw + 0.8f; x < hw; x += 0.8f) c.drawLine(x, -hh, x, hh, stroke);
                else for (float y = -hh + 0.8f; y < hh; y += 0.8f) c.drawLine(-hw, y, hw, y, stroke);
                break;
            }
            case Defs.STEEL: {
                fill.setColor(0x30FFFFFF);
                if (horiz) c.drawRect(-hw, hh * 0.1f, hw, hh * 0.45f, fill);
                else c.drawRect(-hw * 0.45f, -hh, -hw * 0.1f, hh, fill);
                fill.setColor(0xFF4C5866);
                float rv = Math.min(0.06f, Math.min(w, h) * 0.15f);
                float ix = hw - rv * 2.2f, iy = hh - rv * 2.2f;
                if (ix > 0 && iy > 0) {
                    c.drawCircle(-ix, -iy, rv, fill);
                    c.drawCircle(ix, -iy, rv, fill);
                    c.drawCircle(-ix, iy, rv, fill);
                    c.drawCircle(ix, iy, rv, fill);
                }
                break;
            }
            case Defs.TNT: {
                fill.setColor(0xFF3B2A22);
                c.drawRect(-hw, hh - h * 0.16f, hw, hh - h * 0.06f, fill);
                c.drawRect(-hw, -hh + h * 0.06f, hw, -hh + h * 0.16f, fill);
                fill.setColor(0xFFF3E6C8);
                c.drawRect(-hw + w * 0.1f, -h * 0.17f, hw - w * 0.1f, h * 0.17f, fill);
                c.save();
                c.scale(1, -1);
                text.setTextSize(Math.min(h * 0.3f, w * 0.32f));
                text.setColor(0xFFB3150E);
                c.drawText("TNT", 0, text.getTextSize() * 0.36f, text);
                c.restore();
                break;
            }
            case Defs.GOLD: {
                stroke.setColor(0x99B87400);
                stroke.setStrokeWidth(0.04f);
                r.set(-hw + w * 0.15f, -hh + h * 0.2f, hw - w * 0.15f, hh - h * 0.2f);
                c.drawRect(r, stroke);
                fill.setColor(0xCCFFFFFF);
                float sx = hw * 0.45f, sy = hh * 0.4f, ss = Math.min(w, h) * 0.12f;
                c.drawRect(sx - ss * 0.15f, sy - ss, sx + ss * 0.15f, sy + ss, fill);
                c.drawRect(sx - ss, sy - ss * 0.15f, sx + ss, sy + ss * 0.15f, fill);
                r.set(-hw, -hh, hw, hh);
                break;
            }
        }
        float bev = Math.min(0.11f, Math.min(w, h) * 0.2f);
        fill.setColor(0x38FFFFFF);
        c.drawRect(-hw, hh - bev, hw, hh, fill);
        fill.setColor(0x2C000000);
        c.drawRect(-hw, -hh, hw, -hh + bev, fill);
        if (dmg > 0.2f) cracks(c, hw, hh, seed, dmg);
        c.restore();

        r.set(-hw, -hh, hw, hh);
        stroke.setColor(clear ? 0xCCFFFFFF : Defs.shade(base, 0.55f));
        stroke.setStrokeWidth(0.05f);
        c.drawRoundRect(r, rad, rad, stroke);
        if (flash > 0) {
            fill.setColor(Defs.withAlpha(0xFFFFFFFF, (int) (flash * 150)));
            c.drawRoundRect(r, rad, rad, fill);
        }
    }

    private void cracks(Canvas c, float hw, float hh, int seed, float dmg) {
        stroke.setColor(0xB0201510);
        stroke.setStrokeWidth(0.035f);
        int n = 1 + (int) (dmg * 4);
        for (int k = 0; k < n; k++) {
            float t = Defs.hash(seed, 200 + k) * 4f;
            float x, y;
            if (t < 1) { x = -hw + t * 2 * hw; y = hh; }
            else if (t < 2) { x = hw; y = hh - (t - 1) * 2 * hh; }
            else if (t < 3) { x = hw - (t - 2) * 2 * hw; y = -hh; }
            else { x = -hw; y = -hh + (t - 3) * 2 * hh; }
            float tx = (Defs.hash(seed, 220 + k) - 0.5f) * hw, ty = (Defs.hash(seed, 230 + k) - 0.5f) * hh;
            tmpPath.reset();
            tmpPath.moveTo(x, y);
            for (int s = 1; s <= 3; s++) {
                float f = s / 3f * Math.min(1f, dmg * 1.3f);
                float jx = (Defs.hash(seed, 240 + k * 5 + s) - 0.5f) * 0.25f, jy = (Defs.hash(seed, 260 + k * 5 + s) - 0.5f) * 0.25f;
                tmpPath.lineTo(x + (tx - x) * f + jx, y + (ty - y) * f + jy);
            }
            c.drawPath(tmpPath, stroke);
        }
    }

    void drawPolyMat(Canvas c, int mat, float[] v, int seed, float dmg, float flash) {
        path.reset();
        path.moveTo(v[0], v[1]);
        for (int i = 2; i < v.length; i += 2) path.lineTo(v[i], v[i + 1]);
        path.close();
        int base = Defs.MAT_COLOR[mat];
        boolean clear = mat == Defs.GLASS || mat == Defs.ICE;
        fill.setColor(clear ? Defs.withAlpha(base, mat == Defs.GLASS ? 150 : 205) : base);
        c.drawPath(path, fill);
        c.save();
        c.clipPath(path);
        float minY = 1e9f, maxY = -1e9f, minX = 1e9f, maxX = -1e9f;
        for (int i = 0; i < v.length; i += 2) {
            minX = Math.min(minX, v[i]); maxX = Math.max(maxX, v[i]);
            minY = Math.min(minY, v[i + 1]); maxY = Math.max(maxY, v[i + 1]);
        }
        if (mat == Defs.BRICK) {
            stroke.setColor(Defs.withAlpha(Defs.shade(base, 0.6f), 170));
            stroke.setStrokeWidth(0.05f);
            int j = 0;
            for (float y = minY + 0.3f; y < maxY; y += 0.3f, j++) {
                c.drawLine(minX, y, maxX, y, stroke);
                for (float x = minX + (j % 2) * 0.3f; x < maxX; x += 0.6f) c.drawLine(x, y - 0.3f, x, y, stroke);
            }
        } else if (mat == Defs.WOOD) {
            stroke.setColor(Defs.withAlpha(Defs.shade(base, 0.6f), 150));
            stroke.setStrokeWidth(0.04f);
            for (float y = minY + 0.25f; y < maxY; y += 0.25f) c.drawLine(minX, y, maxX, y, stroke);
        } else if (clear) {
            fill.setColor(0x60FFFFFF);
            c.drawRect(minX + (maxX - minX) * 0.3f, minY, minX + (maxX - minX) * 0.42f, maxY, fill);
        } else if (mat == Defs.GOLD) {
            fill.setColor(0x66FFFFFF);
            c.drawRect(minX + (maxX - minX) * 0.35f, minY, minX + (maxX - minX) * 0.45f, maxY, fill);
        } else {
            fill.setColor(0x22000000);
            for (int i = 0; i < 4; i++)
                c.drawCircle(minX + Defs.hash(seed, i) * (maxX - minX), minY + Defs.hash(seed, i + 9) * (maxY - minY) * 0.5f, 0.15f, fill);
        }
        fill.setColor(0x30000000);
        c.drawRect(minX, minY, maxX, minY + 0.1f, fill);
        if (dmg > 0.2f) cracks(c, (maxX - minX) / 3f, (maxY - minY) / 4f, seed, dmg);
        c.restore();
        stroke.setColor(clear ? 0xCCFFFFFF : Defs.shade(base, 0.55f));
        stroke.setStrokeWidth(0.05f);
        c.drawPath(path, stroke);
        if (flash > 0) {
            fill.setColor(Defs.withAlpha(0xFFFFFFFF, (int) (flash * 150)));
            c.drawPath(path, fill);
        }
    }

    /** Preview of a building with depth (for level cards). Coordinates in metres. */
    void drawSpecPreview(Canvas c, java.util.List<Defs.Spec> specs) {
        Vec2 pos = new Vec2();
        for (Defs.Spec s : specs) {
            pos.set(s.x, s.y);
            int n = worldPoly(pos, 0, s.verts, s.w / 2, s.h / 2);
            boolean clear = s.mat == Defs.GLASS || s.mat == Defs.ICE;
            extrude(c, n, Defs.MAT_COLOR[s.mat], clear ? 170 : 255);
        }
        for (Defs.Spec s : specs) {
            int col = Defs.MAT_COLOR[s.mat];
            boolean clear = s.mat == Defs.GLASS || s.mat == Defs.ICE;
            fill.setColor(clear ? Defs.withAlpha(col, 200) : col);
            stroke.setColor(Defs.shade(col, 0.55f));
            stroke.setStrokeWidth(0.08f);
            if (s.verts == null) {
                r.set(s.x - s.w / 2, s.y - s.h / 2, s.x + s.w / 2, s.y + s.h / 2);
                c.drawRect(r, fill);
                c.drawRect(r, stroke);
            } else {
                path.reset();
                path.moveTo(s.x + s.verts[0], s.y + s.verts[1]);
                for (int i = 2; i < s.verts.length; i += 2) path.lineTo(s.x + s.verts[i], s.y + s.verts[i + 1]);
                path.close();
                c.drawPath(path, fill);
                c.drawPath(path, stroke);
            }
        }
    }

    // ---------------------------------------------------------------- ammo (local coords, centred)

    void drawAmmo(Canvas c, int type) {
        float[] sz = Defs.AMMO_SIZE[type];
        switch (type) {
            case Defs.A_BRICK: {
                drawBoxMat(c, Defs.BRICK, sz[0] * 2, sz[1] * 2, 77, 0, 0);
                fill.setColor(0x55000000);
                r.set(-0.3f, -0.08f, -0.12f, 0.08f); c.drawRoundRect(r, 0.04f, 0.04f, fill);
                r.set(-0.09f, -0.08f, 0.09f, 0.08f); c.drawRoundRect(r, 0.04f, 0.04f, fill);
                r.set(0.12f, -0.08f, 0.3f, 0.08f); c.drawRoundRect(r, 0.04f, 0.04f, fill);
                break;
            }
            case Defs.A_BOWLING: {
                sphere(c, sz[0], 0xFF4E6BD8, 0xFF141B45);
                fill.setColor(0xFF0A0D20);
                c.drawCircle(-0.1f, 0.2f, 0.07f, fill);
                c.drawCircle(0.1f, 0.24f, 0.07f, fill);
                c.drawCircle(0.02f, 0.02f, 0.08f, fill);
                break;
            }
            case Defs.A_MELON: {
                float rr = sz[0];
                fill.setColor(0xFF3E9B3A);
                c.drawCircle(0, 0, rr, fill);
                stroke.setColor(0xFF1E5E22);
                stroke.setStrokeWidth(0.1f);
                c.save();
                c.clipRect(-rr, -rr, rr, rr);
                for (int i = -2; i <= 2; i++) {
                    r.set(-rr * 0.25f + i * rr * 0.32f - rr * 0.15f, -rr, rr * 0.25f + i * rr * 0.32f + rr * 0.15f, rr);
                    c.drawArc(r, 90, 180, false, stroke);
                }
                c.restore();
                stroke.setColor(0xFF1C4A1E);
                stroke.setStrokeWidth(0.05f);
                c.drawCircle(0, 0, rr - 0.02f, stroke);
                highlight(c, rr);
                break;
            }
            case Defs.A_ANVIL: {
                path.reset();
                float[] p = {-0.85f, 0.42f, 0.85f, 0.42f, 0.85f, 0.2f, 0.32f, 0.08f, 0.24f, -0.2f, 0.45f, -0.42f,
                        -0.45f, -0.42f, -0.24f, -0.2f, -0.32f, 0.08f, -0.62f, 0.16f, -0.85f, 0.32f};
                path.moveTo(p[0], p[1]);
                for (int i = 2; i < p.length; i += 2) path.lineTo(p[i], p[i + 1]);
                path.close();
                grad.setShader(new LinearGradient(0, 0.42f, 0, -0.42f, 0xFF7A828E, 0xFF2E333B, Shader.TileMode.CLAMP));
                c.drawPath(path, grad);
                grad.setShader(null);
                fill.setColor(0x80FFFFFF);
                c.drawRect(-0.8f, 0.34f, 0.8f, 0.42f, fill);
                stroke.setColor(0xFF1C1F24);
                stroke.setStrokeWidth(0.05f);
                c.drawPath(path, stroke);
                break;
            }
            case Defs.A_CAR: vehicle(c, sz[0], 0xFFE8434B, 0xFF9C1820, 0xFFC7262E, false); break;
            case Defs.A_BUS: vehicle(c, sz[0], 0xFFFFD54A, 0xFFE0A520, 0xFFFFC93C, true); break;
            case Defs.A_PIANO: {
                float hw = sz[0], hh = sz[1];
                grad.setShader(new LinearGradient(0, hh, 0, -hh, 0xFF3A3A44, 0xFF0E0E12, Shader.TileMode.CLAMP));
                r.set(-hw, -hh + 0.12f, hw, hh);
                c.drawRoundRect(r, 0.08f, 0.08f, grad);
                grad.setShader(null);
                fill.setColor(0xFF0E0E12);
                c.drawRect(-hw + 0.08f, -hh, -hw + 0.2f, -hh + 0.14f, fill);
                c.drawRect(hw - 0.2f, -hh, hw - 0.08f, -hh + 0.14f, fill);
                fill.setColor(0xFFF8F4EA);
                c.drawRect(-hw + 0.06f, -0.08f, hw - 0.06f, 0.1f, fill);
                fill.setColor(0xFF111111);
                for (float x = -hw + 0.15f; x < hw - 0.1f; x += 0.13f) c.drawRect(x, 0.0f, x + 0.06f, 0.1f, fill);
                fill.setColor(0xFFD9B44A);
                c.drawRect(-0.12f, -hh + 0.2f, 0.12f, -hh + 0.26f, fill);
                fill.setColor(0x30FFFFFF);
                c.drawRect(-hw + 0.1f, 0.25f, hw - 0.1f, 0.33f, fill);
                break;
            }
            case Defs.A_TNT: {
                float hw = sz[0], hh = sz[1];
                grad.setShader(new LinearGradient(-hw, 0, hw, 0, new int[]{0xFF9E1B14, 0xFFE8453A, 0xFF9E1B14}, null, Shader.TileMode.CLAMP));
                r.set(-hw, -hh, hw, hh);
                c.drawRoundRect(r, 0.14f, 0.14f, grad);
                grad.setShader(null);
                fill.setColor(0xFF3B2A22);
                c.drawRect(-hw, hh - 0.18f, hw, hh - 0.08f, fill);
                c.drawRect(-hw, -hh + 0.08f, hw, -hh + 0.18f, fill);
                fill.setColor(0xFFF3E6C8);
                c.drawRect(-hw + 0.06f, -0.17f, hw - 0.06f, 0.17f, fill);
                c.save();
                c.scale(1, -1);
                text.setTextSize(0.26f);
                text.setColor(0xFFB3150E);
                c.drawText("TNT", 0, 0.095f, text);
                c.restore();
                stroke.setColor(0xFF3B2A22);
                stroke.setStrokeWidth(0.05f);
                c.drawLine(0.1f, hh, 0.22f, hh + 0.2f, stroke);
                fill.setColor(0xFFFFC23B);
                c.drawCircle(0.24f, hh + 0.23f, 0.06f, fill);
                break;
            }
            case Defs.A_WRECK: {
                float rr = sz[0];
                stroke.setColor(0xFF5A5F66);
                stroke.setStrokeWidth(0.08f);
                r.set(-0.12f, rr - 0.05f, 0.12f, rr + 0.25f);
                c.drawOval(r, stroke);
                sphere(c, rr, 0xFF8D949E, 0xFF22262C);
                fill.setColor(0xFF3A3E45);
                c.drawCircle(0, rr * 0.92f, 0.14f, fill);
                break;
            }
            case Defs.A_FRIDGE: {
                float hw = sz[0], hh = sz[1];
                grad.setShader(new LinearGradient(-hw, 0, hw, 0, 0xFFF4F7FA, 0xFFC7D2DC, Shader.TileMode.CLAMP));
                r.set(-hw, -hh, hw, hh);
                c.drawRoundRect(r, 0.14f, 0.14f, grad);
                grad.setShader(null);
                stroke.setColor(0xFF9AA8B5);
                stroke.setStrokeWidth(0.04f);
                c.drawLine(-hw, 0.3f, hw, 0.3f, stroke);
                c.drawRoundRect(r, 0.14f, 0.14f, stroke);
                fill.setColor(0xFF8592A0);
                c.drawRect(hw - 0.17f, 0.42f, hw - 0.11f, 0.75f, fill);
                c.drawRect(hw - 0.17f, -0.2f, hw - 0.11f, 0.2f, fill);
                fill.setColor(0xFFFF6B6B);
                c.drawCircle(-0.2f, 0.62f, 0.07f, fill);
                fill.setColor(0xFF6BCBFF);
                c.drawRect(-0.32f, -0.1f, -0.16f, 0.05f, fill);
                break;
            }
            case Defs.A_BOULDER: {
                float[] p = Defs.BOULDER_POLY;
                path.reset();
                path.moveTo(p[0], p[1]);
                for (int i = 2; i < p.length; i += 2) path.lineTo(p[i], p[i + 1]);
                path.close();
                grad.setShader(new RadialGradient(-0.25f, 0.3f, 1.1f, 0xFFA9A49C, 0xFF56524D, Shader.TileMode.CLAMP));
                c.drawPath(path, grad);
                grad.setShader(null);
                stroke.setColor(0xFF3F3B37);
                stroke.setStrokeWidth(0.05f);
                c.drawPath(path, stroke);
                stroke.setColor(0x66302C28);
                c.drawLine(-0.3f, 0.1f, 0.1f, -0.2f, stroke);
                c.drawLine(0.2f, 0.4f, 0.4f, 0.1f, stroke);
                break;
            }
            case Defs.A_CANNON: sphere(c, sz[0], 0xFF6A6E78, 0xFF15161A); break;
            case Defs.A_TIRE: {
                float rr = sz[0];
                fill.setColor(0xFF1F1F23);
                c.drawCircle(0, 0, rr, fill);
                stroke.setColor(0xFF3A3A40);
                stroke.setStrokeWidth(0.06f);
                for (int i = 0; i < 12; i++) {
                    double a = i * Math.PI / 6;
                    c.drawLine((float) Math.cos(a) * rr * 0.75f, (float) Math.sin(a) * rr * 0.75f, (float) Math.cos(a) * rr * 0.97f, (float) Math.sin(a) * rr * 0.97f, stroke);
                }
                grad.setShader(new RadialGradient(-0.05f, 0.05f, rr * 0.5f, 0xFFE2E6EC, 0xFF8A9099, Shader.TileMode.CLAMP));
                c.drawCircle(0, 0, rr * 0.42f, grad);
                grad.setShader(null);
                fill.setColor(0xFF2B2B2F);
                for (int i = 0; i < 5; i++) {
                    double a = i * Math.PI * 2 / 5;
                    c.drawCircle((float) Math.cos(a) * rr * 0.22f, (float) Math.sin(a) * rr * 0.22f, 0.035f, fill);
                }
                highlight(c, rr);
                break;
            }
            case Defs.A_SAFE: {
                float hw = sz[0];
                grad.setShader(new LinearGradient(0, hw, 0, -hw, 0xFF5D8274, 0xFF2C4239, Shader.TileMode.CLAMP));
                r.set(-hw, -hw, hw, hw);
                c.drawRoundRect(r, 0.1f, 0.1f, grad);
                grad.setShader(null);
                stroke.setColor(0xFF1C2A24);
                stroke.setStrokeWidth(0.05f);
                c.drawRoundRect(r, 0.1f, 0.1f, stroke);
                r.set(-hw + 0.08f, -hw + 0.08f, hw - 0.08f, hw - 0.08f);
                c.drawRect(r, stroke);
                fill.setColor(0xFFC8B26A);
                c.drawCircle(0, 0, hw * 0.38f, fill);
                stroke.setColor(0xFF6A5420);
                c.drawCircle(0, 0, hw * 0.38f, stroke);
                c.drawLine(0, -hw * 0.3f, 0, hw * 0.3f, stroke);
                c.drawLine(-hw * 0.3f, 0, hw * 0.3f, 0, stroke);
                fill.setColor(0xFFDCE3E8);
                c.drawRect(hw - 0.2f, -0.22f, hw - 0.13f, 0.22f, fill);
                break;
            }
            case Defs.A_COW: {
                fill.setColor(0xFF22123A);
                c.drawRect(-0.75f, -0.55f, -0.6f, -0.2f, fill);
                c.drawRect(-0.15f, -0.55f, 0.0f, -0.2f, fill);
                c.drawRect(0.25f, -0.55f, 0.4f, -0.2f, fill);
                fill.setColor(0xFFFFFFFF);
                r.set(-1.0f, -0.3f, 0.5f, 0.35f);
                c.drawRoundRect(r, 0.25f, 0.25f, fill);
                fill.setColor(0xFF1A1A1E);
                c.drawCircle(-0.55f, 0.1f, 0.15f, fill);
                c.drawCircle(-0.1f, -0.12f, 0.12f, fill);
                c.drawCircle(0.22f, 0.15f, 0.09f, fill);
                fill.setColor(0xFFFFFFFF);
                r.set(0.38f, -0.05f, 1.0f, 0.5f);
                c.drawRoundRect(r, 0.18f, 0.18f, fill);
                fill.setColor(0xFFFFB3C1);
                r.set(0.62f, -0.05f, 1.0f, 0.2f);
                c.drawRoundRect(r, 0.1f, 0.1f, fill);
                fill.setColor(0xFF1A1A1E);
                c.drawCircle(0.58f, 0.33f, 0.05f, fill);
                fill.setColor(0xFFF3E6C8);
                c.drawRect(0.45f, 0.5f, 0.52f, 0.62f, fill);
                c.drawRect(0.86f, 0.5f, 0.93f, 0.62f, fill);
                stroke.setColor(0xFF6E6A6A);
                stroke.setStrokeWidth(0.04f);
                r.set(-1.0f, -0.3f, 0.5f, 0.35f);
                c.drawRoundRect(r, 0.25f, 0.25f, stroke);
                break;
            }
            case Defs.A_CLUSTER: {
                fill.setColor(0xFFFF7A3C);
                c.drawCircle(-0.32f, 0.3f, 0.17f, fill);
                c.drawCircle(0.32f, 0.3f, 0.17f, fill);
                c.drawCircle(0, 0.42f, 0.15f, fill);
                sphere(c, sz[0] * 0.85f, 0xFF5A6270, 0xFF1C2028);
                stroke.setColor(0xFF3B2A22);
                stroke.setStrokeWidth(0.05f);
                c.drawLine(0.25f, 0.33f, 0.4f, 0.55f, stroke);
                fill.setColor(0xFFFFC23B);
                c.drawCircle(0.42f, 0.58f, 0.07f, fill);
                break;
            }
            case Defs.A_MINI: {
                sphere(c, sz[0], 0xFF5A6270, 0xFF1C2028);
                fill.setColor(0xFFFF7A3C);
                c.drawRect(-sz[0], -0.04f, sz[0], 0.04f, fill);
                break;
            }
            case Defs.A_ROCKET: {
                float hw = sz[0], hh = sz[1];
                fill.setColor(0xFFF2443A);
                path.reset();
                path.moveTo(-hw, -hh);
                path.lineTo(-hw - 0.15f, -hh - 0.22f);
                path.lineTo(-hw + 0.35f, -hh);
                path.close();
                path.moveTo(-hw, hh);
                path.lineTo(-hw - 0.15f, hh + 0.22f);
                path.lineTo(-hw + 0.35f, hh);
                path.close();
                c.drawPath(path, fill);
                grad.setShader(new LinearGradient(0, hh, 0, -hh, 0xFFFFFFFF, 0xFFB8BEC8, Shader.TileMode.CLAMP));
                r.set(-hw, -hh, hw - 0.3f, hh);
                c.drawRoundRect(r, 0.08f, 0.08f, grad);
                grad.setShader(null);
                fill.setColor(0xFFF2443A);
                path.reset();
                path.moveTo(hw - 0.32f, -hh);
                path.quadTo(hw, -hh * 0.4f, hw + 0.02f, 0);
                path.quadTo(hw, hh * 0.4f, hw - 0.32f, hh);
                path.close();
                c.drawPath(path, fill);
                fill.setColor(0xFF5BC8FF);
                c.drawCircle(0.15f, 0, 0.1f, fill);
                stroke.setColor(0xFF22123A);
                stroke.setStrokeWidth(0.03f);
                c.drawCircle(0.15f, 0, 0.1f, stroke);
                fill.setColor(0xFF3B3F48);
                c.drawRect(-hw - 0.05f, -hh * 0.7f, -hw + 0.02f, hh * 0.7f, fill);
                break;
            }
            case Defs.A_FREEZE: {
                float rr = sz[0];
                sphere(c, rr, 0xFFCFF4FF, 0xFF3FA6E0);
                stroke.setColor(0xFFFFFFFF);
                stroke.setStrokeWidth(0.07f);
                for (int i = 0; i < 3; i++) {
                    double a = i * Math.PI / 3;
                    float dx = (float) Math.cos(a) * rr * 0.6f, dy = (float) Math.sin(a) * rr * 0.6f;
                    c.drawLine(-dx, -dy, dx, dy, stroke);
                }
                break;
            }
            case Defs.A_HOLE: {
                float rr = sz[0];
                grad.setShader(new RadialGradient(0, 0, rr * 2.2f, 0x99B07CFF, 0x00B07CFF, Shader.TileMode.CLAMP));
                c.drawCircle(0, 0, rr * 2.2f, grad);
                grad.setShader(null);
                stroke.setColor(0xFFC49BFF);
                stroke.setStrokeWidth(0.09f);
                r.set(-rr * 1.7f, -rr * 0.55f, rr * 1.7f, rr * 0.55f);
                c.drawArc(r, 180, 180, false, stroke);
                fill.setColor(0xFF120624);
                c.drawCircle(0, 0, rr, fill);
                fill.setColor(0xFF000000);
                c.drawCircle(0, 0, rr * 0.5f, fill);
                stroke.setColor(0xFFFF7AE0);
                c.drawArc(r, 0, 180, false, stroke);
                break;
            }
            case Defs.A_METEOR: {
                float rr = sz[0];
                grad.setShader(new RadialGradient(0, 0, rr * 1.8f, 0x88FF8A1F, 0x00FF8A1F, Shader.TileMode.CLAMP));
                c.drawCircle(0, 0, rr * 1.8f, grad);
                grad.setShader(null);
                sphere(c, rr, 0xFFB5552E, 0xFF4A1A0E);
                stroke.setColor(0xFFFF8A1F);
                stroke.setStrokeWidth(0.07f);
                c.drawLine(-0.3f, 0.2f, 0.05f, -0.05f, stroke);
                c.drawLine(0.05f, -0.05f, 0.3f, 0.1f, stroke);
                c.drawLine(0.05f, -0.05f, 0.0f, -0.4f, stroke);
                fill.setColor(0xFFFF6A1F);
                c.drawCircle(-0.25f, -0.25f, 0.1f, fill);
                c.drawCircle(0.3f, 0.35f, 0.08f, fill);
                break;
            }
        }
    }

    private void sphere(Canvas c, float rr, int light, int dark) {
        grad.setShader(new RadialGradient(-rr * 0.35f, rr * 0.35f, rr * 1.5f, light, dark, Shader.TileMode.CLAMP));
        c.drawCircle(0, 0, rr, grad);
        grad.setShader(null);
        highlight(c, rr);
    }

    private void highlight(Canvas c, float rr) {
        fill.setColor(0x55FFFFFF);
        r.set(-rr * 0.6f, rr * 0.25f, -rr * 0.15f, rr * 0.6f);
        c.drawOval(r, fill);
    }

    private void vehicle(Canvas c, float hw, int top, int bottom, int roof, boolean bus) {
        float wheelX = hw * 0.62f;
        fill.setColor(0xFF1A1A1E);
        c.drawCircle(-wheelX, -0.24f, 0.25f, fill);
        c.drawCircle(wheelX, -0.24f, 0.25f, fill);
        fill.setColor(0xFFB8BCC4);
        c.drawCircle(-wheelX, -0.24f, 0.11f, fill);
        c.drawCircle(wheelX, -0.24f, 0.11f, fill);
        if (bus) {
            grad.setShader(new LinearGradient(0, 0.75f, 0, -0.25f, top, bottom, Shader.TileMode.CLAMP));
            r.set(-hw, -0.25f, hw, 0.75f);
            c.drawRoundRect(r, 0.2f, 0.2f, grad);
            grad.setShader(null);
            fill.setColor(0xFFAEE3FF);
            for (float x = -hw + 0.25f; x < hw - 0.6f; x += 0.62f) c.drawRect(x, 0.25f, x + 0.48f, 0.6f, fill);
            c.drawRect(hw - 0.4f, 0.0f, hw - 0.08f, 0.62f, fill);
            fill.setColor(0xFF22123A);
            c.drawRect(-hw, 0.05f, hw, 0.12f, fill);
        } else {
            path.reset();
            path.moveTo(-0.62f, 0.1f);
            path.lineTo(-0.38f, 0.47f);
            path.lineTo(0.42f, 0.47f);
            path.lineTo(0.72f, 0.1f);
            path.close();
            fill.setColor(roof);
            c.drawPath(path, fill);
            fill.setColor(0xFFAEE3FF);
            path.reset();
            path.moveTo(-0.5f, 0.12f); path.lineTo(-0.33f, 0.4f); path.lineTo(0.0f, 0.4f); path.lineTo(0.0f, 0.12f); path.close();
            c.drawPath(path, fill);
            path.reset();
            path.moveTo(0.08f, 0.12f); path.lineTo(0.08f, 0.4f); path.lineTo(0.38f, 0.4f); path.lineTo(0.6f, 0.12f); path.close();
            c.drawPath(path, fill);
            grad.setShader(new LinearGradient(0, 0.15f, 0, -0.25f, top, bottom, Shader.TileMode.CLAMP));
            r.set(-hw, -0.25f, hw, 0.15f);
            c.drawRoundRect(r, 0.14f, 0.14f, grad);
            grad.setShader(null);
        }
        fill.setColor(0xFFFFE680);
        r.set(hw - 0.16f, -0.05f, hw - 0.02f, 0.08f);
        c.drawRoundRect(r, 0.03f, 0.03f, fill);
        fill.setColor(0xFFFF5050);
        r.set(-hw + 0.02f, -0.05f, -hw + 0.13f, 0.08f);
        c.drawRoundRect(r, 0.03f, 0.03f, fill);
    }

    // ---------------------------------------------------------------- particles

    void drawParticles(Canvas c, java.util.ArrayList<GameWorld.Particle> ps) {
        for (int i = 0, n = ps.size(); i < n; i++) {
            GameWorld.Particle p = ps.get(i);
            float k = p.life / p.max;
            switch (p.kind) {
                case GameWorld.P_CHUNK: {
                    fill.setColor(Defs.withAlpha(p.color, (int) (255 * Math.min(1, k * 2.5f))));
                    c.save();
                    c.translate(p.x, p.y);
                    c.rotate(p.rot);
                    c.drawRect(-p.size, -p.size * 0.7f, p.size, p.size * 0.7f, fill);
                    fill.setColor(Defs.withAlpha(Defs.shade(p.color, 0.6f), (int) (255 * Math.min(1, k * 2.5f))));
                    c.drawRect(-p.size, -p.size * 0.7f, p.size, -p.size * 0.35f, fill);
                    c.restore();
                    break;
                }
                case GameWorld.P_SHARD: case GameWorld.P_SNOW: {
                    fill.setColor(Defs.withAlpha(Defs.shade(p.color, 1.3f), (int) (220 * Math.min(1, k * 2.5f))));
                    c.save();
                    c.translate(p.x, p.y);
                    c.rotate(p.rot);
                    tmpPath.reset();
                    tmpPath.moveTo(-p.size, -p.size * 0.5f);
                    tmpPath.lineTo(p.size, -p.size * 0.2f);
                    tmpPath.lineTo(-p.size * 0.2f, p.size);
                    tmpPath.close();
                    c.drawPath(tmpPath, fill);
                    c.restore();
                    break;
                }
                case GameWorld.P_DUST:
                    fill.setColor(Defs.withAlpha(p.color, (int) (120 * k)));
                    c.drawCircle(p.x, p.y, p.size, fill);
                    break;
                case GameWorld.P_SMOKE:
                    fill.setColor(Defs.withAlpha(p.color, (int) (170 * k)));
                    c.drawCircle(p.x, p.y, p.size, fill);
                    break;
                case GameWorld.P_FIRE:
                    fill.setColor(Defs.withAlpha(p.color, (int) (255 * Math.min(1, k * 1.6f))));
                    c.drawCircle(p.x, p.y, p.size * (0.4f + k * 0.6f), fill);
                    break;
                case GameWorld.P_SPARK:
                    stroke.setColor(Defs.withAlpha(p.color, (int) (255 * k)));
                    stroke.setStrokeWidth(0.07f);
                    c.drawLine(p.x, p.y, p.x - p.vx * 0.03f, p.y - p.vy * 0.03f, stroke);
                    break;
                case GameWorld.P_JUICE:
                    fill.setColor(Defs.withAlpha(p.color, (int) (255 * Math.min(1, k * 2f))));
                    c.drawCircle(p.x, p.y, p.size, fill);
                    break;
                case GameWorld.P_TRAIL:
                    fill.setColor(Defs.withAlpha(p.color, (int) (170 * k)));
                    c.drawCircle(p.x, p.y, p.size * (0.5f + 0.5f * k), fill);
                    break;
                case GameWorld.P_GLOW:
                    fill.setColor(Defs.withAlpha(p.color, (int) (200 * k)));
                    c.drawCircle(p.x, p.y, p.size, fill);
                    break;
                case GameWorld.P_RING:
                    stroke.setColor(Defs.withAlpha(p.color, (int) (230 * k)));
                    stroke.setStrokeWidth(0.25f * k + 0.04f);
                    c.drawCircle(p.x, p.y, p.size, stroke);
                    break;
            }
        }
    }

    void drawVortex(Canvas c, float x, float y, float t, float time) {
        float a = Math.min(1f, t * 2f);
        grad.setShader(new RadialGradient(x, y, 4.5f, Defs.withAlpha(0xFF8A4DFF, (int) (150 * a)), 0x008A4DFF, Shader.TileMode.CLAMP));
        c.drawCircle(x, y, 4.5f, grad);
        grad.setShader(null);
        for (int i = 0; i < 3; i++) {
            stroke.setColor(Defs.withAlpha(i == 1 ? 0xFFFF7AE0 : 0xFFC49BFF, (int) (220 * a)));
            stroke.setStrokeWidth(0.12f);
            r.set(x - 2.6f + i * 0.5f, y - 0.9f + i * 0.15f, x + 2.6f - i * 0.5f, y + 0.9f - i * 0.15f);
            c.save();
            c.rotate(time * (200 + i * 70), x, y);
            c.drawArc(r, 0, 250, false, stroke);
            c.restore();
        }
        fill.setColor(0xFF000000);
        c.drawCircle(x, y, 0.75f * a, fill);
        stroke.setColor(Defs.withAlpha(0xFFFFFFFF, (int) (180 * a)));
        stroke.setStrokeWidth(0.05f);
        c.drawCircle(x, y, 0.8f * a, stroke);
    }
}
