package com.slingsmash.game;

import java.util.ArrayList;

/** Simple stacking editor: blocks drop onto whatever is below them. */
final class Builder {
    static final int[] MATS = {Defs.WOOD, Defs.GLASS, Defs.BRICK, Defs.STONE, Defs.CONCRETE, Defs.STEEL, Defs.ICE,
            Defs.TNT, Defs.GOLD, Defs.RUBBER, Defs.CRYSTAL};
    /** w, h, isTriangle */
    static final float[][] SHAPES = {{1f, 1f, 0}, {2f, 0.5f, 0}, {0.5f, 2f, 0}, {3f, 0.4f, 0}, {2f, 1f, 0}, {0.5f, 1f, 0}, {2.4f, 1.2f, 1}};
    static final float MIN_X = 22f, MAX_X = 42f, MAX_Y = 14f;

    /** {mat, shape, left x, bottom y} */
    final ArrayList<float[]> items = new ArrayList<>();
    int max = 80;

    float[] ghost(int mat, int shape, float cx) {
        float w = SHAPES[shape][0], h = SHAPES[shape][1];
        float x = Math.round((cx - w / 2) * 4) / 4f;
        x = Math.max(MIN_X, Math.min(MAX_X - w, x));
        float y = 0;
        boolean blocked = false;
        for (float[] it : items) {
            float iw = SHAPES[(int) it[1]][0], ih = SHAPES[(int) it[1]][1];
            if (it[2] < x + w - 0.01f && it[2] + iw > x + 0.01f && it[3] + ih > y) {
                y = it[3] + ih;
                blocked = SHAPES[(int) it[1]][2] > 0;
            } else if (it[2] < x + w - 0.01f && it[2] + iw > x + 0.01f && SHAPES[(int) it[1]][2] > 0 && it[3] + ih >= y - 0.01f) {
                blocked = true;
            }
        }
        // the top item under the new block must not be a triangle
        blocked = false;
        float topY = -1;
        for (float[] it : items) {
            float iw = SHAPES[(int) it[1]][0], ih = SHAPES[(int) it[1]][1];
            if (it[2] < x + w - 0.01f && it[2] + iw > x + 0.01f && Math.abs(it[3] + ih - y) < 0.01f) {
                if (SHAPES[(int) it[1]][2] > 0) blocked = true;
                topY = y;
            }
        }
        boolean ok = !blocked && y + h <= MAX_Y && items.size() < max;
        return new float[]{x, y, w, h, ok ? 1 : 0, topY};
    }

    boolean place(int mat, int shape, float cx) {
        float[] g = ghost(mat, shape, cx);
        if (g[4] < 1) return false;
        items.add(new float[]{mat, shape, g[0], g[1]});
        return true;
    }

    /** Removes the topmost item at a point, plus everything resting above it. */
    boolean erase(float px, float py) {
        for (int i = items.size() - 1; i >= 0; i--) {
            float[] it = items.get(i);
            float w = SHAPES[(int) it[1]][0], h = SHAPES[(int) it[1]][1];
            if (px >= it[2] - 0.1f && px <= it[2] + w + 0.1f && py >= it[3] - 0.1f && py <= it[3] + h + 0.1f) {
                items.remove(i);
                settle();
                return true;
            }
        }
        return false;
    }

    void undo() {
        if (!items.isEmpty()) items.remove(items.size() - 1);
    }

    /** Re-drops every block in order so nothing floats after an erase. */
    private void settle() {
        ArrayList<float[]> old = new ArrayList<>(items);
        items.clear();
        for (float[] it : old) {
            float w = SHAPES[(int) it[1]][0];
            float[] g = ghost((int) it[0], (int) it[1], it[2] + w / 2);
            items.add(new float[]{it[0], it[1], g[0], g[1]});
        }
    }

    Defs.LevelDef toLevel(String name, int theme, int shots) {
        Defs.B b = new Defs.B();
        for (float[] it : items) {
            float w = SHAPES[(int) it[1]][0], h = SHAPES[(int) it[1]][1];
            if (SHAPES[(int) it[1]][2] > 0) b.tri(it[2], it[3], w, h, (int) it[0]);
            else b.box(it[2], it[3], w, h, (int) it[0]);
        }
        Defs.LevelDef d = new Defs.LevelDef(name, theme, shots, b.s);
        d.star2 = 0.75f;
        return d;
    }

    String encode() {
        StringBuilder sb = new StringBuilder();
        for (float[] it : items) {
            if (sb.length() > 0) sb.append(';');
            sb.append((int) it[0]).append(',').append((int) it[1]).append(',').append(it[2]).append(',').append(it[3]);
        }
        return sb.toString();
    }

    void decode(String s) {
        items.clear();
        if (s == null || s.isEmpty()) return;
        for (String part : s.split(";")) {
            String[] f = part.split(",");
            if (f.length != 4) continue;
            try {
                items.add(new float[]{Integer.parseInt(f[0]), Integer.parseInt(f[1]), Float.parseFloat(f[2]), Float.parseFloat(f[3])});
            } catch (NumberFormatException ignored) {
            }
        }
    }

    /** A ready-made house so the editor never starts completely empty. */
    void starter() {
        items.clear();
        place(Defs.WOOD, 2, 27.25f);
        place(Defs.WOOD, 2, 31.25f);
        place(Defs.GLASS, 4, 29.25f);
        place(Defs.WOOD, 3, 29.5f);
        place(Defs.BRICK, 0, 28.5f);
        place(Defs.BRICK, 0, 30.5f);
        place(Defs.WOOD, 3, 29.5f);
        place(Defs.BRICK, 6, 29.5f);
    }
}
