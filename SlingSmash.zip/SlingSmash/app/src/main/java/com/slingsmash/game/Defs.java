package com.slingsmash.game;

import java.util.ArrayList;

/** Static game data: materials, ammo, sounds, worlds, objectives and all buildings. Pure Java (no Android). */
final class Defs {
    private Defs() {}

    // ---------------------------------------------------------------- materials
    static final int WOOD = 0, GLASS = 1, BRICK = 2, STONE = 3, CONCRETE = 4, STEEL = 5, ICE = 6, TNT = 7, GOLD = 8,
            RUBBER = 9, MAGNET = 10, CRYSTAL = 11, ARMOR = 12, CORE = 13, CROWN = 14, SHIELD = 15;
    static final int NUM_MATS = 16;
    static final String[] MAT_NAME = {"Wood", "Glass", "Brick", "Stone", "Concrete", "Steel", "Ice", "TNT", "Gold",
            "Rubber", "Magnet", "Crystal", "Armor", "Core", "Crown", "Shield"};
    static final int[] MAT_COLOR = {0xFFCB8A4E, 0xFF8FD3F0, 0xFFC4553D, 0xFFA3A1AC, 0xFFC9C3B5, 0xFF6F7E8E, 0xFFBFEAFF, 0xFFE0402F, 0xFFFFC93C,
            0xFFFF5DA2, 0xFFD63A3A, 0xFFB07CFF, 0xFF4A5260, 0xFF3FE0FF, 0xFFFFD23F, 0xFF5BC8FF};
    static final float[] MAT_DENSITY = {0.7f, 1.0f, 1.8f, 2.4f, 2.1f, 3.4f, 0.9f, 0.8f, 3.0f, 1.2f, 3.5f, 1.4f, 4.0f, 1.5f, 2.0f, 1.0f};
    static final float[] MAT_HP = {100f, 28f, 190f, 330f, 270f, 620f, 50f, 35f, 150f, 900f, 500f, 60f, 600f, 240f, 1e9f, 1e9f};
    static final float[] MAT_FRICTION = {0.75f, 0.35f, 0.8f, 0.85f, 0.8f, 0.55f, 0.12f, 0.7f, 0.6f, 0.95f, 0.6f, 0.3f, 0.6f, 0.4f, 0.6f, 0.4f};
    static final float[] MAT_RESTITUTION = {0.03f, 0.03f, 0.03f, 0.03f, 0.03f, 0.03f, 0.03f, 0.03f, 0.03f, 0.85f, 0.03f, 0.05f, 0.02f, 0.05f, 0.05f, 0.05f};
    /** Multiplier for impact damage (explosions always do full damage). */
    static final float[] MAT_IMPACT = {1, 1, 1, 1, 1, 1, 1, 1, 1, 0.3f, 1, 1, 0f, 1, 0, 0};
    static final int[] MAT_POINTS = {100, 150, 200, 250, 220, 400, 160, 300, 500, 350, 400, 300, 600, 1500, 0, 200};

    // block flags
    static final int F_TARGET = 1, F_PROTECT = 2;

    // ---------------------------------------------------------------- sounds
    static final int S_LAUNCH = 0, S_WOOD = 1, S_GLASS = 2, S_STONE = 3, S_METAL = 4, S_BOOM = 5,
            S_PIANO = 6, S_SPLAT = 7, S_CLICK = 8, S_STAR = 9, S_THUD = 10, S_WIN = 11, S_STRETCH = 12, S_HONK = 13,
            S_MOO = 14, S_FREEZE = 15, S_VORTEX = 16, S_COIN = 17, S_POP = 18, S_ROCKET = 19, S_BOING = 20, S_CHEST = 21;
    static final int NUM_SOUNDS = 22;
    static final int[] MAT_BREAK_SOUND = {S_WOOD, S_GLASS, S_STONE, S_STONE, S_STONE, S_METAL, S_GLASS, S_BOOM, S_COIN,
            S_BOING, S_METAL, S_GLASS, S_METAL, S_FREEZE, S_COIN, S_GLASS};

    // ---------------------------------------------------------------- ammo
    static final int A_BRICK = 0, A_BOWLING = 1, A_MELON = 2, A_ANVIL = 3, A_CAR = 4, A_PIANO = 5,
            A_TNT = 6, A_WRECK = 7, A_FRIDGE = 8, A_BOULDER = 9, A_CANNON = 10, A_TIRE = 11, A_SAFE = 12,
            A_COW = 13, A_BUS = 14, A_CLUSTER = 15, A_ROCKET = 16, A_FREEZE = 17, A_HOLE = 18, A_METEOR = 19,
            A_MINI = 20;
    static final int NUM_AMMO = 20;
    static final String[] AMMO_NAME = {"Brick", "Bowling Ball", "Watermelon", "Anvil", "Car", "Piano",
            "TNT Barrel", "Wrecking Ball", "Fridge", "Boulder", "Cannonball", "Tire", "Safe", "Cow", "Bus",
            "Cluster Bomb", "Rocket", "Freeze Bomb", "Black Hole", "Meteor", "Bomblet"};
    static final String[] AMMO_DESC = {
            "Cheap, reliable and surprisingly rude. The classic.",
            "Strike! Rolls through glass like it is not even there.",
            "Explodes into juicy chaos on impact. Messy but fun.",
            "Cartoon physics approved. Heavy, heavy, heavy.",
            "A whole car. Honks as it flies. Insurance not included.",
            "Plays one last dramatic chord on impact.",
            "Boom on impact. Tap mid-air to detonate early!",
            "Massive steel sphere. Flattens anything in its path.",
            "Tall, cold and full of leftovers.",
            "A big rock. Sometimes the simple answer is the right one.",
            "Small, dense and very fast. Punches straight through.",
            "Super bouncy! Ricochets around the building.",
            "Ridiculously heavy for its size. Gravity loves it.",
            "Moo. Somewhere a farmer is very confused.",
            "The biggest thing you can fit in a slingshot.",
            "Tap mid-air to split into four bomblets!",
            "Tap mid-air to fire the booster. Explodes on impact.",
            "Freezes everything around it. Frozen blocks shatter!",
            "Tap to open a tiny black hole that sucks the building in.",
            "A burning space rock. Huge explosion on impact.",
            ""};
    static final int SH_BOX = 0, SH_CIRCLE = 1, SH_POLY = 2;
    static final int[] AMMO_SHAPE = {SH_BOX, SH_CIRCLE, SH_CIRCLE, SH_POLY, SH_BOX, SH_BOX, SH_BOX, SH_CIRCLE, SH_BOX, SH_POLY,
            SH_CIRCLE, SH_CIRCLE, SH_BOX, SH_BOX, SH_BOX, SH_CIRCLE, SH_BOX, SH_CIRCLE, SH_CIRCLE, SH_CIRCLE, SH_CIRCLE};
    /** box: half width, half height. circle: radius. poly: bounding radius. */
    static final float[][] AMMO_SIZE = {{0.5f, 0.24f}, {0.48f}, {0.58f}, {0.85f}, {1.3f, 0.48f}, {1.0f, 0.72f},
            {0.45f, 0.58f}, {0.92f}, {0.52f, 0.98f}, {0.8f}, {0.42f}, {0.6f}, {0.6f, 0.6f}, {1.0f, 0.55f}, {2.4f, 0.78f},
            {0.5f}, {0.95f, 0.26f}, {0.52f}, {0.48f}, {0.75f}, {0.28f}};
    static final float[] AMMO_DENSITY = {3f, 6f, 1.6f, 9f, 2.6f, 3.4f, 2f, 7f, 2.8f, 4.5f,
            14f, 1.4f, 15f, 2f, 2.1f, 4f, 3f, 3f, 3f, 8f, 6f};
    static final float[] AMMO_RESTITUTION = {0.1f, 0.2f, 0.05f, 0.05f, 0.15f, 0.08f, 0.1f, 0.12f, 0.1f, 0.08f,
            0.12f, 0.82f, 0.05f, 0.2f, 0.1f, 0.1f, 0.05f, 0.1f, 0.1f, 0.05f, 0.1f};
    static final int[] AMMO_PRICE = {0, 0, 0, 0, 0, 0, 0, 1200, 600, 800, 900, 700, 2000, 1500, 2500,
            3000, 3500, 4000, 6000, 5000};
    static final int CAT_HEAVY = 1, CAT_EXPLOSIVE = 2, CAT_SPECIAL = 3;
    static final int[] AMMO_CAT = {CAT_HEAVY, CAT_HEAVY, CAT_SPECIAL, CAT_HEAVY, CAT_HEAVY, CAT_HEAVY, CAT_EXPLOSIVE,
            CAT_HEAVY, CAT_HEAVY, CAT_HEAVY, CAT_HEAVY, CAT_SPECIAL, CAT_HEAVY, CAT_SPECIAL, CAT_HEAVY,
            CAT_EXPLOSIVE, CAT_EXPLOSIVE, CAT_SPECIAL, CAT_SPECIAL, CAT_EXPLOSIVE};
    /** weight, power, chaos (0..1) for the armory. */
    static final float[][] AMMO_STATS = {
            {0.2f, 0.25f, 0.1f}, {0.45f, 0.4f, 0.2f}, {0.15f, 0.15f, 0.5f}, {0.75f, 0.6f, 0.2f}, {0.6f, 0.7f, 0.4f},
            {0.6f, 0.6f, 0.5f}, {0.15f, 0.75f, 0.7f}, {0.95f, 0.85f, 0.3f}, {0.5f, 0.55f, 0.3f}, {0.6f, 0.55f, 0.2f},
            {0.55f, 0.6f, 0.2f}, {0.15f, 0.35f, 0.8f}, {1.0f, 0.75f, 0.2f}, {0.35f, 0.45f, 0.75f}, {1.0f, 1.0f, 0.6f},
            {0.3f, 0.85f, 0.9f}, {0.25f, 0.8f, 0.85f}, {0.3f, 0.7f, 0.85f}, {0.2f, 0.95f, 1.0f}, {0.8f, 0.95f, 0.8f}};
    /** Specials that react to a tap while flying. */
    static boolean tappable(int t) {
        return t == A_TNT || t == A_CLUSTER || t == A_ROCKET || t == A_FREEZE || t == A_HOLE;
    }

    static final String[] TAP_HINT = new String[NUM_AMMO];

    static {
        TAP_HINT[A_TNT] = "TAP TO DETONATE!";
        TAP_HINT[A_CLUSTER] = "TAP TO SPLIT!";
        TAP_HINT[A_ROCKET] = "TAP TO BOOST!";
        TAP_HINT[A_FREEZE] = "TAP TO FREEZE!";
        TAP_HINT[A_HOLE] = "TAP FOR BLACK HOLE!";
    }

    static final float[] ANVIL_POLY = {-0.45f, -0.42f, 0.45f, -0.42f, 0.85f, 0.28f, 0.85f, 0.42f, -0.85f, 0.42f, -0.85f, 0.28f};
    static final float[] BOULDER_POLY;

    static {
        float[] r = {0.8f, 0.7f, 0.78f, 0.68f, 0.8f, 0.72f, 0.76f, 0.69f};
        BOULDER_POLY = new float[16];
        for (int i = 0; i < 8; i++) {
            double a = i * Math.PI / 4 + 0.2;
            BOULDER_POLY[i * 2] = (float) (Math.cos(a) * r[i]);
            BOULDER_POLY[i * 2 + 1] = (float) (Math.sin(a) * r[i]);
        }
    }

    // ---------------------------------------------------------------- themes / worlds
    static final int T_DAY = 0, T_SUNSET = 1, T_NIGHT = 2, T_WINTER = 3, T_DESERT = 4, T_LAVA = 5, T_LAB = 6;
    static final int NUM_THEMES = 7;
    static final String[] WORLD_NAME = {"Countryside", "Desert Ruins", "Frozen Peaks", "Neon City", "Lava Fortress", "Chaos Lab"};
    static final int[] WORLD_THEME = {T_DAY, T_DESERT, T_WINTER, T_NIGHT, T_LAVA, T_LAB};
    static final int LEVELS_PER_WORLD = 9;
    static final int NUM_WORLDS = 6;
    /** Stars needed to open each world. */
    static final int[] WORLD_REQ = {0, 16, 38, 62, 88, 110};

    // ---------------------------------------------------------------- slingshot skins
    static final String[] SKIN_NAME = {"Classic Wood", "Desert Bone", "Ice Crystal", "Neon Glow", "Lava Obsidian", "Royal Gold", "Candy", "Steel Monster"};
    static final String[] SKIN_HOW = {"Default", "Beat the Desert boss", "Beat the Frozen boss", "Beat the Neon boss",
            "Beat the Lava boss", "Found in chests", "Found in chests", "Found in chests"};
    static final int NUM_SKINS = 8;
    /** wood, light, dark, band, lashing */
    static final int[][] SKIN_COL = {
            {0xFF7A4A22, 0xFFB8824A, 0xFF4A2A10, 0xFF3A1B12, 0xFFE9D3A8},
            {0xFFE8D6B0, 0xFFFFF4DA, 0xFFB39A6A, 0xFF7A4A22, 0xFF8A5A2B},
            {0xFF8FD3F0, 0xFFE6FAFF, 0xFF4A90B8, 0xFF2B6FA0, 0xFFFFFFFF},
            {0xFF2B1F5C, 0xFFFF7AE0, 0xFF5BC8FF, 0xFF5BC8FF, 0xFFFF7AE0},
            {0xFF2A1214, 0xFFFF6A1F, 0xFF120606, 0xFFFFB13B, 0xFF5A2A1E},
            {0xFFE0A520, 0xFFFFF09A, 0xFF8A5A00, 0xFF7A1A0A, 0xFFFFFFFF},
            {0xFFFF8FB8, 0xFFFFFFFF, 0xFFC2457A, 0xFF5BC8FF, 0xFFFFE780},
            {0xFF6F7E8E, 0xFFB8C2CC, 0xFF3A4450, 0xFF1C1C22, 0xFFFFC93C}};

    // ---------------------------------------------------------------- objectives
    static final int O_DESTROY = 0, O_CROWN = 1, O_TARGETS = 2, O_PROTECT = 3, O_TIME = 4, O_CORES = 5;

    static final class Spec {
        final float x, y, w, h; // centre + size (for polygons: body position, w/h = bounds)
        final int mat;
        final float[] verts; // local polygon (CCW) or null for a box
        int flags;

        Spec(float x, float y, float w, float h, int mat, float[] verts) {
            this.x = x; this.y = y; this.w = w; this.h = h; this.mat = mat; this.verts = verts;
        }
    }

    static final class LevelDef {
        final String name;
        final int theme;
        int shots, par, objective = O_DESTROY;
        final ArrayList<Spec> specs;
        float timeLimit, star2 = 0.85f, star3 = 0.9f, wind, quake, platformAmp, platformPeriod = 9f, regen, regenHeal = 0.3f;
        int regenCount = 10;
        String hint;
        boolean boss;

        LevelDef(String name, int theme, int shots, ArrayList<Spec> specs) {
            this.name = name; this.theme = theme; this.shots = shots; this.specs = specs;
            this.par = Math.max(1, shots - 2);
        }

        LevelDef obj(int o) {
            objective = o;
            if (o != O_DESTROY) { star2 = 0.72f; star3 = 0.85f; }
            return this;
        }

        LevelDef time(float t) { objective = O_TIME; timeLimit = t; star2 = 0.8f; star3 = 0.9f; return this; }
        LevelDef par(int p) { par = Math.max(1, p - 1); return this; }
        LevelDef exactPar(int p) { par = p; return this; }
        LevelDef hint(String h) { hint = h; return this; }
        LevelDef superRegen(float every, float heal, int count) { regen = every; regenHeal = heal; regenCount = count; return this; }
        LevelDef wind(float w) { wind = w; return this; }
        LevelDef quake(float q) { quake = q; return this; }
        LevelDef platform(float amp, float period) { platformAmp = amp; platformPeriod = period; return this; }
        LevelDef regen(float r) { regen = r; return this; }
        LevelDef boss() { boss = true; obj(O_CORES); return this; }

        int count(int mat) {
            int n = 0;
            for (Spec s : specs) if (s.mat == mat) n++;
            return n;
        }

        int countFlag(int f) {
            int n = 0;
            for (Spec s : specs) if ((s.flags & f) != 0) n++;
            return n;
        }

        String objectiveText() {
            switch (objective) {
                case O_CROWN: return "KNOCK DOWN THE CROWN";
                case O_TARGETS: return "DESTROY ALL " + countFlag(F_TARGET) + " TARGETS";
                case O_PROTECT: return "SMASH IT - DON'T HIT THE NEIGHBOR!";
                case O_TIME: return "DESTROY 60% IN " + (int) timeLimit + " SECONDS";
                case O_CORES: return "DESTROY ALL " + count(CORE) + " POWER CORES";
                default: return "DESTROY 50% OF THE BUILDING";
            }
        }
    }

    /** Small helper for building structures. (x, y) is always the bottom-left corner. */
    static final class B {
        final ArrayList<Spec> s = new ArrayList<>();

        void box(float x, float y, float w, float h, int m) {
            s.add(new Spec(x + w / 2f, y + h / 2f, w, h, m, null));
        }

        /** Isosceles triangle, base from x to x+w at height y. */
        void tri(float x, float y, float w, float h, int m) {
            float cx = x + w / 2f, cy = y + h / 3f;
            s.add(new Spec(cx, cy, w, h, m, new float[]{-w / 2f, -h / 3f, w / 2f, -h / 3f, 0f, h * 2f / 3f}));
        }

        void crown(float cx, float y) {
            box(cx - 0.45f, y, 0.9f, 0.55f, CROWN);
        }

        void mark(int idx, int f) {
            s.get(idx).flags |= f;
        }

        void markLast(int f) {
            s.get(s.size() - 1).flags |= f;
        }

        /** The little neighbour's house standing in front of the target. */
        void neighbor(float x) {
            int start = s.size();
            float y = storey(x, 0, 3, 1.6f, 0.25f, WOOD, WOOD);
            box(x + 0.85f, 0, 1.3f, 0.9f, GLASS);
            tri(x - 0.2f, y, 3.4f, 1.0f, BRICK);
            for (int i = start; i < s.size(); i++) s.get(i).flags |= F_PROTECT;
        }

        float storey(float x, float y, float w, float h, float t, int wall, int slab) {
            box(x, y, t, h, wall);
            box(x + w - t, y, t, h, wall);
            box(x, y + h, w, t, slab);
            return y + h + t;
        }

        float fillFloor(float x, float y, float w, float h, float colW, int cols, int colMat, int fill, int slabMat, float slabT) {
            float gap = (w - cols * colW) / (cols - 1);
            for (int i = 0; i < cols; i++) {
                float cx = x + i * (colW + gap);
                box(cx, y, colW, h, colMat);
                if (i < cols - 1) box(cx + colW, y, gap, h, fill);
            }
            box(x, y + h, w, slabT, slabMat);
            return y + h + slabT;
        }

        float glassFloor(float x, float y, float w, float h, float colW, int cols, int colMat, int slabMat, float slabT) {
            return fillFloor(x, y, w, h, colW, cols, colMat, GLASS, slabMat, slabT);
        }

        void window(float x, float y, float w, float h, int mat) {
            box(x, y, w, h * 0.28f, mat);
            box(x, y + h * 0.28f, w, h * 0.5f, GLASS);
            box(x, y + h * 0.78f, w, h * 0.22f, mat);
        }

        float column(float x, float y, float w, float bh, int n, int m) {
            for (int i = 0; i < n; i++) box(x, y + i * bh, w, bh, m);
            return y + n * bh;
        }

        float pyramid(float x0, float y0, int rows, float bw, float bh, int m) {
            for (int r = 0; r < rows; r++) {
                int n = rows - r;
                float x = x0 + r * bw / 2f;
                for (int i = 0; i < n; i++) box(x + i * bw, y0 + r * bh, bw, bh, m);
            }
            return y0 + rows * bh;
        }
    }

    /** A power core locked in an unbreakable shield cage (left, right, roof). */
    static void cage(B b, float cx, float y) {
        b.box(cx - 1.0f, y, 0.4f, 1.6f, SHIELD);
        b.box(cx - 0.6f, y, 1.2f, 1.2f, CORE);
        b.box(cx + 0.6f, y, 0.4f, 1.6f, SHIELD);
        b.box(cx - 1.0f, y + 1.6f, 2.0f, 0.4f, SHIELD);
    }

    static final LevelDef[] LEVELS = buildLevels();

    static int worldOf(int level) { return level / LEVELS_PER_WORLD; }

    private static LevelDef[] buildLevels() {
        ArrayList<LevelDef> L = new ArrayList<>();
        B b;

        // ================================================================ WORLD 1 · COUNTRYSIDE
        b = new B();
        {
            float y = b.storey(26, 0, 6, 2.8f, 0.4f, WOOD, WOOD);
            b.box(26.6f, 0, 1.1f, 1.1f, WOOD);
            b.box(26.6f, 1.1f, 1.1f, 1.1f, WOOD);
            b.box(30.0f, 0, 1.2f, 1.2f, WOOD);
            y = b.storey(26.8f, y, 4.4f, 2.2f, 0.35f, WOOD, WOOD);
            b.tri(26.3f, y, 5.4f, 1.8f, WOOD);
        }
        L.add(new LevelDef("Wooden Shack", T_DAY, 4, b.s).par(2));

        b = new B();
        {
            float y = b.glassFloor(25, 0, 9, 2.6f, 0.25f, 4, STEEL, GLASS, 0.25f);
            y = b.glassFloor(26.2f, y, 6.6f, 2.0f, 0.22f, 3, STEEL, GLASS, 0.22f);
            b.tri(25.9f, y, 7.2f, 2.0f, GLASS);
            b.mark(3, F_TARGET);
            b.mark(9, F_TARGET);
            b.mark(11, F_TARGET);
            b.markLast(F_TARGET);
        }
        L.add(new LevelDef("Glass Greenhouse", T_DAY, 3, b.s).obj(O_TARGETS).par(2));

        b = new B();
        {
            float y = 0;
            for (int f = 0; f < 2; f++) {
                float h = 2.6f;
                b.box(25, y, 0.6f, h, BRICK);
                b.window(25.6f, y, 2.0f, h, BRICK);
                b.box(27.6f, y, 0.6f, h, BRICK);
                if (f == 0) {
                    b.box(28.2f, y, 1.6f, 2.0f, WOOD);
                    b.box(28.2f, y + 2.0f, 1.6f, 0.6f, BRICK);
                } else b.window(28.2f, y, 1.6f, h, BRICK);
                b.box(29.8f, y, 0.6f, h, BRICK);
                b.window(30.4f, y, 2.0f, h, BRICK);
                b.box(32.4f, y, 0.6f, h, BRICK);
                b.box(25, y + h, 8f, 0.35f, WOOD);
                y += h + 0.35f;
            }
            b.tri(24.6f, y, 8.8f, 2.6f, BRICK);
            b.neighbor(15.8f);
        }
        L.add(new LevelDef("Brick House", T_DAY, 5, b.s).obj(O_PROTECT).par(3));

        b = new B();
        {
            for (int i = 0; i < 12; i++) b.box(24 + i * 1.45f, 0, 0.45f, 3.6f, i % 3 == 2 ? STONE : WOOD);
            b.column(42.0f, 0, 1.2f, 1.0f, 4, BRICK);
            b.column(43.2f, 0, 1.2f, 1.0f, 4, BRICK);
            b.box(41.8f, 4.0f, 2.8f, 0.4f, WOOD);
            b.tri(41.8f, 4.4f, 2.8f, 1.4f, WOOD);
        }
        L.add(new LevelDef("Domino Row", T_DAY, 3, b.s).time(14).par(2));

        b = new B();
        {
            float y = 0;
            for (int i = 0; i < 4; i++) y = b.storey(29, y, 3.4f, 2.3f, 0.5f, WOOD, WOOD);
            b.box(28.5f, y, 4.4f, 0.35f, WOOD);
            y += 0.35f;
            b.box(28.6f, y, 0.25f, 0.9f, WOOD);
            b.box(32.65f, y, 0.25f, 0.9f, WOOD);
            y = b.storey(29.3f, y, 2.8f, 2.0f, 0.3f, WOOD, WOOD);
            b.crown(30.7f, y);
            b.box(30.1f, 0, 1.2f, 0.9f, TNT);
        }
        L.add(new LevelDef("Watchtower", T_DAY, 4, b.s).obj(O_CROWN).par(2));

        b = new B();
        {
            float y = 0;
            for (int i = 0; i < 16; i++) {
                if (i % 2 == 0) {
                    b.box(28.5f, y, 1.0f, 0.55f, WOOD);
                    b.box(29.5f, y, 1.0f, 0.55f, WOOD);
                    b.box(30.5f, y, 1.0f, 0.55f, WOOD);
                } else b.box(28.5f, y, 3.0f, 0.55f, WOOD);
                y += 0.55f;
            }
            b.box(29.25f, y, 1.5f, 1.5f, GOLD);
            b.crown(30f, y + 1.5f);
        }
        L.add(new LevelDef("Jenga Tower", T_DAY, 3, b.s).obj(O_CROWN).wind(2f).par(2));

        b = new B();
        {
            float y = b.storey(25, 0, 9, 3.2f, 0.5f, WOOD, WOOD);
            for (int i = 0; i < 3; i++) b.box(25.7f + i * 1.3f, 0, 1.2f, 1.0f, WOOD);
            b.box(26.3f, 1.0f, 1.2f, 1.0f, WOOD);
            b.box(31.4f, 0, 1.0f, 2.2f, WOOD);
            y = b.storey(26.2f, y, 6.6f, 2.2f, 0.4f, WOOD, WOOD);
            b.box(28.6f, 3.7f, 1.8f, 1.2f, GOLD);
            b.tri(25.0f, y, 9.0f, 3.0f, BRICK);
            for (int i = 3; i <= 6; i++) b.mark(i, F_TARGET);
            b.mark(11, F_TARGET);
        }
        L.add(new LevelDef("Red Barn", T_DAY, 4, b.s).obj(O_TARGETS).par(3));

        b = new B();
        {
            float cx = 37f, y = 0;
            float[] w = {2.8f, 2.5f, 2.2f, 1.9f};
            for (int i = 0; i < w.length; i++) {
                b.box(cx - w[i] / 2, y, w[i], 1.6f, i % 2 == 0 ? BRICK : CONCRETE);
                y += 1.6f;
            }
            b.tri(cx - 1.4f, y, 2.8f, 2.0f, WOOD);
            float t = b.storey(25, 0, 5, 2.4f, 0.35f, WOOD, WOOD);
            b.tri(24.8f, t, 5.4f, 1.4f, BRICK);
            b.box(25.6f, 0, 1.0f, 1.0f, WOOD);
            b.box(28.0f, 0, 1.1f, 1.1f, WOOD);
            b.box(26.8f, 0, 0.6f, 0.4f, GOLD);
            b.box(31.2f, 0, 1.2f, 0.9f, WOOD);
            b.box(31.2f, 0.9f, 1.2f, 0.9f, WOOD);
            b.box(32.6f, 0, 1.0f, 0.9f, TNT);
            b.neighbor(15.8f);
        }
        L.add(new LevelDef("Windmill Farm", T_DAY, 5, b.s).obj(O_PROTECT).wind(-2f).par(3));

        b = new B();
        {
            float y = b.storey(27.5f, 0, 9, 2.4f, 0.45f, WOOD, WOOD);
            b.box(30.3f, 0, 0.4f, 2.4f, WOOD);
            b.box(33.3f, 0, 0.4f, 2.4f, WOOD);
            b.box(31.4f, 0, 1.2f, 1.2f, CORE);
            b.box(28.3f, 0, 1.0f, 1.0f, WOOD);
            b.box(34.6f, 0, 1.0f, 1.0f, TNT);
            float y2 = b.storey(28.5f, y, 7, 2.0f, 0.4f, WOOD, BRICK);
            b.box(31.4f, y, 1.2f, 1.2f, CORE);
            b.box(29.2f, y, 1.0f, 1.0f, WOOD);
            b.tri(28.3f, y2, 7.4f, 1.8f, BRICK);
        }
        L.add(new LevelDef("BOSS: Rolling Fortress", T_DAY, 6, b.s).boss().platform(2.2f, 11f).par(4));

        // ================================================================ WORLD 2 · DESERT RUINS
        b = new B();
        {
            float top = b.pyramid(26, 0, 8, 1.5f, 1.0f, STONE);
            b.crown(26 + 4 * 1.5f, top);
        }
        L.add(new LevelDef("Pyramid", T_DESERT, 5, b.s).obj(O_CROWN).wind(2f).par(3));

        b = new B();
        {
            b.storey(24, 0, 3, 2.2f, 0.25f, WOOD, WOOD);
            b.box(24.5f, 0, 0.9f, 0.7f, WOOD);
            b.box(25.6f, 0, 0.6f, 0.6f, GLASS);
            b.markLast(F_TARGET);
            float y = b.storey(28, 0, 6, 2.6f, 0.6f, STONE, STONE);
            b.box(30.3f, 0, 1.2f, 1.0f, TNT);
            b.box(29.0f, 0, 0.9f, 0.9f, WOOD);
            y = b.storey(28.8f, y, 4.4f, 2.2f, 0.5f, STONE, WOOD);
            b.tri(28.6f, y, 4.8f, 1.8f, STONE);
            b.storey(35.5f, 0, 3, 2.2f, 0.25f, WOOD, WOOD);
            b.box(36.1f, 0, 0.5f, 0.8f, GLASS);
            b.markLast(F_TARGET);
            b.box(36.8f, 0, 0.5f, 0.8f, GLASS);
            b.markLast(F_TARGET);
            b.box(37.5f, 0, 0.5f, 0.3f, GOLD);
            b.markLast(F_TARGET);
        }
        L.add(new LevelDef("Desert Bazaar", T_DESERT, 5, b.s).obj(O_TARGETS).wind(-2f).par(2));

        b = new B();
        {
            b.box(24, 0, 11, 0.4f, STONE);
            b.box(24.4f, 0.4f, 10.2f, 0.4f, STONE);
            b.box(24.8f, 0.8f, 9.4f, 0.4f, STONE);
            for (int i = 0; i < 5; i++) {
                float cx = 25.2f + i * 2.05f;
                b.box(cx, 1.2f, 0.7f, 2.2f, (i == 1 || i == 3) ? RUBBER : STONE);
                b.box(cx, 3.4f, 0.7f, 2.2f, STONE);
                b.box(cx - 0.15f, 5.6f, 1.0f, 0.3f, STONE);
            }
            b.box(24.8f, 5.9f, 9.4f, 0.6f, STONE);
            b.tri(24.6f, 6.5f, 9.8f, 1.8f, STONE);
            b.box(26.3f, 1.2f, 0.5f, 0.5f, GOLD);
            b.box(32.4f, 1.2f, 0.5f, 0.5f, GOLD);
        }
        L.add(new LevelDef("Greek Temple", T_DESERT, 5, b.s).wind(-3f).par(3));

        b = new B();
        {
            b.column(27, 0, 1.4f, 1.0f, 4, STONE);
            b.column(35.6f, 0, 1.4f, 1.0f, 4, STONE);
            b.box(27, 4, 10, 0.8f, STONE);
            b.box(28, 4.8f, 8, 0.7f, STONE);
            b.box(29.5f, 5.5f, 5, 0.6f, STONE);
            b.tri(29.3f, 6.1f, 5.4f, 1.4f, STONE);
            b.box(31.6f, 0, 0.8f, 0.5f, GOLD);
            b.box(31.8f, 0.5f, 0.4f, 0.3f, GOLD);
            b.box(29.5f, 0, 0.5f, 0.9f, GLASS);
            b.box(33.8f, 0, 0.5f, 0.9f, GLASS);
        }
        L.add(new LevelDef("Sandstone Arch", T_DESERT, 4, b.s).time(12).par(3));

        b = new B();
        {
            b.column(25.0f, 0, 1.6f, 1.0f, 4, STONE);
            b.column(31.0f, 0, 1.6f, 1.0f, 4, STONE);
            b.column(37.0f, 0, 1.6f, 1.0f, 4, STONE);
            b.box(25.0f, 4f, 6.8f, 0.5f, CONCRETE);
            b.box(31.8f, 4f, 6.8f, 0.5f, CONCRETE);
            b.box(26.0f, 4.5f, 2.2f, 1.0f, STEEL);
            b.box(29.0f, 4.5f, 1.0f, 1.0f, WOOD);
            b.box(29.0f, 5.5f, 1.0f, 1.0f, TNT);
            float y = b.storey(33.0f, 4.5f, 2.8f, 1.8f, 0.3f, WOOD, WOOD);
            b.tri(32.8f, y, 3.2f, 1.2f, BRICK);
            b.box(36.5f, 4.5f, 1.8f, 0.9f, STEEL);
            b.neighbor(15.8f);
        }
        L.add(new LevelDef("Stone Bridge", T_DESERT, 5, b.s).obj(O_PROTECT).wind(3f).par(3));

        b = new B();
        {
            float cx = 33f;
            float y = b.storey(cx - 2.5f, 0, 5, 2.4f, 0.5f, STONE, STONE);
            b.box(cx - 0.6f, 0, 1.2f, 1.8f, WOOD);
            y = b.column(cx - 1.3f, y, 2.6f, 1.4f, 4, STONE);
            b.box(cx - 2.0f, y, 4.0f, 0.35f, WOOD);
            y += 0.35f;
            b.box(cx - 1.95f, y, 0.2f, 0.8f, WOOD);
            b.box(cx + 1.75f, y, 0.2f, 0.8f, WOOD);
            b.box(cx - 0.75f, y, 1.5f, 1.4f, GLASS);
            b.markLast(F_TARGET);
            y = b.storey(cx - 1.0f, y, 2.0f, 1.4f, 0.25f, STONE, STONE);
            b.tri(cx - 1.2f, y, 2.4f, 1.6f, GOLD);
            b.markLast(F_TARGET);
            b.box(26.0f, 0, 1.1f, 1.1f, WOOD);
            b.box(27.2f, 0, 1.0f, 0.9f, TNT);
            b.markLast(F_TARGET);
        }
        L.add(new LevelDef("Oasis Tower", T_DESERT, 4, b.s).obj(O_TARGETS).wind(4f).par(2));

        b = new B();
        {
            float t1 = b.pyramid(24.5f, 0, 5, 1.2f, 0.9f, STONE);
            b.box(24.5f + 2.4f + 0.2f, t1, 0.8f, 0.5f, GOLD);
            float t2 = b.pyramid(33f, 0, 6, 1.2f, 0.9f, STONE);
            b.crown(33f + 3.6f, t2);
            b.box(31.2f, 0, 1.0f, 0.9f, TNT);
        }
        L.add(new LevelDef("Twin Pyramids", T_DESERT, 4, b.s).obj(O_CROWN).wind(-2f).par(3));

        b = new B();
        {
            float y = b.storey(25, 0, 10, 2.4f, 1.0f, CONCRETE, ARMOR);
            b.box(29.2f, 0, 0.6f, 2.4f, STEEL);
            b.box(26.3f, 0, 1.0f, 1.0f, WOOD);
            b.box(31.0f, 0, 1.6f, 0.8f, STEEL);
            b.box(32.8f, 0, 0.6f, 0.4f, GOLD);
            y = b.storey(26.5f, y, 7f, 1.8f, 0.8f, CONCRETE, ARMOR);
            b.box(28.5f, y, 3f, 0.8f, CONCRETE);
            b.box(36.0f, 0, 1.0f, 1.0f, CONCRETE);
            b.box(37.2f, 0, 1.0f, 0.6f, CONCRETE);
        }
        L.add(new LevelDef("Steel Bunker", T_DESERT, 6, b.s).par(4));

        b = new B();
        {
            float bw = 1.5f, bh = 1.0f;
            for (int r = 0; r < 8; r++) {
                int n = 8 - r;
                float x0 = 26 + r * bw / 2f;
                for (int i = 0; i < n; i++) {
                    boolean core = (r == 1 && (i == 1 || i == 5)) || (r == 5 && i == 1);
                    b.box(x0 + i * bw, r * bh, bw, bh, core ? CORE : STONE);
                }
            }
            b.box(26 + 3.5f * 1.5f + 0.25f, 8, 1.0f, 0.7f, GOLD);
        }
        L.add(new LevelDef("BOSS: Pharaoh's Tomb", T_DESERT, 7, b.s).boss().regen(6f).wind(1.5f).par(5));

        // ================================================================ WORLD 3 · FROZEN PEAKS
        b = new B();
        {
            float y = b.storey(25, 0, 10, 2.5f, 0.5f, ICE, ICE);
            b.box(27.5f, 0, 0.5f, 2.5f, ICE);
            b.box(32.0f, 0, 0.5f, 2.5f, ICE);
            b.box(29.2f, 0, 1.6f, 1.6f, ICE);
            float t = b.column(25.1f, y, 1.4f, 1.0f, 3, ICE);
            b.tri(24.95f, t, 1.7f, 1.6f, CRYSTAL);
            b.column(33.5f, y, 1.4f, 1.0f, 3, ICE);
            b.tri(33.35f, t, 1.7f, 1.6f, CRYSTAL);
            float y2 = b.storey(27.5f, y, 5f, 2.2f, 0.4f, ICE, ICE);
            b.tri(27.3f, y2, 5.4f, 2.4f, ICE);
        }
        L.add(new LevelDef("Ice Palace", T_WINTER, 4, b.s).par(2));

        b = new B();
        {
            for (int k = 0; k < 2; k++) {
                float x0 = k == 0 ? 25f : 31.5f;
                for (int r = 0; r < 4; r++) {
                    int n = 5 - r;
                    for (int i = 0; i < n; i++) b.box(x0 + r * 0.45f + i * 0.9f, r * 0.7f, 0.9f, 0.7f, ICE);
                }
            }
            b.box(38f, 0, 1.2f, 1.0f, ICE);
            b.markLast(F_TARGET);
            b.box(38.15f, 1.0f, 0.9f, 0.8f, ICE);
            b.markLast(F_TARGET);
            b.box(38.3f, 1.8f, 0.6f, 0.6f, CRYSTAL);
            b.markLast(F_TARGET);
            b.column(41f, 0, 1.0f, 0.7f, 3, ICE);
            b.box(30.0f, 0, 1.0f, 0.9f, TNT);
        }
        L.add(new LevelDef("Igloo Village", T_WINTER, 3, b.s).obj(O_TARGETS).par(2));

        b = new B();
        {
            float y = b.glassFloor(26, 0, 8, 2.6f, 0.5f, 3, WOOD, WOOD, 0.4f);
            y = b.glassFloor(27, y, 6, 2.2f, 0.4f, 3, WOOD, WOOD, 0.35f);
            b.tri(25.6f, y, 8.8f, 3.0f, BRICK);
            float t = b.column(35f, 0, 1.0f, 1.0f, 6, STONE);
            b.crown(35.5f, t);
            b.box(36.4f, 0, 1.0f, 0.9f, TNT);
        }
        L.add(new LevelDef("Ski Lodge", T_WINTER, 4, b.s).obj(O_CROWN).wind(-2f).par(2));

        b = new B();
        {
            float y = 0;
            float cx = 31f;
            float[] widths = {3.6f, 3.3f, 3.0f, 2.7f, 2.4f, 2.1f};
            for (int i = 0; i < widths.length; i++) {
                b.box(cx - widths[i] / 2, y, widths[i], 1.5f, i % 2 == 0 ? CONCRETE : BRICK);
                y += 1.5f;
            }
            b.box(cx - 1.7f, y, 3.4f, 0.3f, STEEL);
            y += 0.3f;
            b.box(cx - 1.0f, y, 0.18f, 1.4f, STEEL);
            b.box(cx - 0.82f, y, 1.64f, 1.4f, CRYSTAL);
            b.box(cx + 0.82f, y, 0.18f, 1.4f, STEEL);
            y += 1.4f;
            b.tri(cx - 1.2f, y, 2.4f, 1.3f, STEEL);
            b.box(26.5f, 0, 1.4f, 1.0f, ICE);
            b.box(34.3f, 0, 1.6f, 1.2f, ICE);
            b.box(36.0f, 0, 1.0f, 0.7f, ICE);
        }
        L.add(new LevelDef("Frozen Lighthouse", T_WINTER, 4, b.s).time(12).par(3));

        b = new B();
        {
            b.column(25, 0, 1.4f, 1.0f, 3, ICE);
            b.column(31.3f, 0, 1.4f, 1.0f, 3, ICE);
            b.column(37.6f, 0, 1.4f, 1.0f, 3, ICE);
            b.box(25, 3, 7.0f, 0.45f, ICE);
            b.box(32, 3, 7.0f, 0.45f, ICE);
            b.box(27f, 3.45f, 1.6f, 0.5f, WOOD);
            b.markLast(F_TARGET);
            b.box(34f, 3.45f, 1.0f, 0.9f, TNT);
            b.box(36f, 3.45f, 1.0f, 0.9f, ICE);
            b.markLast(F_TARGET);
            b.box(36.15f, 4.35f, 0.7f, 0.6f, ICE);
            b.markLast(F_TARGET);
            b.box(29.5f, 3.45f, 0.6f, 0.4f, GOLD);
            b.markLast(F_TARGET);
        }
        L.add(new LevelDef("Ice Bridge", T_WINTER, 4, b.s).obj(O_TARGETS).wind(3f).par(3));

        b = new B();
        {
            float cx = 31f, y = 0;
            float[] w = {6f, 5f, 4f, 3.2f};
            for (float tw : w) {
                y = b.storey(cx - tw / 2, y, tw, 1.8f, 0.4f, WOOD, WOOD) - 0.4f;
                b.s.remove(b.s.size() - 1);
                b.box(cx - tw / 2 - 0.7f, y, tw + 1.4f, 0.4f, BRICK);
                y += 0.4f;
            }
            b.crown(cx, y);
            b.box(cx - 0.5f, 0, 1.0f, 0.9f, TNT);
        }
        L.add(new LevelDef("Snowy Pagoda", T_WINTER, 5, b.s).obj(O_CROWN).par(3));

        b = new B();
        {
            float t = b.column(25, 0, 1.8f, 1.0f, 5, ICE);
            b.tri(24.9f, t, 2.0f, 1.4f, ICE);
            b.column(37.2f, 0, 1.8f, 1.0f, 5, ICE);
            b.tri(37.1f, t, 2.0f, 1.4f, ICE);
            for (int r = 0; r < 3; r++) {
                float x = 26.8f, y = r * 0.8f;
                if (r % 2 == 1) {
                    b.box(x, y, 0.65f, 0.8f, ICE);
                    x += 0.65f;
                }
                int k = 0;
                while (x < 37.19f) {
                    float w = Math.min(1.3f, 37.2f - x);
                    b.box(x, y, w, 0.8f, r == 0 && k == 4 ? TNT : ICE);
                    x += w;
                    k++;
                }
            }
            b.box(28f, 2.4f, 0.2f, 1.4f, WOOD);
            b.box(35.8f, 2.4f, 0.2f, 1.4f, WOOD);
            b.box(31.5f, 2.4f, 1.0f, 0.6f, GOLD);
            b.neighbor(15.8f);
        }
        L.add(new LevelDef("Snow Fort", T_WINTER, 4, b.s).obj(O_PROTECT).par(3));

        b = new B();
        {
            float y = b.fillFloor(25, 0, 12, 3.0f, 0.6f, 4, ICE, GLASS, STEEL, 0.5f);
            y = b.glassFloor(26.5f, y, 9, 2.4f, 0.5f, 3, ICE, ICE, 0.45f);
            float t = b.column(26.5f, y, 1.4f, 1.0f, 2, ICE);
            b.tri(26.35f, t, 1.7f, 1.5f, CRYSTAL);
            b.column(34.1f, y, 1.4f, 1.0f, 2, ICE);
            b.tri(33.95f, t, 1.7f, 1.5f, CRYSTAL);
            float y2 = b.storey(29, y, 4, 1.8f, 0.4f, ICE, ICE);
            b.tri(28.8f, y2, 4.4f, 2.0f, GLASS);
            b.box(30.5f, y, 1.0f, 0.6f, GOLD);
        }
        L.add(new LevelDef("Glacier Castle", T_WINTER, 5, b.s).par(3));

        b = new B();
        {
            b.column(29, 0, 1.2f, 1.0f, 3, ICE);
            b.column(32.8f, 0, 1.2f, 1.0f, 3, ICE);
            b.column(26.8f, 0, 1.0f, 5.9f / 6f, 6, ICE);
            b.column(35.2f, 0, 1.0f, 5.9f / 6f, 6, ICE);
            b.box(28.6f, 3.0f, 5.8f, 0.5f, ARMOR);
            b.box(28.6f, 3.5f, 1.2f, 2.4f, ICE);
            b.box(33.2f, 3.5f, 1.2f, 2.4f, ICE);
            b.box(29.8f, 3.5f, 3.4f, 0.8f, ICE);
            b.box(29.8f, 4.3f, 1.1f, 1.0f, ICE);
            b.box(30.9f, 4.3f, 1.2f, 1.0f, CORE);
            b.box(32.1f, 4.3f, 1.1f, 1.0f, ICE);
            b.box(29.8f, 5.3f, 3.4f, 0.6f, ICE);
            b.box(26.8f, 5.9f, 9.4f, 0.6f, ARMOR);
            b.box(30.3f, 6.5f, 2.4f, 1.6f, ICE);
            b.box(31.0f, 8.1f, 1.0f, 0.8f, CORE);
        }
        L.add(new LevelDef("BOSS: Ice Golem", T_WINTER, 7, b.s).boss().wind(-2f).par(5));

        // ================================================================ WORLD 4 · NEON CITY
        b = new B();
        {
            float y = 0;
            for (int i = 0; i < 6; i++) y = b.glassFloor(26f, y, 7f, 2.3f, 0.5f, 3, CONCRETE, CONCRETE, 0.35f);
            b.box(27.0f, y, 1.6f, 1.2f, MAGNET);
            b.box(30.5f, y, 0.3f, 1.6f, STEEL);
        }
        L.add(new LevelDef("Apartment Block", T_NIGHT, 6, b.s).par(4));

        b = new B();
        {
            float y = 0;
            for (int f = 0; f < 4; f++) {
                b.box(25, y, 0.6f, 2.0f, CONCRETE);
                b.box(30.6f, y, 0.6f, 2.0f, CONCRETE);
                b.box(36.2f, y, 0.6f, 2.0f, CONCRETE);
                b.box(26f, y, 1.8f, 0.8f, STEEL);
                b.markLast(F_TARGET);
                b.box(32f, y, 1.8f, 0.8f, f == 1 ? TNT : STEEL);
                if (f != 1) b.markLast(F_TARGET);
                b.box(25, y + 2.0f, 11.8f, 0.4f, CONCRETE);
                y += 2.4f;
            }
            b.box(27f, y, 1.8f, 0.8f, STEEL);
            b.markLast(F_TARGET);
            b.box(33f, y, 1.0f, 0.9f, TNT);
        }
        L.add(new LevelDef("Parking Garage", T_NIGHT, 5, b.s).obj(O_TARGETS).par(3));

        b = new B();
        {
            float h = 3.2f;
            b.box(24, 0, 0.6f, h, BRICK);
            b.window(24.6f, 0, 2.2f, h, BRICK);
            b.box(26.8f, 0, 0.6f, h, BRICK);
            b.window(27.4f, 0, 2.2f, h, BRICK);
            b.box(29.6f, 0, 0.6f, h, BRICK);
            b.window(30.2f, 0, 2.2f, h, BRICK);
            b.box(32.4f, 0, 0.6f, h, BRICK);
            b.box(24, h, 9f, 0.35f, STEEL);
            float y = h + 0.35f;
            y = b.glassFloor(28.6f, y, 4.4f, 2.0f, 0.4f, 2, BRICK, STEEL, 0.3f);
            b.column(34.2f, 0, 1.3f, 1.0f, 9, BRICK);
            b.box(34.2f, 9f, 1.3f, 1.0f, MAGNET);
            b.box(24.6f, y - 2.3f, 1.0f, 1.0f, WOOD);
            b.box(25.8f, y - 2.3f, 1.0f, 1.0f, TNT);
            b.box(25.2f, y - 1.3f, 1.0f, 1.0f, WOOD);
        }
        L.add(new LevelDef("Factory", T_NIGHT, 5, b.s).par(3));

        b = new B();
        {
            float y = b.glassFloor(26, 0, 10, 2.8f, 0.4f, 4, STEEL, STEEL, 0.35f);
            y = b.glassFloor(26, y, 10, 2.4f, 0.4f, 4, STEEL, CONCRETE, 0.4f);
            b.box(27.5f, y, 7f, 1.2f, GLASS);
            b.markLast(F_TARGET);
            b.box(37.0f, 0, 1.0f, 0.9f, TNT);
            b.box(38.2f, 0, 0.6f, 0.4f, GOLD);
            b.markLast(F_TARGET);
        }
        L.add(new LevelDef("Neon Arcade", T_NIGHT, 4, b.s).obj(O_TARGETS).platform(2.0f, 10f).par(3));

        b = new B();
        {
            float cx = 31f;
            float y = b.storey(cx - 2.2f, 0, 4.4f, 3.0f, 0.8f, STONE, STONE);
            b.box(cx - 0.9f, 0, 1.8f, 1.6f, WOOD);
            y = b.column(cx - 1.5f, y, 3.0f, 1.5f, 4, BRICK);
            b.box(cx - 1.7f, y, 3.4f, 2.4f, STONE);
            y += 2.4f;
            b.box(cx - 1.9f, y, 3.8f, 0.3f, STEEL);
            y += 0.3f;
            b.crown(cx, y);
        }
        L.add(new LevelDef("Clock Tower", T_NIGHT, 5, b.s).obj(O_CROWN).par(3));

        b = new B();
        {
            for (int k = 0; k < 2; k++) {
                float x = k == 0 ? 26f : 33.4f, y = 0;
                for (int i = 0; i < 5; i++) y = b.glassFloor(x, y, 3.6f, 2.0f, 0.3f, 2, STEEL, STEEL, 0.3f);
                b.box(x + (k == 0 ? 0.4f : 2.9f), y, 0.2f, 2f, STEEL);
                if (k == 0) b.box(28.8f, y, 5.4f, 0.4f, GLASS);
            }
        }
        L.add(new LevelDef("Twin Spires", T_NIGHT, 5, b.s).time(14).par(4));

        b = new B();
        {
            float y = 0;
            for (int i = 0; i < 3; i++) y = b.storey(25, y, 7, 2.6f, 0.25f, STEEL, WOOD);
            b.box(26, 0, 2, 1.0f, CONCRETE);
            b.box(29, 0, 2, 1.0f, CONCRETE);
            b.box(26, 2.85f, 1.2f, 0.5f, WOOD);
            b.box(26, 3.35f, 1.2f, 0.5f, WOOD);
            b.box(29.5f, 2.85f, 1.4f, 0.9f, BRICK);
            b.box(28.5f, 5.7f, 1.0f, 0.9f, TNT);
            b.box(26.5f, 5.7f, 1.6f, 0.3f, GLASS);
            b.box(34, 0, 3, 0.5f, CONCRETE);
            b.box(34, 0.5f, 3, 0.5f, CONCRETE);
            b.box(34, 1.0f, 3, 0.5f, CONCRETE);
            b.box(34.2f, 1.5f, 2.6f, 0.3f, STEEL);
            b.neighbor(15.8f);
        }
        L.add(new LevelDef("Building Site", T_NIGHT, 5, b.s).obj(O_PROTECT).par(3));

        b = new B();
        {
            float y = 0;
            for (int i = 0; i < 7; i++) y = b.glassFloor(27.5f, y, 6.2f, 2.1f, 0.35f, 3, (i == 2 || i == 4) ? RUBBER : STEEL, STEEL, 0.3f);
            b.box(30.45f, y, 0.3f, 2.6f, STEEL);
        }
        L.add(new LevelDef("Skyscraper", T_NIGHT, 6, b.s).wind(-2f).par(4));

        b = new B();
        {
            float y = 0;
            for (int i = 0; i < 5; i++) y = b.fillFloor(28f, y, 6f, 2.1f, 0.35f, 3, STEEL, SHIELD, STEEL, 0.3f);
            b.box(30.5f, y, 1.0f, 1.0f, CORE);
            b.column(24.5f, 0, 1.2f, 1.0f, 2, STEEL);
            b.box(24.6f, 2f, 1.0f, 1.0f, CORE);
            b.column(37.5f, 0, 1.2f, 1.0f, 3, STEEL);
            b.box(37.6f, 3f, 1.0f, 1.0f, CORE);
        }
        L.add(new LevelDef("BOSS: Mech Tower", T_NIGHT, 8, b.s).boss().wind(2f).par(6));

        // ================================================================ WORLD 5 · LAVA FORTRESS
        b = new B();
        {
            float top = b.column(24, 0, 2.4f, 1.2f, 6, STONE);
            for (int i = 0; i < 3; i++) b.box(24 + i * 0.9f, top, 0.6f, 0.6f, STONE);
            b.column(33.6f, 0, 2.4f, 1.2f, 6, STONE);
            for (int i = 0; i < 3; i++) b.box(33.6f + i * 0.9f, top, 0.6f, 0.6f, STONE);
            for (int r = 0; r < 5; r++) {
                float y = r * 0.9f, x = 26.4f;
                if (r % 2 == 1) {
                    b.box(x, y, 0.6f, 0.9f, STONE);
                    x += 0.6f;
                }
                while (x < 33.59f) {
                    float w = Math.min(1.2f, 33.6f - x);
                    float mid = x + w / 2;
                    boolean gate = r < 2 && mid > 29.0f && mid < 31.0f;
                    b.box(x, y, w, 0.9f, gate ? (r == 0 && mid < 30 ? TNT : WOOD) : STONE);
                    x += w;
                }
            }
            for (int i = 0; i < 6; i++) b.box(26.4f + i * 1.2f + 0.3f, 4.5f, 0.6f, 0.6f, STONE);
        }
        L.add(new LevelDef("Castle", T_LAVA, 6, b.s).quake(10f).par(4));

        b = new B();
        {
            for (int t = 0; t < 4; t++) {
                int n = 10 - 2 * t;
                for (int i = 0; i < n; i++)
                    b.box(24.5f + t * 1.2f + i * 1.2f, t * 1.2f, 1.2f, 1.2f, (t == 0 && (i == 3 || i == 6)) ? TNT : STONE);
            }
            float y = b.storey(28.6f, 4.8f, 3.8f, 1.8f, 0.4f, STONE, STONE);
            b.box(29.9f, 4.8f, 1.2f, 0.6f, GOLD);
            b.crown(30.5f, y);
        }
        L.add(new LevelDef("Volcano Temple", T_LAVA, 5, b.s).obj(O_CROWN).quake(9f).par(3));

        b = new B();
        {
            float cx = 33f;
            float y = b.storey(cx - 3, 0, 6, 2.4f, 0.8f, STONE, STONE);
            b.box(cx - 0.8f, 0, 1.6f, 1.8f, WOOD);
            for (int i = 0; i < 6; i++) {
                b.box(cx - 1.6f, y, 3.2f, 1.2f, i % 3 == 2 ? STEEL : (i == 1 || i == 4 ? CRYSTAL : STONE));
                if (i == 1 || i == 4) b.markLast(F_TARGET);
                y += 1.2f;
            }
            b.box(cx - 2.0f, y, 4.0f, 0.4f, STEEL);
            y += 0.4f;
            b.box(cx - 2.0f, y, 0.6f, 0.7f, STONE);
            b.box(cx + 1.4f, y, 0.6f, 0.7f, STONE);
            b.box(cx - 0.6f, y, 1.2f, 1.0f, GOLD);
            b.markLast(F_TARGET);
        }
        L.add(new LevelDef("Dark Tower", T_LAVA, 5, b.s).obj(O_TARGETS).quake(11f).par(3));

        b = new B();
        {
            float y = b.fillFloor(25, 0, 10, 2.6f, 0.5f, 3, ARMOR, STONE, STEEL, 0.4f);
            y = b.fillFloor(26, y, 8, 2.4f, 0.5f, 3, STEEL, BRICK, STEEL, 0.4f);
            b.tri(25.8f, y, 8.4f, 2.2f, STEEL);
            b.box(36f, 0, 1.0f, 0.9f, TNT);
            b.box(37.2f, 0, 1.0f, 0.9f, TNT);
        }
        L.add(new LevelDef("Iron Keep", T_LAVA, 6, b.s).quake(10f).par(4));

        b = new B();
        {
            b.column(25, 0, 1.6f, 1.2f, 3, STONE);
            b.column(32, 0, 1.6f, 1.2f, 3, STONE);
            b.column(39, 0, 1.6f, 1.2f, 3, STONE);
            b.box(25, 3.6f, 7.8f, 0.4f, STEEL);
            b.box(32.8f, 3.6f, 7.8f, 0.4f, STEEL);
            b.column(25.2f, 4.0f, 1.2f, 1.0f, 3, STONE);
            b.column(39.2f, 4.0f, 1.2f, 1.0f, 3, STONE);
            b.box(29f, 4.0f, 1.6f, 0.8f, WOOD);
            b.box(35f, 4.0f, 1.0f, 0.9f, TNT);
            b.box(30.8f, 4.0f, 0.6f, 0.4f, GOLD);
        }
        L.add(new LevelDef("Lava Bridge", T_LAVA, 5, b.s).time(12).quake(8f).par(3));

        b = new B();
        {
            b.column(25, 0, 2.2f, 1.2f, 5, STONE);
            b.column(34.8f, 0, 2.2f, 1.2f, 5, STONE);
            b.box(27.2f, 0, 2.2f, 4.8f, STONE);
            b.box(29.4f, 0, 3.2f, 3.0f, WOOD);
            b.markLast(F_TARGET);
            b.box(32.6f, 0, 2.2f, 4.8f, STONE);
            b.box(29.4f, 3.0f, 3.2f, 1.8f, STONE);
            b.box(25, 6.0f, 12, 0.6f, STEEL);
            b.tri(28, 6.6f, 6, 2.2f, STONE);
            b.box(25, 6.6f, 0.8f, 0.7f, STONE);
            b.box(36.2f, 6.6f, 0.8f, 0.7f, STONE);
            b.box(37.4f, 0, 1.0f, 0.9f, TNT);
            b.box(38.6f, 0, 0.6f, 0.4f, GOLD);
            b.markLast(F_TARGET);
        }
        L.add(new LevelDef("Dragon Gate", T_LAVA, 6, b.s).obj(O_TARGETS).quake(10f).par(3));

        b = new B();
        {
            float y = b.glassFloor(24.5f, 0, 12f, 3f, 0.6f, 4, STONE, CONCRETE, 0.5f);
            y = b.glassFloor(25.5f, y, 10f, 2.6f, 0.4f, 3, STEEL, STEEL, 0.35f);
            float y3 = y;
            b.box(27f, y, 0.6f, 2.4f, BRICK);
            b.window(27.6f, y, 2.4f, 2.4f, BRICK);
            b.box(30f, y, 0.6f, 2.4f, BRICK);
            b.window(30.6f, y, 2.4f, 2.4f, BRICK);
            b.box(33f, y, 0.6f, 2.4f, BRICK);
            b.box(27f, y + 2.4f, 6.6f, 0.4f, STONE);
            y += 2.8f;
            b.crown(30.3f, y);
            float t = b.column(38f, 0, 2.2f, 1.2f, 7, STONE);
            for (int i = 0; i < 3; i++) b.box(38f + i * 0.8f, t, 0.6f, 0.6f, STONE);
            b.box(25.6f, y3, 0.9f, 0.9f, TNT);
            b.box(34.6f, y3, 0.8f, 0.8f, GOLD);
        }
        L.add(new LevelDef("Mega Fortress", T_LAVA, 7, b.s).obj(O_CROWN).quake(10f).par(5));

        b = new B();
        {
            float y = b.glassFloor(24, 0, 14, 3, 0.6f, 5, STONE, CONCRETE, 0.5f);
            float[] cols = {25f, 28.7f, 32.4f, 36.1f};
            for (float cx : cols) b.box(cx, y, 0.5f, 2.6f, STEEL);
            b.box(25.5f, y, 3.2f, 1.2f, BRICK);
            b.box(25.5f, y + 1.2f, 3.2f, 1.4f, GLASS);
            b.box(29.2f, y, 1.0f, 0.9f, TNT);
            b.box(30.3f, y, 1.0f, 1.0f, WOOD);
            b.box(31.4f, y, 0.9f, 0.5f, GOLD);
            b.box(32.9f, y, 3.2f, 1.2f, BRICK);
            b.box(32.9f, y + 1.2f, 3.2f, 1.4f, GLASS);
            b.box(25f, y + 2.6f, 11.6f, 0.4f, ARMOR);
            y += 3.0f;
            y = b.glassFloor(26.5f, y, 8.6f, 2.4f, 0.4f, 3, STEEL, STONE, 0.4f);
            b.tri(26.3f, y, 9.0f, 2.6f, STONE);
            float t = b.column(39.5f, 0, 2.2f, 1.2f, 7, STONE);
            for (int i = 0; i < 3; i++) b.box(39.5f + i * 0.8f, t, 0.6f, 0.6f, STONE);
            b.box(40.1f, t + 0.6f, 1.0f, 0.6f, GOLD);
        }
        L.add(new LevelDef("Final Citadel", T_LAVA, 8, b.s).quake(9f).par(6));

        b = new B();
        {
            float y = b.fillFloor(24, 0, 14, 3, 0.6f, 5, ARMOR, STONE, STEEL, 0.5f);
            float[] cols = {25f, 29f, 33f, 37f};
            for (float cx : cols) b.box(cx, y, 0.5f, 2.6f, STEEL);
            b.box(25.5f, y, 3.5f, 2.6f, BRICK);
            b.box(29.6f, y, 1.0f, 0.9f, TNT);
            b.box(30.65f, y, 1.2f, 1.2f, CORE);
            b.box(32.0f, y, 0.9f, 0.9f, TNT);
            b.box(33.5f, y, 3.5f, 2.6f, BRICK);
            b.box(25f, y + 2.6f, 12.5f, 0.4f, STEEL);
            y += 3.0f;
            float y2 = b.storey(27, y, 8, 2.2f, 0.5f, ARMOR, STONE);
            b.box(30.4f, y, 1.2f, 1.2f, CORE);
            b.tri(26.8f, y2, 8.4f, 2.4f, STONE);
            float t = b.column(39.5f, 0, 2.0f, 1.2f, 6, STONE);
            b.box(40.0f, t, 1.0f, 1.0f, CORE);
        }
        L.add(new LevelDef("BOSS: Dragon Citadel", T_LAVA, 9, b.s).boss().regen(8f).quake(12f).par(7));

        // ================================================================ WORLD 6 · CHAOS LAB (combo levels)
        b = new B();
        {
            b.box(27f, 0, 0.8f, 2.6f, ARMOR);
            b.box(33.2f, 0, 0.8f, 2.6f, ARMOR);
            b.box(27f, 2.6f, 7f, 0.8f, ARMOR);
            b.box(28.5f, 0, 1.2f, 1.2f, CORE);
            b.box(31.3f, 0, 1.2f, 1.2f, CORE);
            b.box(30.0f, 0, 0.8f, 1.0f, GLASS);
            b.box(27.2f, 3.4f, 1.2f, 1.0f, STEEL);
            b.box(32.6f, 3.4f, 1.2f, 1.0f, STEEL);
            b.box(29.4f, 3.4f, 2.2f, 0.8f, ARMOR);
        }
        L.add(new LevelDef("Blast Jump", T_LAB, 2, b.s).obj(O_CORES).exactPar(2)
                .hint("PLAN: TNT BLOWS THE ROOF OFF, A SAFE FOLLOWS RIGHT BEHIND"));

        b = new B();
        {
            b.column(25.2f, 0, 1.0f, 2.0f, 4, ARMOR);
            float y = b.fillFloor(29f, 0, 4f, 2.4f, 0.5f, 2, ARMOR, STEEL, ARMOR, 0.4f);
            y = b.fillFloor(29.3f, y, 3.4f, 2.2f, 0.45f, 2, ARMOR, CONCRETE, ARMOR, 0.4f);
            y = b.fillFloor(29.6f, y, 2.8f, 2.0f, 0.4f, 2, STEEL, CONCRETE, STEEL, 0.35f);
            b.crown(31f, y);
        }
        L.add(new LevelDef("Iron Curtain", T_LAB, 2, b.s).obj(O_CROWN).wind(-4f).exactPar(2)
                .hint("HEADWIND! LET TNT BLAST A HEAVY SHOT OVER THE WALL"));

        b = new B();
        {
            float y = 0;
            for (int f = 0; f < 3; f++) {
                b.box(26f, y, 0.5f, 2.2f, STEEL);
                b.box(30.75f, y, 0.5f, 2.2f, STEEL);
                b.box(35.5f, y, 0.5f, 2.2f, STEEL);
                b.box(28.1f, y, 1.2f, 1.2f, f == 1 ? CORE : CONCRETE);
                b.box(32.9f, y, 1.2f, 1.2f, f == 0 || f == 2 ? CORE : CONCRETE);
                b.box(26f, y + 2.2f, 10f, 0.4f, ARMOR);
                y += 2.6f;
            }
        }
        L.add(new LevelDef("Reactor Core", T_LAB, 4, b.s).obj(O_CORES).superRegen(4f, 0.4f, 12).quake(7f).exactPar(3)
                .hint("IT HEALS EVERY 4 SECONDS - HIT IT ALL AT ONCE WITH A COMBO"));

        b = new B();
        {
            for (int k = 0; k < 3; k++) {
                float x = 25f + k * 5.5f;
                float t = b.column(x, 0, 1.6f, 1.1f, 4 + k, k == 1 ? STEEL : STONE);
                b.box(x + 0.45f, t, 0.7f, 0.7f, GOLD);
                b.markLast(F_TARGET);
            }
            b.box(28.8f, 0, 1.6f, 0.8f, ARMOR);
            b.box(34.3f, 0, 1.6f, 0.8f, ARMOR);
        }
        L.add(new LevelDef("Seismic Lab", T_LAB, 2, b.s).obj(O_TARGETS).quake(5f).wind(3f).exactPar(2)
                .hint("THREE TARGETS, TWO SHOTS: ONE BLAST MUST CARRY A SHOT ACROSS"));

        b = new B();
        {
            b.box(26.8f, 0, 1.0f, 3f, SHIELD);
            b.box(33.2f, 0, 1.0f, 3f, ARMOR);
            b.box(26.8f, 3f, 7.4f, 0.6f, SHIELD);
            b.box(27.3f, 3.6f, 6.4f, 0.6f, ARMOR);
            b.box(28.2f, 0, 1.0f, 1.0f, GOLD);
            b.markLast(F_TARGET);
            b.box(29.8f, 0, 1.0f, 1.6f, GLASS);
            b.markLast(F_TARGET);
            b.box(31.5f, 0, 1.2f, 1.0f, GOLD);
            b.markLast(F_TARGET);
        }
        L.add(new LevelDef("Moving Vault", T_LAB, 2, b.s).obj(O_TARGETS).platform(2f, 8f).exactPar(2)
                .hint("A SEALED ARMOR VAULT ON WHEELS. BLAST IT OPEN, THEN STRIKE"));

        b = new B();
        {
            float y = 0;
            for (int f = 0; f < 4; f++) y = b.storey(27.5f, y, 4f, 2.1f, 0.35f, f % 2 == 0 ? BRICK : WOOD, WOOD);
            b.tri(27.3f, y, 4.4f, 1.6f, BRICK);
            b.box(29f, 0, 1.0f, 0.9f, TNT);
            b.neighbor(15.8f);
            int start = b.s.size();
            float yy = b.storey(36.5f, 0, 3, 1.6f, 0.25f, WOOD, WOOD);
            b.box(37.35f, 0, 1.3f, 0.9f, GLASS);
            b.tri(36.3f, yy, 3.4f, 1.0f, BRICK);
            for (int i = start; i < b.s.size(); i++) b.s.get(i).flags |= F_PROTECT;
        }
        L.add(new LevelDef("Two Neighbors", T_LAB, 3, b.s).obj(O_PROTECT).wind(2f).exactPar(2)
                .hint("NEIGHBORS ON BOTH SIDES - MAKE IT FALL STRAIGHT DOWN"));

        b = new B();
        {
            float y = b.fillFloor(25f, 0, 12f, 3f, 0.6f, 4, STEEL, CONCRETE, ARMOR, 0.5f);
            y = b.fillFloor(26f, y, 10f, 2.6f, 0.5f, 3, STEEL, BRICK, STEEL, 0.4f);
            b.fillFloor(27f, y, 8f, 2.2f, 0.4f, 3, STEEL, GLASS, STEEL, 0.35f);
        }
        L.add(new LevelDef("Countdown", T_LAB, 3, b.s).time(7f).exactPar(2)
                .hint("ONLY 7 SECONDS - FIRE A PLANNED 3-SHOT COMBO"));

        b = new B();
        {
            float t = b.column(29.5f, 0, 2.0f, 1.4f, 3, STEEL);
            cage(b, 30.5f, t);
            float t2 = b.column(35f, 0, 2.0f, 1.0f, 5, ARMOR);
            cage(b, 36f, t2);
            b.column(25f, 0, 0.7f, 2f, 3, SHIELD);
        }
        L.add(new LevelDef("Shield Wall", T_LAB, 4, b.s).obj(O_CORES).superRegen(5f, 0.35f, 10).wind(-2f).exactPar(3)
                .hint("SHIELD CAGES CAN'T BE BROKEN - BUT A BLAST CAN THROW THEM AWAY"));

        b = new B();
        {
            float[] cols = {24.5f, 28.65f, 32.8f, 36.95f};
            for (float cx : cols) b.box(cx, 0, 0.7f, 3f, ARMOR);
            b.box(25.25f, 0, 0.5f, 3f, SHIELD);
            b.box(26.3f, 0, 1.2f, 1.2f, CORE);
            b.box(27.6f, 0, 1.0f, 1.5f, STONE);
            b.box(29.4f, 0, 3.35f, 1.4f, CRYSTAL);
            b.box(33.55f, 0, 0.5f, 3f, SHIELD);
            b.box(34.7f, 0, 1.2f, 1.2f, CORE);
            b.box(24.5f, 3f, 13.15f, 0.5f, ARMOR);
            float[] c2 = {25.5f, 30.8f, 36.1f};
            for (float cx : c2) b.box(cx, 3.5f, 0.5f, 2.6f, STEEL);
            b.box(26.0f, 3.5f, 0.5f, 2.6f, SHIELD);
            b.box(28.0f, 3.5f, 1.2f, 1.2f, CORE);
            b.box(33.0f, 3.5f, 1.2f, 1.2f, STONE);
            b.box(25.5f, 6.1f, 11.1f, 0.5f, ARMOR);
            cage(b, 30.8f, 6.6f);
            b.box(38.5f, 0, 1.0f, 0.9f, TNT);
            b.box(39.7f, 0, 1.0f, 0.9f, TNT);
        }
        L.add(new LevelDef("BOSS: The Regenerator", T_LAB, 7, b.s).boss().superRegen(3.5f, 0.5f, 14).quake(9f).wind(2f).exactPar(5)
                .hint("HEALS EVERY 3.5s. CHAIN TNT INTO HEAVY STUFF!"));

        return L.toArray(new LevelDef[0]);
    }

    // ---------------------------------------------------------------- tiny utils
    static int shade(int c, float f) {
        int a = c >>> 24, r = (c >> 16) & 255, g = (c >> 8) & 255, bl = c & 255;
        if (f >= 1f) {
            float t = f - 1f;
            r += (int) ((255 - r) * t); g += (int) ((255 - g) * t); bl += (int) ((255 - bl) * t);
        } else {
            r = (int) (r * f); g = (int) (g * f); bl = (int) (bl * f);
        }
        return (a << 24) | (clamp255(r) << 16) | (clamp255(g) << 8) | clamp255(bl);
    }

    static int withAlpha(int c, int a) {
        return (c & 0xFFFFFF) | (Math.max(0, Math.min(255, a)) << 24);
    }

    private static int clamp255(int v) {
        return v < 0 ? 0 : (v > 255 ? 255 : v);
    }

    /** Deterministic pseudo random in [0,1) for a seed and index. */
    static float hash(int seed, int i) {
        int h = seed * 374761393 + i * 668265263;
        h = (h ^ (h >>> 13)) * 1274126177;
        h ^= h >>> 16;
        return (h & 0xFFFFFF) / 16777216f;
    }
}
