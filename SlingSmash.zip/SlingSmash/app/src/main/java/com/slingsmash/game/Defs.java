package com.slingsmash.game;

import java.util.ArrayList;

/** Static game data: materials, ammo, sounds, worlds and all 40 buildings. Pure Java (no Android). */
final class Defs {
    private Defs() {}

    // ---------------------------------------------------------------- materials
    static final int WOOD = 0, GLASS = 1, BRICK = 2, STONE = 3, CONCRETE = 4, STEEL = 5, ICE = 6, TNT = 7, GOLD = 8;
    static final int NUM_MATS = 9;
    static final String[] MAT_NAME = {"Wood", "Glass", "Brick", "Stone", "Concrete", "Steel", "Ice", "TNT", "Gold"};
    static final int[] MAT_COLOR = {0xFFCB8A4E, 0xFF8FD3F0, 0xFFC4553D, 0xFFA3A1AC, 0xFFC9C3B5, 0xFF6F7E8E, 0xFFBFEAFF, 0xFFE0402F, 0xFFFFC93C};
    static final float[] MAT_DENSITY = {0.7f, 1.0f, 1.8f, 2.4f, 2.1f, 3.4f, 0.9f, 0.8f, 3.0f};
    static final float[] MAT_HP = {100f, 28f, 190f, 330f, 270f, 620f, 50f, 35f, 150f};
    static final float[] MAT_FRICTION = {0.75f, 0.35f, 0.8f, 0.85f, 0.8f, 0.55f, 0.12f, 0.7f, 0.6f};
    static final int[] MAT_POINTS = {100, 150, 200, 250, 220, 400, 160, 300, 500};

    // ---------------------------------------------------------------- sounds
    static final int S_LAUNCH = 0, S_WOOD = 1, S_GLASS = 2, S_STONE = 3, S_METAL = 4, S_BOOM = 5,
            S_PIANO = 6, S_SPLAT = 7, S_CLICK = 8, S_STAR = 9, S_THUD = 10, S_WIN = 11, S_STRETCH = 12, S_HONK = 13,
            S_MOO = 14, S_FREEZE = 15, S_VORTEX = 16, S_COIN = 17, S_POP = 18, S_ROCKET = 19;
    static final int NUM_SOUNDS = 20;
    static final int[] MAT_BREAK_SOUND = {S_WOOD, S_GLASS, S_STONE, S_STONE, S_STONE, S_METAL, S_GLASS, S_BOOM, S_COIN};

    // ---------------------------------------------------------------- ammo
    static final int A_BRICK = 0, A_BOWLING = 1, A_MELON = 2, A_ANVIL = 3, A_CAR = 4, A_PIANO = 5,
            A_TNT = 6, A_WRECK = 7, A_FRIDGE = 8, A_BOULDER = 9, A_CANNON = 10, A_TIRE = 11, A_SAFE = 12,
            A_COW = 13, A_BUS = 14, A_CLUSTER = 15, A_ROCKET = 16, A_FREEZE = 17, A_HOLE = 18, A_METEOR = 19,
            A_MINI = 20;
    static final int NUM_AMMO = 20;
    static final String[] AMMO_NAME = {"Brick", "Bowling Ball", "Watermelon", "Anvil", "Car", "Piano",
            "TNT Barrel", "Wrecking Ball", "Fridge", "Boulder", "Cannonball", "Tire", "Safe", "Cow", "Bus",
            "Cluster Bomb", "Rocket", "Freeze Bomb", "Black Hole", "Meteor", "Bomblet"};
    static final String[] AMMO_DESC = {
            "Cheap, reliable and surprisingly rude. The classic.",
            "Strike! Rolls through glass like it is not even there.",
            "Explodes into juicy chaos on impact. Messy but fun.",
            "Cartoon physics approved. Heavy, heavy, heavy.",
            "A whole car. Honks as it flies. Insurance not included.",
            "Plays one last dramatic chord on impact.",
            "Boom on impact. Tap mid-air to detonate early!",
            "Massive steel sphere. Flattens anything in its path.",
            "Tall, cold and full of leftovers.",
            "A big rock. Sometimes the simple answer is the right one.",
            "Small, dense and very fast. Punches straight through.",
            "Super bouncy! Ricochets around the building.",
            "Ridiculously heavy for its size. Gravity loves it.",
            "Moo. Somewhere a farmer is very confused.",
            "The biggest thing you can fit in a slingshot.",
            "Tap mid-air to split into four bomblets!",
            "Tap mid-air to fire the booster. Explodes on impact.",
            "Freezes everything around it. Frozen blocks shatter!",
            "Tap to open a tiny black hole that sucks the building in.",
            "A burning space rock. Huge explosion on impact.",
            ""};
    static final int SH_BOX = 0, SH_CIRCLE = 1, SH_POLY = 2;
    static final int[] AMMO_SHAPE = {SH_BOX, SH_CIRCLE, SH_CIRCLE, SH_POLY, SH_BOX, SH_BOX, SH_BOX, SH_CIRCLE, SH_BOX, SH_POLY,
            SH_CIRCLE, SH_CIRCLE, SH_BOX, SH_BOX, SH_BOX, SH_CIRCLE, SH_BOX, SH_CIRCLE, SH_CIRCLE, SH_CIRCLE, SH_CIRCLE};
    /** box: half width, half height. circle: radius. poly: bounding radius. */
    static final float[][] AMMO_SIZE = {{0.5f, 0.24f}, {0.48f}, {0.58f}, {0.85f}, {1.3f, 0.48f}, {1.0f, 0.72f},
            {0.45f, 0.58f}, {0.92f}, {0.52f, 0.98f}, {0.8f}, {0.42f}, {0.6f}, {0.6f, 0.6f}, {1.0f, 0.55f}, {2.4f, 0.78f},
            {0.5f}, {0.95f, 0.26f}, {0.52f}, {0.48f}, {0.75f}, {0.28f}};
    static final float[] AMMO_DENSITY = {3f, 6f, 1.6f, 9f, 2.6f, 3.4f, 2f, 7f, 2.8f, 4.5f,
            14f, 1.4f, 15f, 2f, 2.1f, 4f, 3f, 3f, 3f, 8f, 6f};
    static final float[] AMMO_RESTITUTION = {0.1f, 0.2f, 0.05f, 0.05f, 0.15f, 0.08f, 0.1f, 0.12f, 0.1f, 0.08f,
            0.12f, 0.82f, 0.05f, 0.2f, 0.1f, 0.1f, 0.05f, 0.1f, 0.1f, 0.05f, 0.1f};
    static final int[] AMMO_PRICE = {0, 0, 0, 0, 0, 0, 0, 1200, 600, 800, 900, 700, 2000, 1500, 2500,
            3000, 3500, 4000, 6000, 5000};
    static final int CAT_HEAVY = 1, CAT_EXPLOSIVE = 2, CAT_SPECIAL = 3;
    static final int[] AMMO_CAT = {CAT_HEAVY, CAT_HEAVY, CAT_SPECIAL, CAT_HEAVY, CAT_HEAVY, CAT_HEAVY, CAT_EXPLOSIVE,
            CAT_HEAVY, CAT_HEAVY, CAT_HEAVY, CAT_HEAVY, CAT_SPECIAL, CAT_HEAVY, CAT_SPECIAL, CAT_HEAVY,
            CAT_EXPLOSIVE, CAT_EXPLOSIVE, CAT_SPECIAL, CAT_SPECIAL, CAT_EXPLOSIVE};
    /** weight, power, chaos (0..1) for the armory. */
    static final float[][] AMMO_STATS = {
            {0.2f, 0.25f, 0.1f}, {0.45f, 0.4f, 0.2f}, {0.15f, 0.15f, 0.5f}, {0.75f, 0.6f, 0.2f}, {0.6f, 0.7f, 0.4f},
            {0.6f, 0.6f, 0.5f}, {0.15f, 0.75f, 0.7f}, {0.95f, 0.85f, 0.3f}, {0.5f, 0.55f, 0.3f}, {0.6f, 0.55f, 0.2f},
            {0.55f, 0.6f, 0.2f}, {0.15f, 0.35f, 0.8f}, {1.0f, 0.75f, 0.2f}, {0.35f, 0.45f, 0.75f}, {1.0f, 1.0f, 0.6f},
            {0.3f, 0.85f, 0.9f}, {0.25f, 0.8f, 0.85f}, {0.3f, 0.7f, 0.85f}, {0.2f, 0.95f, 1.0f}, {0.8f, 0.95f, 0.8f}};
    /** Specials that react to a tap while flying. */
    static boolean tappable(int t) {
        return t == A_TNT || t == A_CLUSTER || t == A_ROCKET || t == A_FREEZE || t == A_HOLE;
    }

    static final String[] TAP_HINT = new String[NUM_AMMO];

    static {
        TAP_HINT[A_TNT] = "TAP TO DETONATE!";
        TAP_HINT[A_CLUSTER] = "TAP TO SPLIT!";
        TAP_HINT[A_ROCKET] = "TAP TO BOOST!";
        TAP_HINT[A_FREEZE] = "TAP TO FREEZE!";
        TAP_HINT[A_HOLE] = "TAP FOR BLACK HOLE!";
    }

    static final float[] ANVIL_POLY = {-0.45f, -0.42f, 0.45f, -0.42f, 0.85f, 0.28f, 0.85f, 0.42f, -0.85f, 0.42f, -0.85f, 0.28f};
    static final float[] BOULDER_POLY;

    static {
        float[] r = {0.8f, 0.7f, 0.78f, 0.68f, 0.8f, 0.72f, 0.76f, 0.69f};
        BOULDER_POLY = new float[16];
        for (int i = 0; i < 8; i++) {
            double a = i * Math.PI / 4 + 0.2;
            BOULDER_POLY[i * 2] = (float) (Math.cos(a) * r[i]);
            BOULDER_POLY[i * 2 + 1] = (float) (Math.sin(a) * r[i]);
        }
    }

    // ---------------------------------------------------------------- themes / worlds
    static final int T_DAY = 0, T_SUNSET = 1, T_NIGHT = 2, T_WINTER = 3, T_DESERT = 4, T_LAVA = 5;
    static final int NUM_THEMES = 6;
    static final String[] WORLD_NAME = {"Countryside", "Desert Ruins", "Frozen Peaks", "Neon City", "Lava Fortress"};
    static final int[] WORLD_THEME = {T_DAY, T_DESERT, T_WINTER, T_NIGHT, T_LAVA};
    static final int LEVELS_PER_WORLD = 8;

    // ---------------------------------------------------------------- building specs
    static final class Spec {
        final float x, y, w, h; // centre + size (for polygons: body position, w/h = bounds)
        final int mat;
        final float[] verts; // local polygon (CCW) or null for a box

        Spec(float x, float y, float w, float h, int mat, float[] verts) {
            this.x = x; this.y = y; this.w = w; this.h = h; this.mat = mat; this.verts = verts;
        }
    }

    static final class LevelDef {
        final String name;
        final int theme, shots;
        final ArrayList<Spec> specs;

        LevelDef(String name, int theme, int shots, ArrayList<Spec> specs) {
            this.name = name; this.theme = theme; this.shots = shots; this.specs = specs;
        }
    }

    /** Small helper for building structures. (x, y) is always the bottom-left corner. */
    static final class B {
        final ArrayList<Spec> s = new ArrayList<>();

        void box(float x, float y, float w, float h, int m) {
            s.add(new Spec(x + w / 2f, y + h / 2f, w, h, m, null));
        }

        /** Isosceles triangle, base from x to x+w at height y. */
        void tri(float x, float y, float w, float h, int m) {
            float cx = x + w / 2f, cy = y + h / 3f;
            s.add(new Spec(cx, cy, w, h, m, new float[]{-w / 2f, -h / 3f, w / 2f, -h / 3f, 0f, h * 2f / 3f}));
        }

        /** Two walls + slab on top. Returns the top y. */
        float storey(float x, float y, float w, float h, float t, int wall, int slab) {
            box(x, y, t, h, wall);
            box(x + w - t, y, t, h, wall);
            box(x, y + h, w, t, slab);
            return y + h + t;
        }

        /** Columns at both ends (+ middle), panes of fill material in between, slab on top. */
        float fillFloor(float x, float y, float w, float h, float colW, int cols, int colMat, int fill, int slabMat, float slabT) {
            float gap = (w - cols * colW) / (cols - 1);
            for (int i = 0; i < cols; i++) {
                float cx = x + i * (colW + gap);
                box(cx, y, colW, h, colMat);
                if (i < cols - 1) box(cx + colW, y, gap, h, fill);
            }
            box(x, y + h, w, slabT, slabMat);
            return y + h + slabT;
        }

        float glassFloor(float x, float y, float w, float h, float colW, int cols, int colMat, int slabMat, float slabT) {
            return fillFloor(x, y, w, h, colW, cols, colMat, GLASS, slabMat, slabT);
        }

        /** Wall section with a window: sill, glass, lintel. */
        void window(float x, float y, float w, float h, int mat) {
            box(x, y, w, h * 0.28f, mat);
            box(x, y + h * 0.28f, w, h * 0.5f, GLASS);
            box(x, y + h * 0.78f, w, h * 0.22f, mat);
        }

        /** Vertical stack of equal blocks. */
        float column(float x, float y, float w, float bh, int n, int m) {
            for (int i = 0; i < n; i++) box(x, y + i * bh, w, bh, m);
            return y + n * bh;
        }

        /** Stepped pyramid. Returns top y. */
        float pyramid(float x0, float y0, int rows, float bw, float bh, int m) {
            for (int r = 0; r < rows; r++) {
                int n = rows - r;
                float x = x0 + r * bw / 2f;
                for (int i = 0; i < n; i++) box(x + i * bw, y0 + r * bh, bw, bh, m);
            }
            return y0 + rows * bh;
        }
    }

    static final LevelDef[] LEVELS = buildLevels();

    static int worldOf(int level) { return level / LEVELS_PER_WORLD; }

    private static LevelDef[] buildLevels() {
        ArrayList<LevelDef> L = new ArrayList<>();
        B b;

        // ================================================================ WORLD 1 · COUNTRYSIDE
        b = new B();
        {
            float y = b.storey(26, 0, 6, 2.8f, 0.4f, WOOD, WOOD);
            b.box(26.6f, 0, 1.1f, 1.1f, WOOD);
            b.box(26.6f, 1.1f, 1.1f, 1.1f, WOOD);
            b.box(30.0f, 0, 1.2f, 1.2f, WOOD);
            y = b.storey(26.8f, y, 4.4f, 2.2f, 0.35f, WOOD, WOOD);
            b.tri(26.3f, y, 5.4f, 1.8f, WOOD);
        }
        L.add(new LevelDef("Wooden Shack", T_DAY, 4, b.s));

        b = new B();
        {
            float y = b.glassFloor(25, 0, 9, 2.6f, 0.25f, 4, STEEL, GLASS, 0.25f);
            y = b.glassFloor(26.2f, y, 6.6f, 2.0f, 0.22f, 3, STEEL, GLASS, 0.22f);
            b.tri(25.9f, y, 7.2f, 2.0f, GLASS);
        }
        L.add(new LevelDef("Glass Greenhouse", T_DAY, 4, b.s));

        b = new B();
        {
            float y = 0;
            for (int f = 0; f < 2; f++) {
                float h = 2.6f;
                b.box(25, y, 0.6f, h, BRICK);
                b.window(25.6f, y, 2.0f, h, BRICK);
                b.box(27.6f, y, 0.6f, h, BRICK);
                if (f == 0) {
                    b.box(28.2f, y, 1.6f, 2.0f, WOOD);
                    b.box(28.2f, y + 2.0f, 1.6f, 0.6f, BRICK);
                } else b.window(28.2f, y, 1.6f, h, BRICK);
                b.box(29.8f, y, 0.6f, h, BRICK);
                b.window(30.4f, y, 2.0f, h, BRICK);
                b.box(32.4f, y, 0.6f, h, BRICK);
                b.box(25, y + h, 8f, 0.35f, WOOD);
                y += h + 0.35f;
            }
            b.tri(24.6f, y, 8.8f, 2.6f, BRICK);
        }
        L.add(new LevelDef("Brick House", T_DAY, 5, b.s));

        b = new B();
        {
            for (int i = 0; i < 12; i++) b.box(24 + i * 1.45f, 0, 0.45f, 3.6f, i % 3 == 2 ? STONE : WOOD);
            b.column(42.0f, 0, 1.2f, 1.0f, 4, BRICK);
            b.column(43.2f, 0, 1.2f, 1.0f, 4, BRICK);
            b.box(41.8f, 4.0f, 2.8f, 0.4f, WOOD);
            b.tri(41.8f, 4.4f, 2.8f, 1.4f, WOOD);
        }
        L.add(new LevelDef("Domino Row", T_DAY, 3, b.s));

        b = new B();
        {
            float y = 0;
            for (int i = 0; i < 4; i++) y = b.storey(29, y, 3.4f, 2.3f, 0.5f, WOOD, WOOD);
            b.box(28.5f, y, 4.4f, 0.35f, WOOD);
            y += 0.35f;
            b.box(28.6f, y, 0.25f, 0.9f, WOOD);
            b.box(32.65f, y, 0.25f, 0.9f, WOOD);
            y = b.storey(29.3f, y, 2.8f, 2.0f, 0.3f, WOOD, WOOD);
            b.tri(28.9f, y, 3.6f, 1.6f, WOOD);
            b.box(30.1f, 0, 1.2f, 0.9f, TNT);
        }
        L.add(new LevelDef("Watchtower", T_DAY, 4, b.s));

        b = new B();
        {
            float y = 0;
            for (int i = 0; i < 16; i++) {
                if (i % 2 == 0) {
                    b.box(28.5f, y, 1.0f, 0.55f, WOOD);
                    b.box(29.5f, y, 1.0f, 0.55f, WOOD);
                    b.box(30.5f, y, 1.0f, 0.55f, WOOD);
                } else b.box(28.5f, y, 3.0f, 0.55f, WOOD);
                y += 0.55f;
            }
            b.box(29.25f, y, 1.5f, 1.5f, GOLD);
        }
        L.add(new LevelDef("Jenga Tower", T_DAY, 4, b.s));

        b = new B();
        {
            float y = b.storey(25, 0, 9, 3.2f, 0.5f, WOOD, WOOD);
            for (int i = 0; i < 3; i++) b.box(25.7f + i * 1.3f, 0, 1.2f, 1.0f, WOOD);
            b.box(26.3f, 1.0f, 1.2f, 1.0f, WOOD);
            b.box(31.4f, 0, 1.0f, 2.2f, WOOD);
            y = b.storey(26.2f, y, 6.6f, 2.2f, 0.4f, WOOD, WOOD);
            b.box(28.6f, 3.7f, 1.8f, 1.2f, WOOD);
            b.tri(25.0f, y, 9.0f, 3.0f, BRICK);
        }
        L.add(new LevelDef("Red Barn", T_DAY, 5, b.s));

        b = new B();
        {
            float cx = 37f, y = 0;
            float[] w = {2.8f, 2.5f, 2.2f, 1.9f};
            for (int i = 0; i < w.length; i++) {
                b.box(cx - w[i] / 2, y, w[i], 1.6f, i % 2 == 0 ? BRICK : CONCRETE);
                y += 1.6f;
            }
            b.tri(cx - 1.4f, y, 2.8f, 2.0f, WOOD);
            float t = b.storey(25, 0, 5, 2.4f, 0.35f, WOOD, WOOD);
            b.tri(24.8f, t, 5.4f, 1.4f, BRICK);
            b.box(25.6f, 0, 1.0f, 1.0f, WOOD);
            b.box(28.0f, 0, 1.1f, 1.1f, WOOD);
            b.box(26.8f, 0, 0.6f, 0.4f, GOLD);
            b.box(31.2f, 0, 1.2f, 0.9f, WOOD);
            b.box(31.2f, 0.9f, 1.2f, 0.9f, WOOD);
            b.box(32.6f, 0, 1.0f, 0.9f, TNT);
        }
        L.add(new LevelDef("Windmill Farm", T_DAY, 5, b.s));

        // ================================================================ WORLD 2 · DESERT RUINS
        b = new B();
        {
            float top = b.pyramid(26, 0, 8, 1.5f, 1.0f, STONE);
            b.box(26 + 3.5f * 1.5f + 0.25f, top, 1.0f, 0.7f, GOLD);
        }
        L.add(new LevelDef("Pyramid", T_DESERT, 5, b.s));

        b = new B();
        {
            b.storey(24, 0, 3, 2.2f, 0.25f, WOOD, WOOD);
            b.box(24.5f, 0, 0.9f, 0.7f, WOOD);
            b.box(25.6f, 0, 0.6f, 0.6f, GLASS);
            float y = b.storey(28, 0, 6, 2.6f, 0.6f, STONE, STONE);
            b.box(30.3f, 0, 1.2f, 1.0f, TNT);
            b.box(29.0f, 0, 0.9f, 0.9f, WOOD);
            y = b.storey(28.8f, y, 4.4f, 2.2f, 0.5f, STONE, WOOD);
            b.tri(28.6f, y, 4.8f, 1.8f, STONE);
            b.storey(35.5f, 0, 3, 2.2f, 0.25f, WOOD, WOOD);
            b.box(36.1f, 0, 0.5f, 0.8f, GLASS);
            b.box(36.8f, 0, 0.5f, 0.8f, GLASS);
            b.box(37.5f, 0, 0.5f, 0.3f, GOLD);
        }
        L.add(new LevelDef("Desert Bazaar", T_DESERT, 4, b.s));

        b = new B();
        {
            b.box(24, 0, 11, 0.4f, STONE);
            b.box(24.4f, 0.4f, 10.2f, 0.4f, STONE);
            b.box(24.8f, 0.8f, 9.4f, 0.4f, STONE);
            for (int i = 0; i < 5; i++) {
                float cx = 25.2f + i * 2.05f;
                b.box(cx, 1.2f, 0.7f, 2.2f, STONE);
                b.box(cx, 3.4f, 0.7f, 2.2f, STONE);
                b.box(cx - 0.15f, 5.6f, 1.0f, 0.3f, STONE);
            }
            b.box(24.8f, 5.9f, 9.4f, 0.6f, STONE);
            b.tri(24.6f, 6.5f, 9.8f, 1.8f, STONE);
            b.box(26.3f, 1.2f, 0.5f, 0.5f, GOLD);
            b.box(32.4f, 1.2f, 0.5f, 0.5f, GOLD);
        }
        L.add(new LevelDef("Greek Temple", T_DESERT, 5, b.s));

        b = new B();
        {
            b.column(27, 0, 1.4f, 1.0f, 4, STONE);
            b.column(35.6f, 0, 1.4f, 1.0f, 4, STONE);
            b.box(27, 4, 10, 0.8f, STONE);
            b.box(28, 4.8f, 8, 0.7f, STONE);
            b.box(29.5f, 5.5f, 5, 0.6f, STONE);
            b.tri(29.3f, 6.1f, 5.4f, 1.4f, STONE);
            b.box(31.6f, 0, 0.8f, 0.5f, GOLD);
            b.box(31.8f, 0.5f, 0.4f, 0.3f, GOLD);
            b.box(29.5f, 0, 0.5f, 0.9f, GLASS);
            b.box(33.8f, 0, 0.5f, 0.9f, GLASS);
        }
        L.add(new LevelDef("Sandstone Arch", T_DESERT, 4, b.s));

        b = new B();
        {
            b.column(25.0f, 0, 1.6f, 1.0f, 4, STONE);
            b.column(31.0f, 0, 1.6f, 1.0f, 4, STONE);
            b.column(37.0f, 0, 1.6f, 1.0f, 4, STONE);
            b.box(25.0f, 4f, 6.8f, 0.5f, CONCRETE);
            b.box(31.8f, 4f, 6.8f, 0.5f, CONCRETE);
            b.box(26.0f, 4.5f, 2.2f, 1.0f, STEEL);
            b.box(29.0f, 4.5f, 1.0f, 1.0f, WOOD);
            b.box(29.0f, 5.5f, 1.0f, 1.0f, TNT);
            float y = b.storey(33.0f, 4.5f, 2.8f, 1.8f, 0.3f, WOOD, WOOD);
            b.tri(32.8f, y, 3.2f, 1.2f, BRICK);
            b.box(36.5f, 4.5f, 1.8f, 0.9f, STEEL);
        }
        L.add(new LevelDef("Stone Bridge", T_DESERT, 5, b.s));

        b = new B();
        {
            float cx = 33f;
            float y = b.storey(cx - 2.5f, 0, 5, 2.4f, 0.5f, STONE, STONE);
            b.box(cx - 0.6f, 0, 1.2f, 1.8f, WOOD);
            y = b.column(cx - 1.3f, y, 2.6f, 1.4f, 4, STONE);
            b.box(cx - 2.0f, y, 4.0f, 0.35f, WOOD);
            y += 0.35f;
            b.box(cx - 1.95f, y, 0.2f, 0.8f, WOOD);
            b.box(cx + 1.75f, y, 0.2f, 0.8f, WOOD);
            b.box(cx - 0.75f, y, 1.5f, 1.4f, GLASS);
            y = b.storey(cx - 1.0f, y, 2.0f, 1.4f, 0.25f, STONE, STONE);
            b.tri(cx - 1.2f, y, 2.4f, 1.6f, GOLD);
            b.box(26.0f, 0, 1.1f, 1.1f, WOOD);
            b.box(27.2f, 0, 1.0f, 0.9f, TNT);
        }
        L.add(new LevelDef("Oasis Tower", T_DESERT, 4, b.s));

        b = new B();
        {
            float t1 = b.pyramid(24.5f, 0, 5, 1.2f, 0.9f, STONE);
            b.box(24.5f + 2.4f + 0.2f, t1, 0.8f, 0.5f, GOLD);
            float t2 = b.pyramid(33f, 0, 6, 1.2f, 0.9f, STONE);
            b.box(33f + 3.0f + 0.2f, t2, 0.8f, 0.5f, GOLD);
            b.box(31.2f, 0, 1.0f, 0.9f, TNT);
        }
        L.add(new LevelDef("Twin Pyramids", T_DESERT, 4, b.s));

        b = new B();
        {
            float y = b.storey(25, 0, 10, 2.4f, 1.0f, CONCRETE, STEEL);
            b.box(29.2f, 0, 0.6f, 2.4f, STEEL);
            b.box(26.3f, 0, 1.0f, 1.0f, WOOD);
            b.box(31.0f, 0, 1.6f, 0.8f, STEEL);
            b.box(32.8f, 0, 0.6f, 0.4f, GOLD);
            y = b.storey(26.5f, y, 7f, 1.8f, 0.8f, CONCRETE, STEEL);
            b.box(28.5f, y, 3f, 0.8f, CONCRETE);
            b.box(36.0f, 0, 1.0f, 1.0f, CONCRETE);
            b.box(37.2f, 0, 1.0f, 0.6f, CONCRETE);
        }
        L.add(new LevelDef("Steel Bunker", T_DESERT, 6, b.s));

        // ================================================================ WORLD 3 · FROZEN PEAKS
        b = new B();
        {
            float y = b.storey(25, 0, 10, 2.5f, 0.5f, ICE, ICE);
            b.box(27.5f, 0, 0.5f, 2.5f, ICE);
            b.box(32.0f, 0, 0.5f, 2.5f, ICE);
            b.box(29.2f, 0, 1.6f, 1.6f, ICE);
            float t = b.column(25.1f, y, 1.4f, 1.0f, 3, ICE);
            b.tri(24.95f, t, 1.7f, 1.6f, ICE);
            b.column(33.5f, y, 1.4f, 1.0f, 3, ICE);
            b.tri(33.35f, t, 1.7f, 1.6f, ICE);
            float y2 = b.storey(27.5f, y, 5f, 2.2f, 0.4f, ICE, ICE);
            b.tri(27.3f, y2, 5.4f, 2.4f, ICE);
        }
        L.add(new LevelDef("Ice Palace", T_WINTER, 4, b.s));

        b = new B();
        {
            for (int k = 0; k < 2; k++) {
                float x0 = k == 0 ? 25f : 31.5f;
                for (int r = 0; r < 4; r++) {
                    int n = 5 - r;
                    for (int i = 0; i < n; i++) b.box(x0 + r * 0.45f + i * 0.9f, r * 0.7f, 0.9f, 0.7f, ICE);
                }
            }
            b.box(38f, 0, 1.2f, 1.0f, ICE);
            b.box(38.15f, 1.0f, 0.9f, 0.8f, ICE);
            b.box(38.3f, 1.8f, 0.6f, 0.6f, ICE);
            b.column(41f, 0, 1.0f, 0.7f, 3, ICE);
            b.box(30.0f, 0, 1.0f, 0.9f, TNT);
        }
        L.add(new LevelDef("Igloo Village", T_WINTER, 3, b.s));

        b = new B();
        {
            float y = b.glassFloor(26, 0, 8, 2.6f, 0.5f, 3, WOOD, WOOD, 0.4f);
            y = b.glassFloor(27, y, 6, 2.2f, 0.4f, 3, WOOD, WOOD, 0.35f);
            b.tri(25.6f, y, 8.8f, 3.0f, BRICK);
            b.column(35f, 0, 1.0f, 1.0f, 6, STONE);
            b.box(36.4f, 0, 1.0f, 0.9f, TNT);
        }
        L.add(new LevelDef("Ski Lodge", T_WINTER, 4, b.s));

        b = new B();
        {
            float y = 0;
            float cx = 31f;
            float[] widths = {3.6f, 3.3f, 3.0f, 2.7f, 2.4f, 2.1f};
            for (int i = 0; i < widths.length; i++) {
                b.box(cx - widths[i] / 2, y, widths[i], 1.5f, i % 2 == 0 ? CONCRETE : BRICK);
                y += 1.5f;
            }
            b.box(cx - 1.7f, y, 3.4f, 0.3f, STEEL);
            y += 0.3f;
            b.box(cx - 1.0f, y, 0.18f, 1.4f, STEEL);
            b.box(cx - 0.82f, y, 1.64f, 1.4f, GLASS);
            b.box(cx + 0.82f, y, 0.18f, 1.4f, STEEL);
            y += 1.4f;
            b.tri(cx - 1.2f, y, 2.4f, 1.3f, STEEL);
            b.box(26.5f, 0, 1.4f, 1.0f, ICE);
            b.box(34.3f, 0, 1.6f, 1.2f, ICE);
            b.box(36.0f, 0, 1.0f, 0.7f, ICE);
        }
        L.add(new LevelDef("Frozen Lighthouse", T_WINTER, 4, b.s));

        b = new B();
        {
            b.column(25, 0, 1.4f, 1.0f, 3, ICE);
            b.column(31.3f, 0, 1.4f, 1.0f, 3, ICE);
            b.column(37.6f, 0, 1.4f, 1.0f, 3, ICE);
            b.box(25, 3, 7.0f, 0.45f, ICE);
            b.box(32, 3, 7.0f, 0.45f, ICE);
            b.box(27f, 3.45f, 1.6f, 0.5f, WOOD);
            b.box(34f, 3.45f, 1.0f, 0.9f, TNT);
            b.box(36f, 3.45f, 1.0f, 0.9f, ICE);
            b.box(36.15f, 4.35f, 0.7f, 0.6f, ICE);
            b.box(29.5f, 3.45f, 0.6f, 0.4f, GOLD);
        }
        L.add(new LevelDef("Ice Bridge", T_WINTER, 4, b.s));

        b = new B();
        {
            float cx = 31f, y = 0;
            float[] w = {6f, 5f, 4f, 3.2f};
            for (float tw : w) {
                y = b.storey(cx - tw / 2, y, tw, 1.8f, 0.4f, WOOD, WOOD) - 0.4f;
                b.s.remove(b.s.size() - 1);
                b.box(cx - tw / 2 - 0.7f, y, tw + 1.4f, 0.4f, BRICK);
                y += 0.4f;
            }
            b.tri(cx - 1.4f, y, 2.8f, 1.6f, BRICK);
            b.box(cx - 0.5f, 0, 1.0f, 0.9f, TNT);
        }
        L.add(new LevelDef("Snowy Pagoda", T_WINTER, 5, b.s));

        b = new B();
        {
            float t = b.column(25, 0, 1.8f, 1.0f, 5, ICE);
            b.tri(24.9f, t, 2.0f, 1.4f, ICE);
            b.column(37.2f, 0, 1.8f, 1.0f, 5, ICE);
            b.tri(37.1f, t, 2.0f, 1.4f, ICE);
            for (int r = 0; r < 3; r++) {
                float x = 26.8f, y = r * 0.8f;
                if (r % 2 == 1) {
                    b.box(x, y, 0.65f, 0.8f, ICE);
                    x += 0.65f;
                }
                int k = 0;
                while (x < 37.19f) {
                    float w = Math.min(1.3f, 37.2f - x);
                    b.box(x, y, w, 0.8f, r == 0 && k == 4 ? TNT : ICE);
                    x += w;
                    k++;
                }
            }
            b.box(28f, 2.4f, 0.2f, 1.4f, WOOD);
            b.box(35.8f, 2.4f, 0.2f, 1.4f, WOOD);
            b.box(31.5f, 2.4f, 1.0f, 0.6f, GOLD);
        }
        L.add(new LevelDef("Snow Fort", T_WINTER, 4, b.s));

        b = new B();
        {
            float y = b.fillFloor(25, 0, 12, 3.0f, 0.6f, 4, ICE, GLASS, STEEL, 0.5f);
            y = b.glassFloor(26.5f, y, 9, 2.4f, 0.5f, 3, ICE, ICE, 0.45f);
            float t = b.column(26.5f, y, 1.4f, 1.0f, 2, ICE);
            b.tri(26.35f, t, 1.7f, 1.5f, ICE);
            b.column(34.1f, y, 1.4f, 1.0f, 2, ICE);
            b.tri(33.95f, t, 1.7f, 1.5f, ICE);
            float y2 = b.storey(29, y, 4, 1.8f, 0.4f, ICE, ICE);
            b.tri(28.8f, y2, 4.4f, 2.0f, GLASS);
            b.box(30.5f, y, 1.0f, 0.6f, GOLD);
        }
        L.add(new LevelDef("Glacier Castle", T_WINTER, 5, b.s));

        // ================================================================ WORLD 4 · NEON CITY
        b = new B();
        {
            float y = 0;
            for (int i = 0; i < 6; i++) y = b.glassFloor(26f, y, 7f, 2.3f, 0.5f, 3, CONCRETE, CONCRETE, 0.35f);
            b.box(27.0f, y, 1.6f, 1.2f, STEEL);
            b.box(30.5f, y, 0.3f, 1.6f, STEEL);
        }
        L.add(new LevelDef("Apartment Block", T_NIGHT, 6, b.s));

        b = new B();
        {
            float y = 0;
            for (int f = 0; f < 4; f++) {
                b.box(25, y, 0.6f, 2.0f, CONCRETE);
                b.box(30.6f, y, 0.6f, 2.0f, CONCRETE);
                b.box(36.2f, y, 0.6f, 2.0f, CONCRETE);
                b.box(26f, y, 1.8f, 0.8f, STEEL);
                b.box(32f, y, 1.8f, 0.8f, f == 1 ? TNT : STEEL);
                b.box(25, y + 2.0f, 11.8f, 0.4f, CONCRETE);
                y += 2.4f;
            }
            b.box(27f, y, 1.8f, 0.8f, STEEL);
            b.box(33f, y, 1.0f, 0.9f, TNT);
        }
        L.add(new LevelDef("Parking Garage", T_NIGHT, 5, b.s));

        b = new B();
        {
            float h = 3.2f;
            b.box(24, 0, 0.6f, h, BRICK);
            b.window(24.6f, 0, 2.2f, h, BRICK);
            b.box(26.8f, 0, 0.6f, h, BRICK);
            b.window(27.4f, 0, 2.2f, h, BRICK);
            b.box(29.6f, 0, 0.6f, h, BRICK);
            b.window(30.2f, 0, 2.2f, h, BRICK);
            b.box(32.4f, 0, 0.6f, h, BRICK);
            b.box(24, h, 9f, 0.35f, STEEL);
            float y = h + 0.35f;
            y = b.glassFloor(28.6f, y, 4.4f, 2.0f, 0.4f, 2, BRICK, STEEL, 0.3f);
            b.column(34.2f, 0, 1.3f, 1.0f, 10, BRICK);
            b.box(24.6f, y - 2.3f, 1.0f, 1.0f, WOOD);
            b.box(25.8f, y - 2.3f, 1.0f, 1.0f, TNT);
            b.box(25.2f, y - 1.3f, 1.0f, 1.0f, WOOD);
        }
        L.add(new LevelDef("Factory", T_NIGHT, 5, b.s));

        b = new B();
        {
            float y = b.glassFloor(26, 0, 10, 2.8f, 0.4f, 4, STEEL, STEEL, 0.35f);
            y = b.glassFloor(26, y, 10, 2.4f, 0.4f, 4, STEEL, CONCRETE, 0.4f);
            b.box(27.5f, y, 7f, 1.2f, GLASS);
            b.box(37.0f, 0, 1.0f, 0.9f, TNT);
            b.box(38.2f, 0, 0.6f, 0.4f, GOLD);
        }
        L.add(new LevelDef("Neon Arcade", T_NIGHT, 4, b.s));

        b = new B();
        {
            float cx = 31f;
            float y = b.storey(cx - 2.2f, 0, 4.4f, 3.0f, 0.8f, STONE, STONE);
            b.box(cx - 0.9f, 0, 1.8f, 1.6f, WOOD);
            y = b.column(cx - 1.5f, y, 3.0f, 1.5f, 4, BRICK);
            b.box(cx - 1.7f, y, 3.4f, 2.4f, STONE);
            y += 2.4f;
            b.box(cx - 1.9f, y, 3.8f, 0.3f, STEEL);
            y += 0.3f;
            b.tri(cx - 1.9f, y, 3.8f, 3.0f, STEEL);
        }
        L.add(new LevelDef("Clock Tower", T_NIGHT, 5, b.s));

        b = new B();
        {
            for (int k = 0; k < 2; k++) {
                float x = k == 0 ? 26f : 33.4f, y = 0;
                for (int i = 0; i < 5; i++) y = b.glassFloor(x, y, 3.6f, 2.0f, 0.3f, 2, STEEL, STEEL, 0.3f);
                b.box(x + (k == 0 ? 0.4f : 2.9f), y, 0.2f, 2f, STEEL);
                if (k == 0) b.box(28.8f, y, 5.4f, 0.4f, GLASS);
            }
        }
        L.add(new LevelDef("Twin Spires", T_NIGHT, 5, b.s));

        b = new B();
        {
            float y = 0;
            for (int i = 0; i < 3; i++) y = b.storey(25, y, 7, 2.6f, 0.25f, STEEL, WOOD);
            b.box(26, 0, 2, 1.0f, CONCRETE);
            b.box(29, 0, 2, 1.0f, CONCRETE);
            b.box(26, 2.85f, 1.2f, 0.5f, WOOD);
            b.box(26, 3.35f, 1.2f, 0.5f, WOOD);
            b.box(29.5f, 2.85f, 1.4f, 0.9f, BRICK);
            b.box(28.5f, 5.7f, 1.0f, 0.9f, TNT);
            b.box(26.5f, 5.7f, 1.6f, 0.3f, GLASS);
            b.box(34, 0, 3, 0.5f, CONCRETE);
            b.box(34, 0.5f, 3, 0.5f, CONCRETE);
            b.box(34, 1.0f, 3, 0.5f, CONCRETE);
            b.box(34.2f, 1.5f, 2.6f, 0.3f, STEEL);
        }
        L.add(new LevelDef("Building Site", T_NIGHT, 5, b.s));

        b = new B();
        {
            float y = 0;
            for (int i = 0; i < 7; i++) y = b.glassFloor(27.5f, y, 6.2f, 2.1f, 0.35f, 3, STEEL, STEEL, 0.3f);
            b.box(30.45f, y, 0.3f, 2.6f, STEEL);
        }
        L.add(new LevelDef("Skyscraper", T_NIGHT, 6, b.s));

        // ================================================================ WORLD 5 · LAVA FORTRESS
        b = new B();
        {
            float top = b.column(24, 0, 2.4f, 1.2f, 6, STONE);
            for (int i = 0; i < 3; i++) b.box(24 + i * 0.9f, top, 0.6f, 0.6f, STONE);
            b.column(33.6f, 0, 2.4f, 1.2f, 6, STONE);
            for (int i = 0; i < 3; i++) b.box(33.6f + i * 0.9f, top, 0.6f, 0.6f, STONE);
            for (int r = 0; r < 5; r++) {
                float y = r * 0.9f, x = 26.4f;
                if (r % 2 == 1) {
                    b.box(x, y, 0.6f, 0.9f, STONE);
                    x += 0.6f;
                }
                while (x < 33.59f) {
                    float w = Math.min(1.2f, 33.6f - x);
                    float mid = x + w / 2;
                    boolean gate = r < 2 && mid > 29.0f && mid < 31.0f;
                    b.box(x, y, w, 0.9f, gate ? (r == 0 && mid < 30 ? TNT : WOOD) : STONE);
                    x += w;
                }
            }
            for (int i = 0; i < 6; i++) b.box(26.4f + i * 1.2f + 0.3f, 4.5f, 0.6f, 0.6f, STONE);
        }
        L.add(new LevelDef("Castle", T_LAVA, 6, b.s));

        b = new B();
        {
            for (int t = 0; t < 4; t++) {
                int n = 10 - 2 * t;
                for (int i = 0; i < n; i++)
                    b.box(24.5f + t * 1.2f + i * 1.2f, t * 1.2f, 1.2f, 1.2f, (t == 0 && (i == 3 || i == 6)) ? TNT : STONE);
            }
            float y = b.storey(28.6f, 4.8f, 3.8f, 1.8f, 0.4f, STONE, STONE);
            b.box(29.9f, 4.8f, 1.2f, 0.6f, GOLD);
            b.tri(28.4f, y, 4.2f, 1.6f, STONE);
        }
        L.add(new LevelDef("Volcano Temple", T_LAVA, 5, b.s));

        b = new B();
        {
            float cx = 33f;
            float y = b.storey(cx - 3, 0, 6, 2.4f, 0.8f, STONE, STONE);
            b.box(cx - 0.8f, 0, 1.6f, 1.8f, WOOD);
            for (int i = 0; i < 6; i++) {
                b.box(cx - 1.6f, y, 3.2f, 1.2f, i % 3 == 2 ? STEEL : STONE);
                y += 1.2f;
            }
            b.box(cx - 2.0f, y, 4.0f, 0.4f, STEEL);
            y += 0.4f;
            b.box(cx - 2.0f, y, 0.6f, 0.7f, STONE);
            b.box(cx + 1.4f, y, 0.6f, 0.7f, STONE);
            b.box(cx - 0.6f, y, 1.2f, 1.0f, GOLD);
        }
        L.add(new LevelDef("Dark Tower", T_LAVA, 5, b.s));

        b = new B();
        {
            float y = b.fillFloor(25, 0, 10, 2.6f, 0.5f, 3, STEEL, STONE, STEEL, 0.4f);
            y = b.fillFloor(26, y, 8, 2.4f, 0.5f, 3, STEEL, BRICK, STEEL, 0.4f);
            b.tri(25.8f, y, 8.4f, 2.2f, STEEL);
            b.box(36f, 0, 1.0f, 0.9f, TNT);
            b.box(37.2f, 0, 1.0f, 0.9f, TNT);
        }
        L.add(new LevelDef("Iron Keep", T_LAVA, 6, b.s));

        b = new B();
        {
            b.column(25, 0, 1.6f, 1.2f, 3, STONE);
            b.column(32, 0, 1.6f, 1.2f, 3, STONE);
            b.column(39, 0, 1.6f, 1.2f, 3, STONE);
            b.box(25, 3.6f, 7.8f, 0.4f, STEEL);
            b.box(32.8f, 3.6f, 7.8f, 0.4f, STEEL);
            b.column(25.2f, 4.0f, 1.2f, 1.0f, 3, STONE);
            b.column(39.2f, 4.0f, 1.2f, 1.0f, 3, STONE);
            b.box(29f, 4.0f, 1.6f, 0.8f, WOOD);
            b.box(35f, 4.0f, 1.0f, 0.9f, TNT);
            b.box(30.8f, 4.0f, 0.6f, 0.4f, GOLD);
        }
        L.add(new LevelDef("Lava Bridge", T_LAVA, 5, b.s));

        b = new B();
        {
            b.column(25, 0, 2.2f, 1.2f, 5, STONE);
            b.column(34.8f, 0, 2.2f, 1.2f, 5, STONE);
            b.box(27.2f, 0, 2.2f, 4.8f, STONE);
            b.box(29.4f, 0, 3.2f, 3.0f, WOOD);
            b.box(32.6f, 0, 2.2f, 4.8f, STONE);
            b.box(29.4f, 3.0f, 3.2f, 1.8f, STONE);
            b.box(25, 6.0f, 12, 0.6f, STEEL);
            b.tri(28, 6.6f, 6, 2.2f, STONE);
            b.box(25, 6.6f, 0.8f, 0.7f, STONE);
            b.box(36.2f, 6.6f, 0.8f, 0.7f, STONE);
            b.box(37.4f, 0, 1.0f, 0.9f, TNT);
            b.box(38.6f, 0, 0.6f, 0.4f, GOLD);
        }
        L.add(new LevelDef("Dragon Gate", T_LAVA, 5, b.s));

        b = new B();
        {
            float y = b.glassFloor(24.5f, 0, 12f, 3f, 0.6f, 4, STONE, CONCRETE, 0.5f);
            y = b.glassFloor(25.5f, y, 10f, 2.6f, 0.4f, 3, STEEL, STEEL, 0.35f);
            float y3 = y;
            b.box(27f, y, 0.6f, 2.4f, BRICK);
            b.window(27.6f, y, 2.4f, 2.4f, BRICK);
            b.box(30f, y, 0.6f, 2.4f, BRICK);
            b.window(30.6f, y, 2.4f, 2.4f, BRICK);
            b.box(33f, y, 0.6f, 2.4f, BRICK);
            b.box(27f, y + 2.4f, 6.6f, 0.4f, STONE);
            y += 2.8f;
            b.tri(26.8f, y, 7.0f, 2.2f, STONE);
            float t = b.column(38f, 0, 2.2f, 1.2f, 7, STONE);
            for (int i = 0; i < 3; i++) b.box(38f + i * 0.8f, t, 0.6f, 0.6f, STONE);
            b.box(25.6f, y3, 0.9f, 0.9f, TNT);
            b.box(34.6f, y3, 0.8f, 0.8f, GOLD);
        }
        L.add(new LevelDef("Mega Fortress", T_LAVA, 7, b.s));

        b = new B();
        {
            float y = b.glassFloor(24, 0, 14, 3, 0.6f, 5, STONE, CONCRETE, 0.5f);
            float[] cols = {25f, 28.7f, 32.4f, 36.1f};
            for (float cx : cols) b.box(cx, y, 0.5f, 2.6f, STEEL);
            b.box(25.5f, y, 3.2f, 1.2f, BRICK);
            b.box(25.5f, y + 1.2f, 3.2f, 1.4f, GLASS);
            b.box(29.2f, y, 1.0f, 0.9f, TNT);
            b.box(30.3f, y, 1.0f, 1.0f, WOOD);
            b.box(31.4f, y, 0.9f, 0.5f, GOLD);
            b.box(32.9f, y, 3.2f, 1.2f, BRICK);
            b.box(32.9f, y + 1.2f, 3.2f, 1.4f, GLASS);
            b.box(25f, y + 2.6f, 11.6f, 0.4f, STEEL);
            y += 3.0f;
            y = b.glassFloor(26.5f, y, 8.6f, 2.4f, 0.4f, 3, STEEL, STONE, 0.4f);
            b.tri(26.3f, y, 9.0f, 2.6f, STONE);
            float t = b.column(39.5f, 0, 2.2f, 1.2f, 7, STONE);
            for (int i = 0; i < 3; i++) b.box(39.5f + i * 0.8f, t, 0.6f, 0.6f, STONE);
            b.box(40.1f, t + 0.6f, 1.0f, 0.6f, GOLD);
        }
        L.add(new LevelDef("Final Citadel", T_LAVA, 8, b.s));

        return L.toArray(new LevelDef[0]);
    }

    // ---------------------------------------------------------------- tiny utils
    static int shade(int c, float f) {
        int a = c >>> 24, r = (c >> 16) & 255, g = (c >> 8) & 255, bl = c & 255;
        if (f >= 1f) {
            float t = f - 1f;
            r += (int) ((255 - r) * t); g += (int) ((255 - g) * t); bl += (int) ((255 - bl) * t);
        } else {
            r = (int) (r * f); g = (int) (g * f); bl = (int) (bl * f);
        }
        return (a << 24) | (clamp255(r) << 16) | (clamp255(g) << 8) | clamp255(bl);
    }

    static int withAlpha(int c, int a) {
        return (c & 0xFFFFFF) | (Math.max(0, Math.min(255, a)) << 24);
    }

    private static int clamp255(int v) {
        return v < 0 ? 0 : (v > 255 ? 255 : v);
    }

    /** Deterministic pseudo random in [0,1) for a seed and index. */
    static float hash(int seed, int i) {
        int h = seed * 374761393 + i * 668265263;
        h = (h ^ (h >>> 13)) * 1274126177;
        h ^= h >>> 16;
        return (h & 0xFFFFFF) / 16777216f;
    }
}
