package com.slingsmash.game;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.Typeface;
import android.os.Build;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.view.MotionEvent;
import android.view.View;

import org.jbox2d.common.Vec2;

import java.util.ArrayList;
import java.util.Locale;

public final class GameView extends View implements GameWorld.Fx {

    private static final int SC_MENU = 0, SC_WORLDS = 1, SC_LEVELS = 2, SC_GAME = 3, SC_ARMORY = 4, SC_MISSIONS = 5, SC_BUILDER = 6, SC_CODES = 7;
    static final int M_CAMPAIGN = 0, M_ENDLESS = 1, M_DAILY = 2, M_TEST = 3, M_VERSUS = 4;
    private static final int ST_AIM = 0, ST_FLY = 1, ST_WAIT = 2;
    private static final float MAX_PULL = 3.4f, MAX_SPEED = 27f;

    // button ids
    private static final int B_PLAY = 1, B_ARMORY = 2, B_ENDLESS = 3, B_SOUND = 4, B_VIBE = 5, B_BACK = 6, B_PAUSE = 7,
            B_RESTART = 8, B_RESUME = 9, B_LEVELS = 10, B_NEXT = 11, B_RETRY = 12, B_BUY = 13, B_DAILY = 15,
            B_BUILD = 16, B_MISSIONS = 17, B_FINISH = 18, B_REPLAY = 19, B_UPGRADE_AMMO = 20, B_TEST = 21, B_VS = 22,
            B_UNDO = 23, B_CLEAR = 24, B_ERASE = 25, B_DONE = 26, B_READY = 27, B_CHEST_OK = 28, B_TO_BUILDER = 29,
            B_SKIN_AUTO = 30, B_PLAN = 31, B_PLAN_GO = 32, B_PLAN_CANCEL = 33, B_PLAN_ADD = 34, B_PLAN_DEL = 35,
            B_HINT = 36, B_HINT_A = 37, B_SOL_A = 38, B_HINT_CLOSE = 39, B_CODES = 40, B_ASKIN = 41, B_KEY = 800,
            B_STEP = 700, B_STEP_WM = 710, B_STEP_WP = 720, B_STEP_FM = 730, B_STEP_FP = 740,
            B_WORLD = 100, B_LEVEL = 200, B_TAB = 300, B_ITEM = 400, B_UPG = 500, B_SKIN = 520, B_CLAIM = 540,
            B_PAL_MAT = 600, B_PAL_SHAPE = 640;

    private final Typeface font;
    private final Art art;
    private final Ui ui;
    private final Sfx sfx;
    private final Vibrator vibrator;
    private final Progress pr;
    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final RectF rf = new RectF();
    private final Path path = new Path();

    private final GameWorld game;
    private final GameWorld demo;
    private int screen = SC_MENU, armoryReturn = SC_MENU;
    private int mode = M_CAMPAIGN;
    private Defs.LevelDef cur;
    private int world, level, ammo, state, shotsLeft, shotsFired, shotsThisWave;
    private final int[] uses = new int[Defs.NUM_AMMO];
    private float stateTime, settleTime, completeTime;
    private boolean paused, showResult, vibeOn = true, statsCommitted, objectiveAnnounced;
    private float resultT;
    private int resultStars, resultScore, starsPlayed, coinsEarned;
    private final boolean[] starOk = new boolean[3];
    private float resultDestr;
    private boolean newBest, resultFailed;
    private String toast;
    private float toastT;
    // endless
    private int wave, endlessScore, lastWaveBonus;
    private float waveClearT = -1;
    // versus
    private int vsPhase;
    private final float[] vsScore = new float[2];
    private boolean vsInterstitial;
    // builder
    private final Builder builder = new Builder();
    private final Builder vsBuilder = new Builder();
    private int palMat = Defs.WOOD, palShape = 0;
    private boolean eraseMode, ghostOn;
    private float ghostX, ghostY;
    // chest
    private Progress.Reward chest;
    private float chestT;
    private boolean pendingDailyChest;
    // replay
    private GameWorld.Clip replay;
    private float replayT, rCamX, rCamY, rZoom;

    // demo
    private int demoLevel;
    private float demoTimer, demoTrigger;
    private int demoShots;

    // view / camera
    private int W, H;
    private float s0, sc, viewL, viewB = -4.6f, camX = 19f, camZ = 1f, camY = 0;
    private float k, ox, oy, L, R, T, Bm;
    private float time, fade, dtLast;
    private long lastNs;
    private boolean running = true;

    // aiming / dragging
    private boolean aiming;
    private int aimId = -1;
    private float tx0, ty0, pullX, pullY;
    private boolean barDrag, barMoved, gridDrag, gridMoved;
    private float dragX0, dragY0, scroll0;
    private float barScroll, gridScroll;
    private int pendingItem = -1;
    private int armoryTab, armorySel = Defs.A_HOLE, armoryPage;
    private final ArrayList<Integer> owned = new ArrayList<>();

    // combo planner
    private static final int[] STEP_COL = {0xFFFF5A4A, 0xFF4FD8FF, 0xFFFFD23F, 0xFF7CFF7A};
    private static final int MAX_STEPS = 4;
    private final Plan cplan = new Plan();
    private final ArrayList<Plan.Step> plan = cplan.steps;
    private boolean solutionPlan, solutionRun;
    // hints / rewarded videos
    Ads ads;
    private boolean hintOpen;
    private float adWaitT = -1, adWaitMax;
    private Runnable adReward;
    private boolean adShowing;
    private boolean planning, planRun, holdWorld;
    private int planSel;
    private Defs.LevelDef planFor;
    private float lastVx = 15f, lastVy = 11f;

    public GameView(Context ctx) {
        super(ctx);
        Typeface tf;
        try {
            tf = Typeface.createFromAsset(ctx.getAssets(), "LilitaOne.ttf");
        } catch (Exception e) {
            tf = Typeface.create("sans-serif-black", Typeface.NORMAL);
        }
        font = tf;
        Sprites.load(ctx.getAssets());
        art = new Art(font);
        ui = new Ui(font);
        sfx = new Sfx(ctx);
        vibrator = (Vibrator) ctx.getSystemService(Context.VIBRATOR_SERVICE);
        pr = new Progress(ctx.getSharedPreferences("slingsmash", Context.MODE_PRIVATE));
        sfx.muted = pr.bool("muted", false);
        vibeOn = pr.bool("vibe", true);
        loadOwned();
        applyAmmoSkins();
        ammo = pr.p.getInt("ammo", 0);
        if (!pr.owned(ammo)) ammo = 0;
        builder.decode(pr.save(0));
        if (builder.items.isEmpty()) builder.starter();
        game = new GameWorld(this);
        game.hook = new GameWorld.StepHook() {
            @Override
            public void onStep(int step) {
                cplan.onStep(game, step, planListener);
            }
        };
        demo = new GameWorld(new GameWorld.Fx() {
            @Override public void sound(int id, float vol, float pv) {}
            @Override public void vibrate(int ms) {}
        });
        demoLevel = 36 + (int) (Math.random() * 3);
        demo.load(Defs.LEVELS[demoLevel]);
        setFocusable(true);
    }

    private void loadOwned() {
        owned.clear();
        for (int i = 0; i < Defs.NUM_AMMO; i++) if (pr.owned(i)) owned.add(i);
    }

    // ================================================================ lifecycle

    void onPauseGame() {
        running = false;
        if (screen == SC_GAME && !showResult && replay == null) paused = true;
    }

    void onResumeGame() {
        running = true;
        lastNs = 0;
        postInvalidateOnAnimation();
    }

    void release() {
        sfx.release();
    }

    boolean onBack() {
        click();
        if (chest != null) { chest = null; return true; }
        if (adWaitT >= 0) return true;
        if (hintOpen) { hintOpen = false; return true; }
        if (replay != null) { endReplay(); return true; }
        switch (screen) {
            case SC_GAME:
                if (showResult) leaveGame();
                else paused = !paused;
                return true;
            case SC_LEVELS: go(SC_WORLDS); return true;
            case SC_WORLDS: case SC_MISSIONS: case SC_CODES: go(SC_MENU); return true;
            case SC_ARMORY: go(armoryReturn); return true;
            case SC_BUILDER:
                mode = M_CAMPAIGN;
                go(SC_MENU);
                return true;
        }
        return false;
    }

    @Override
    protected void onSizeChanged(int w, int h, int ow, int oh) {
        W = w;
        H = h;
        s0 = Math.min(W / 56f, H / 27.5f);
        k = Math.min(W / 1600f, H / 720f);
        ox = (W - 1600 * k) / 2f;
        oy = (H - 720 * k) / 2f;
        L = -ox / k;
        R = 1600 + ox / k;
        T = -oy / k;
        Bm = 720 + oy / k;
    }

    // ================================================================ Fx

    @Override
    public void sound(int id, float vol, float pitchVar) {
        sfx.play(id, vol, pitchVar);
    }

    @Override
    public void vibrate(int ms) {
        if (vibrator == null || !vibeOn) return;
        try {
            if (Build.VERSION.SDK_INT >= 26) vibrator.vibrate(VibrationEffect.createOneShot(ms, VibrationEffect.DEFAULT_AMPLITUDE));
            else vibrator.vibrate(ms);
        } catch (Exception ignored) {
        }
    }

    private void click() {
        sfx.play(Defs.S_CLICK, 0.6f, 0.05f);
    }

    private void showToast(String s) {
        toast = s;
        toastT = 2.4f;
    }

    // ================================================================ flow

    private void go(int s) {
        screen = s;
        fade = 1f;
        paused = false;
        showResult = false;
        aiming = false;
        gridScroll = 0;
        ghostOn = false;
    }

    private void startCampaign(int idx) {
        level = idx;
        world = Defs.worldOf(idx);
        mode = M_CAMPAIGN;
        startGame(Defs.LEVELS[idx]);
    }

    private void startGame(Defs.LevelDef def) {
        cur = def;
        game.load(def);
        game.dmgBoost = 1f + 0.15f * pr.upg(Progress.UPG_POWER);
        int extra = (mode == M_CAMPAIGN || mode == M_DAILY || mode == M_ENDLESS) ? pr.upg(Progress.UPG_SHOT) : 0;
        if (mode == M_TEST) shotsLeft = 9999;
        else if (mode == M_VERSUS) shotsLeft = 4;
        else if (mode == M_ENDLESS) shotsLeft = (wave == 1 ? def.shots + extra : shotsLeft);
        else shotsLeft = def.shots + extra;
        shotsFired = 0;
        shotsThisWave = 0;
        resetUses();
        state = ST_AIM;
        stateTime = 0;
        settleTime = 0;
        completeTime = 0;
        waveClearT = -1;
        statsCommitted = false;
        objectiveAnnounced = false;
        planning = false;
        planRun = false;
        cplan.running = false;
        holdWorld = false;
        solutionPlan = false;
        if (planFor != def) { plan.clear(); planFor = def; }
        camX = 19f;
        camZ = 1f;
        if (!ammoAllowed(ammo)) ammo = 0;
        int ai = Math.max(0, barList().indexOf(ammo));
        barScroll = ai * (SLOT + SLOT_GAP) + SLOT / 2 + 18 - (R - L) * 0.28f;
        go(SC_GAME);
    }

    private void resetUses() {
        for (int i = 0; i < Defs.NUM_AMMO; i++) uses[i] = (mode == M_TEST) ? 99 : pr.usesPerLevel(i);
    }

    private boolean ammoAllowed(int t) {
        if (!pr.owned(t)) return false;
        if (mode == M_VERSUS) return Defs.AMMO_PRICE[t] == 0;
        return true;
    }

    private ArrayList<Integer> barList() {
        ArrayList<Integer> l = new ArrayList<>();
        for (int t : owned) if (ammoAllowed(t)) l.add(t);
        return l;
    }

    private void startEndless() {
        mode = M_ENDLESS;
        wave = 1;
        endlessScore = 0;
        startGame(Gen.make(System.nanoTime(), 0f, false));
    }

    private void nextWave() {
        endlessScore += game.score;
        commitStats();
        pr.reach("wave", wave + 1);
        wave++;
        startGame(Gen.make(System.nanoTime(), Math.min(1.5f, wave * 0.13f), false));
        showToast("WAVE " + wave + "  •  +" + lastWaveBonus + " SHOTS");
    }

    private void startDaily() {
        mode = M_DAILY;
        startGame(Gen.make(Progress.today(), 0.9f, true));
    }

    private void startTest() {
        mode = M_TEST;
        startGame(builder.toLevel("Your Building", Defs.T_DAY, 9999));
    }

    private void leaveGame() {
        commitStats();
        switch (mode) {
            case M_CAMPAIGN: go(SC_LEVELS); break;
            case M_TEST: go(SC_BUILDER); break;
            case M_VERSUS: mode = M_CAMPAIGN; go(SC_MENU); break;
            default: go(SC_MENU);
        }
    }

    /** Copies what happened in this level into the long-term stats used by missions. */
    private void commitStats() {
        if (statsCommitted || cur == null) return;
        statsCommitted = true;
        GameWorld g = game;
        int[] b = g.statBroken;
        pr.addStat("glass", b[Defs.GLASS] + b[Defs.CRYSTAL]);
        pr.addStat("wood", b[Defs.WOOD]);
        pr.addStat("stone", b[Defs.STONE] + b[Defs.BRICK] + b[Defs.CONCRETE]);
        pr.addStat("steel", b[Defs.STEEL] + b[Defs.ARMOR]);
        pr.addStat("explosions", g.statExplosions);
        pr.addStat("frozen", g.statFrozen);
        pr.addStat("gold", g.statGold);
        pr.addStat("shots", shotsFired);
        pr.addStat("cows", g.launchedCows);
        pr.addStat("special", g.launchedSpecial);
        if (cur.objective == Defs.O_TARGETS) pr.addStat("targets", g.targetsDown());
        if (cur.objective == Defs.O_CROWN && g.crownDown()) pr.addStat("crowns", 1);
        pr.reach("combo", g.maxCombo);
        int smashed = 0;
        for (int v : b) smashed += v;
        pr.addStat("smashed", smashed);
    }

    private void finishLevel(boolean failed) {
        if (showResult) return;
        game.finishClip();
        float d = game.destruction();
        resultDestr = d;
        resultFailed = failed;
        int obj = game.objectiveState();
        aiming = false;
        if (mode == M_VERSUS) {
            vsScore[vsPhase == 1 ? 1 : 0] = d;
            if (vsPhase >= 3) pr.addStat("versus", 1);
            commitStats();
            showResult = true;
            resultT = 0;
            sfx.play(Defs.S_WIN, 0.8f, 0f);
            return;
        }
        if (mode == M_ENDLESS) {
            endlessScore += game.score;
            resultScore = endlessScore;
            newBest = endlessScore > pr.endlessBest();
            pr.setEndless(endlessScore, wave);
            pr.reach("wave", wave);
            coinsEarned = wave * 25 + game.coins;
            pr.addCoins(coinsEarned);
            commitStats();
            showResult = true;
            resultT = 0;
            sfx.play(Defs.S_THUD, 0.8f, 0f);
            return;
        }
        int par = cur.par;
        starOk[0] = obj == 1;
        starOk[1] = starOk[0] && d >= cur.star2;
        starOk[2] = starOk[1] && shotsFired <= par;
        resultStars = (starOk[0] ? 1 : 0) + (starOk[1] ? 1 : 0) + (starOk[2] ? 1 : 0);
        resultScore = game.score + (int) (d * 5000) + (resultStars > 0 ? Math.max(0, shotsLeft) * 1500 : 0);
        coinsEarned = resultStars == 0 ? (int) (d * 30) : (int) (d * 70) + resultStars * 35 + game.coins + game.maxCombo * 2;
        if (mode == M_CAMPAIGN) {
            newBest = resultScore > pr.best(level) && resultStars > 0;
            boolean firstBoss = cur.boss && resultStars > 0 && pr.stars(level) == 0;
            pr.setResult(level, resultStars, resultStars > 0 ? resultScore : 0);
            if (firstBoss) {
                pr.addStat("bosses", 1);
                if (world >= 1 && world <= 4 && !pr.skinOwned(world)) {
                    pr.unlockSkin(world);
                    showToast("NEW SLINGSHOT: " + Defs.SKIN_NAME[world].toUpperCase(Locale.US) + "!");
                }
                coinsEarned += 400;
            }
        } else if (mode == M_DAILY) {
            newBest = resultScore > pr.dailyBest();
            if (pr.setDaily(resultScore, resultStars > 0)) {
                coinsEarned += 300;
                pendingDailyChest = true;
            }
        }
        pr.addCoins(coinsEarned);
        commitStats();
        showResult = true;
        resultT = 0;
        starsPlayed = 0;
        sfx.play(resultStars > 0 ? Defs.S_WIN : Defs.S_THUD, 0.8f, 0f);
        if (solutionRun && resultStars == 0) showToast("BAD LUCK! TAP THE BULB - THE SOLUTION IS FREE NOW");
        solutionRun = false;
        if (game.bestClip != null && game.bestClip.gain > 0.22f && resultStars > 0) startReplay(game.bestClip);
    }

    // ================================================================ replay

    private void startReplay(GameWorld.Clip c) {
        replay = c;
        replayT = 0;
        rCamX = 26;
        rCamY = 4;
        rZoom = 1;
    }

    private void endReplay() {
        replay = null;
        Art.DX = 0.42f;
        Art.DY = 0.30f;
        resultT = 0;
        starsPlayed = 0;
    }

    // ================================================================ loop

    @Override
    protected void onDraw(Canvas c) {
        long now = System.nanoTime();
        float dt = lastNs == 0 ? 1 / 60f : Math.min(0.05f, (now - lastNs) / 1e9f);
        lastNs = now;
        time += dt;
        dtLast = dt;
        art.time = time;
        if (W > 0) {
            update(dt);
            render(c);
        }
        if (running) postInvalidateOnAnimation();
    }

    private void update(float dt) {
        fade = Math.max(0, fade - dt * 3.5f);
        if (ui.pressedT > 0) ui.pressedT -= dt;
        if (toastT > 0) toastT -= dt;
        if (chest != null) chestT += dt;
        if (replay != null) {
            replayT += dt;
            return;
        }
        if (screen != SC_GAME) {
            if (screen != SC_BUILDER) updateDemo(dt);
            camX = 19f;
            camZ = 1f;
            return;
        }
        if (adWaitT >= 0) {
            adWaitT -= dt;
            if (adWaitT < 0) {
                Runnable r = adReward;
                adReward = null;
                if (r != null) r.run();
            }
            return;
        }
        if (paused || vsInterstitial || hintOpen || adShowing) return;
        if (!holdWorld) game.update(dt);
        updateCamera(dt);
        if (showResult) {
            resultT += dt;
            while (starsPlayed < resultStars && resultT > 0.55f + starsPlayed * 0.4f) {
                starsPlayed++;
                sfx.play(Defs.S_STAR, 0.8f, 0f);
                sfx.play(Defs.S_THUD, 0.4f, 0f);
                vibrate(20);
            }
            if (pendingDailyChest && resultT > 2f) {
                pendingDailyChest = false;
                openChest(pr.openChest(2));
            }
            return;
        }
        stateTime += dt;
        int obj = game.objectiveState();
        if (obj == 1 && !objectiveAnnounced && mode != M_TEST && mode != M_VERSUS) {
            objectiveAnnounced = true;
            sfx.play(Defs.S_WIN, 0.7f, 0f);
            vibrate(50);
        }
        if (state == ST_FLY && stateTime > 1.1f && !planRun) {
            if (shotsLeft > 0) state = ST_AIM;
            else {
                state = ST_WAIT;
                stateTime = 0;
                settleTime = 0;
            }
        }
        if (game.settled()) settleTime += dt;
        else settleTime = 0;
        if (mode == M_TEST) return;
        if (mode == M_ENDLESS) {
            if (obj == 1) {
                if (waveClearT < 0) {
                    waveClearT = 0;
                    lastWaveBonus = 1 + (shotsThisWave <= cur.par ? 1 : 0);
                    shotsLeft += lastWaveBonus;
                    if (state == ST_WAIT) state = ST_AIM;
                }
                waveClearT += dt;
                if ((settleTime > 0.8f && waveClearT > 1.2f) || waveClearT > 3.5f) nextWave();
                return;
            }
            if (state == ST_WAIT && (settleTime > 1.0f || stateTime > 8f)) finishLevel(true);
            return;
        }
        if (mode != M_VERSUS && obj == -1 && (settleTime > 0.8f || stateTime > 6f) && state != ST_FLY) {
            finishLevel(true);
            return;
        }
        if (state == ST_WAIT && (settleTime > 1.0f || stateTime > 8f)) finishLevel(false);
        if (shotsFired > 0 && game.destruction() >= 0.97f && obj == 1 && !planRun) {
            completeTime += dt;
            if (completeTime > 1.8f) finishLevel(false);
        }
    }

    private void updateCamera(float dt) {
        float tx = 19f, tz = 1f;
        GameWorld.Shot a = game.activeShot();
        if (game.vortexT > 0) {
            tx = game.vortexX;
            tz = 1.1f;
        } else if (a != null && !aiming && (state != ST_AIM || stateTime < 2.5f)) {
            Vec2 pp = a.body.getPosition();
            tx = pp.x;
            tz = 1.14f;
        }
        tx = Math.max(19f, Math.min(29f, tx));
        float kk = Math.min(1f, dt * 2.2f);
        camX += (tx - camX) * kk;
        camZ += (tz - camZ) * kk;
    }

    private void updateDemo(float dt) {
        demo.update(dt);
        demoTimer += dt;
        if (demoShots < 4 && demoTimer > 2.4f) {
            demoTimer = 0;
            demoShots++;
            float minX = 99, maxX = 0, maxY = 0;
            for (Defs.Spec s : Defs.LEVELS[demoLevel].specs) {
                minX = Math.min(minX, s.x);
                maxX = Math.max(maxX, s.x);
                maxY = Math.max(maxY, s.y);
            }
            float tx = minX + (float) Math.random() * (maxX - minX) * 0.5f;
            float ty = 0.5f + (float) Math.random() * maxY;
            float th = (float) Math.toRadians(18 + Math.random() * 25);
            float dx = tx - GameWorld.POUCH_X, dy = ty - GameWorld.POUCH_Y;
            float den = (float) (2 * Math.cos(th) * Math.cos(th) * (dx * Math.tan(th) - dy));
            float v = den > 0 ? (float) Math.sqrt(-GameWorld.GRAVITY * dx * dx / den) : MAX_SPEED;
            v = Math.min(v, MAX_SPEED);
            int type = (int) (Math.random() * Defs.NUM_AMMO);
            demo.launch(type, GameWorld.POUCH_X, GameWorld.POUCH_Y, (float) Math.cos(th) * v, (float) Math.sin(th) * v);
            if (Defs.tappable(type)) demoTrigger = 0.55f;
        } else if (demoShots >= 4 && demoTimer > 4f) {
            demoLevel = (demoLevel + 7) % Defs.LEVELS.length;
            demo.load(Defs.LEVELS[demoLevel]);
            demoShots = 0;
            demoTimer = 0;
        }
        if (demoTrigger > 0) {
            demoTrigger -= dt;
            if (demoTrigger <= 0) demo.trigger();
        }
    }

    // ================================================================ world rendering

    private float sx(float wx) { return (wx - viewL) * sc; }

    private float sy(float wy) { return H - (wy - viewB) * sc; }

    private float wx(float px) { return px / sc + viewL; }

    private float wy(float py) { return (H - py) / sc + viewB; }

    private void setupCamera() {
        sc = s0 * camZ;
        float viewW = W / sc;
        viewL = camX - viewW / 2f;
        viewB = -4.6f + camY;
    }

    private int skinNow() {
        if (screen != SC_GAME || cur == null) return pr.skinFor(0);
        return pr.skinFor(mode == M_CAMPAIGN ? world : themeWorld(cur.theme));
    }

    private static int themeWorld(int theme) {
        for (int i = 0; i < Defs.WORLD_THEME.length; i++) if (Defs.WORLD_THEME[i] == theme) return i;
        return 0;
    }

    private void drawWorld(Canvas c, GameWorld g, int theme, boolean loaded, int loadedAmmo, float px, float py, int skin) {
        setupCamera();
        float horizon = H - (Art.DY - viewB) * s0;
        art.drawBackground(c, W, H, theme, horizon, (camX - 19f) * s0, time);
        if (g.wind != 0) drawWind(c, g.wind);

        float shx = 0, shy = 0;
        if (g.shake > 0) {
            shx = (float) (Math.random() - 0.5) * g.shake * 0.6f * sc;
            shy = (float) (Math.random() - 0.5) * g.shake * 0.6f * sc;
        }
        c.save();
        c.translate(-viewL * sc + shx, H + viewB * sc + shy);
        c.scale(sc, -sc);
        art.drawGround(c, viewL - 2, viewL + W / sc + 2, viewB - 1, theme);
        p.setColor(0x26000000);
        if (g.platform == null) {
            for (GameWorld.Block b : g.blocks) {
                Vec2 bp = b.body.getPosition();
                if (bp.y < 2.5f) {
                    rf.set(bp.x - b.w * 0.5f + 0.1f, 0.02f, bp.x + b.w * 0.5f + Art.DX, Art.DY);
                    c.drawRect(rf, p);
                }
            }
        }
        art.drawPlatform(c, g);
        art.drawSlingBack(c, px, py, skin);
        if (loaded) {
            c.save();
            c.translate(px, py);
            art.drawAmmo(c, loadedAmmo);
            c.restore();
        }
        art.drawSlingFront(c, px, py, skin);
        for (int i = 0, n = g.blocks.size(); i < n; i++) art.drawBlockDepth(c, g.blocks.get(i));
        for (int i = 0, n = g.shots.size(); i < n; i++) {
            GameWorld.Shot s = g.shots.get(i);
            if (!s.gone) art.drawShotDepth(c, s);
        }
        for (int i = 0, n = g.blocks.size(); i < n; i++) art.drawBlock(c, g.blocks.get(i));
        for (int i = 0, n = g.shots.size(); i < n; i++) {
            GameWorld.Shot s = g.shots.get(i);
            if (s.gone) continue;
            Vec2 sp = s.body.getPosition();
            c.save();
            c.translate(sp.x, sp.y);
            c.rotate(s.body.getAngle() * 57.29578f);
            art.drawAmmo(c, s.type);
            c.restore();
        }
        if (g.def != null) art.drawMarkers(c, g.blocks, g.def.objective);
        if (g.vortexT > 0) art.drawVortex(c, g.vortexX, g.vortexY, g.vortexT, time);
        art.drawParticles(c, g.particles);
        c.restore();
        art.drawAmbient(c, W, H, theme, dtLast, time);
    }

    private void drawWind(Canvas c, float wind) {
        p.setColor(0x40FFFFFF);
        float dir = Math.signum(wind), sp = Math.abs(wind);
        for (int i = 0; i < 14; i++) {
            float y = H * (0.12f + 0.06f * i);
            float len = W * (0.04f + 0.02f * (i % 3)) * (0.5f + sp * 0.12f);
            float span = W + len * 2;
            float x = (((i * 0.37f * span) + time * W * 0.12f * (0.6f + sp * 0.15f) * dir) % span + span) % span - len;
            c.drawRect(x, y, x + len, y + H * 0.004f, p);
        }
    }

    private float pouchX() { return GameWorld.POUCH_X + (aiming ? pullX : 0); }

    private float pouchY() { return GameWorld.POUCH_Y + (aiming ? pullY : 0); }

    // ================================================================ render

    private void render(Canvas c) {
        ui.hits.clear();
        if (replay != null) {
            renderReplay(c);
            return;
        }
        if (screen == SC_GAME) {
            boolean loaded = state == ST_AIM && !showResult;
            int la = planning && planSel < plan.size() ? plan.get(planSel).ammo : ammo;
            drawWorld(c, game, cur.theme, loaded && !planRun, la, planning && !aiming && planSel < plan.size() ? plan.get(planSel).px : pouchX(),
                    planning && !aiming && planSel < plan.size() ? plan.get(planSel).py : pouchY(), skinNow());
            if (planning && !showResult) drawPlanPreview(c);
            else if (aiming && loaded) drawTrajectory(c);
            drawWorldTexts(c, game);
        } else if (screen == SC_BUILDER) {
            renderBuilderWorld(c);
        } else if (screen != SC_ARMORY && screen != SC_MISSIONS) {
            drawWorld(c, demo, Defs.LEVELS[demoLevel].theme, false, 0, GameWorld.POUCH_X, GameWorld.POUCH_Y, pr.skinFor(Defs.worldOf(demoLevel)));
        }
        c.save();
        c.translate(ox, oy);
        c.scale(k, k);
        switch (screen) {
            case SC_MENU: drawMenu(c); break;
            case SC_WORLDS: drawWorlds(c); break;
            case SC_LEVELS: drawLevels(c); break;
            case SC_ARMORY: drawArmory(c); break;
            case SC_MISSIONS: drawMissions(c); break;
            case SC_CODES: drawCodes(c); break;
            case SC_BUILDER: drawBuilderUi(c); break;
            case SC_GAME:
                if (!showResult) drawHud(c);
                if (paused) drawPause(c);
                if (showResult) drawResult(c);
                if (vsInterstitial) drawInterstitial(c);
                if (hintOpen) drawHintPanel(c);
                if (adWaitT >= 0) drawAdWait(c);
                break;
        }
        if (chest != null) drawChestOverlay(c);
        if (toastT > 0 && toast != null) {
            float a = Math.min(1f, toastT * 3f);
            float w = ui.width(toast, 30) + 60;
            rf.set(800 - w / 2, Bm - 175, 800 + w / 2, Bm - 125);
            p.setColor(Defs.withAlpha(0xFF22123A, (int) (230 * a)));
            c.drawRoundRect(rf, 25, 25, p);
            ui.textC(c, toast, 800, rf.centerY(), 30, Defs.withAlpha(0xFFFFD23F, (int) (255 * a)), 0);
        }
        c.restore();
        if (fade > 0) {
            p.setColor(Defs.withAlpha(0xFF0B0820, (int) (fade * 255)));
            c.drawRect(0, 0, W, H, p);
        }
    }

    private void drawWorldTexts(Canvas c, GameWorld g) {
        for (GameWorld.FloatText t : g.texts) {
            float a = Math.min(1f, t.life * 2.5f);
            float pop = 1f + Math.max(0, (t.life - 0.85f)) * 2f;
            float size = 42 * k * pop * t.size;
            ui.tp.setTextAlign(Paint.Align.CENTER);
            ui.tp.setTextSize(size);
            float x = sx(t.x), y = sy(t.y);
            ui.tp.setStyle(Paint.Style.STROKE);
            ui.tp.setStrokeWidth(size * 0.2f);
            ui.tp.setColor(Defs.withAlpha(Ui.INK, (int) (255 * a)));
            c.drawText(t.text, x, y, ui.tp);
            ui.tp.setStyle(Paint.Style.FILL);
            ui.tp.setColor(Defs.withAlpha(t.color, (int) (255 * a)));
            c.drawText(t.text, x, y, ui.tp);
        }
        for (GameWorld.Shot s : g.shots) {
            if (s.gone) continue;
            Vec2 sp = s.body.getPosition();
            if (sy(sp.y) < 0) {
                float x = sx(sp.x), u = H / 100f;
                path.reset();
                path.moveTo(x, 1.2f * u);
                path.lineTo(x - 1.8f * u, 4.2f * u);
                path.lineTo(x + 1.8f * u, 4.2f * u);
                path.close();
                p.setColor(0xCCFFFFFF);
                c.drawPath(path, p);
            }
        }
    }

    private void drawTrajectory(Canvas c) {
        float len = (float) Math.hypot(pullX, pullY);
        if (len < 0.35f) return;
        float vx = -pullX * MAX_SPEED / MAX_PULL, vy = -pullY * MAX_SPEED / MAX_PULL;
        float x = pouchX(), y = pouchY();
        int dots = Progress.AIM_DOTS[Math.min(3, pr.upg(Progress.UPG_AIM))];
        for (int i = 1; i <= dots; i++) {
            float t = i * 0.075f;
            float wx = x + vx * t, wy = y + vy * t + 0.5f * GameWorld.GRAVITY * t * t;
            if (wy < 0) break;
            float a = 1f - i / (dots + 2f);
            p.setColor(Defs.withAlpha(0xFFFFFFFF, (int) (235 * a)));
            c.drawCircle(sx(wx), sy(wy), (11f - i * 0.25f) * k, p);
        }
        int pct = Math.round(Math.min(1f, len / MAX_PULL) * 100);
        ui.tp.setTextAlign(Paint.Align.CENTER);
        float size = 34 * k;
        ui.tp.setTextSize(size);
        float bx = sx(pouchX()), by = sy(pouchY()) - 70 * k;
        ui.tp.setStyle(Paint.Style.STROKE);
        ui.tp.setStrokeWidth(size * 0.22f);
        ui.tp.setColor(Ui.INK);
        c.drawText(pct + "%", bx, by, ui.tp);
        ui.tp.setStyle(Paint.Style.FILL);
        ui.tp.setColor(0xFFFFFFFF);
        c.drawText(pct + "%", bx, by, ui.tp);
    }

    // ================================================================ replay rendering

    private void renderReplay(Canvas c) {
        GameWorld.Clip cl = replay;
        int frames = cl.blocks.size();
        float playSpeed = 0.45f;
        int fi = Math.min(frames - 1, (int) (replayT * 30f * playSpeed));
        float total = frames / (30f * playSpeed);
        float seg = replayT / total;
        int cam = seg < 0.34f ? 0 : (seg < 0.67f ? 1 : 2);
        float tz, tdx, tdy;
        if (cam == 0) { tz = 1.0f; tdx = 0.42f; tdy = 0.30f; }
        else if (cam == 1) { tz = 1.65f; tdx = 0.85f; tdy = 0.10f; }
        else { tz = 1.3f; tdx = 0.2f; tdy = 0.62f; }
        float kk = Math.min(1, dtLast * 3);
        Art.DX += (tdx - Art.DX) * kk;
        Art.DY += (tdy - Art.DY) * kk;
        float[] spf = cl.sp.get(fi);
        float fx = 31, fy = 4;
        float[] bt = cl.bt.get(fi);
        if (spf.length >= 3 && cam != 0) {
            fx = spf[0];
            fy = spf[1];
        } else if (bt.length > 0) {
            float sxs = 0, sys = 0;
            int n = bt.length / 4;
            for (int i = 0; i < n; i++) { sxs += bt[i * 4]; sys += bt[i * 4 + 1]; }
            fx = sxs / n;
            fy = sys / n;
        }
        float kc = Math.min(1, dtLast * 2.5f);
        rCamX += (fx - rCamX) * kc;
        rCamY += (fy - rCamY) * kc;
        rZoom += (tz - rZoom) * kc;
        float saveX = camX, saveZ = camZ, saveY = camY;
        camX = Math.max(14, rCamX);
        camZ = rZoom;
        camY = rZoom > 1.2f ? Math.max(0, (rCamY - 5f) * 0.6f) : 0;
        setupCamera();
        float horizon = H - (Art.DY - viewB) * s0;
        art.drawBackground(c, W, H, cur.theme, horizon, (camX - 19f) * s0, time);
        c.save();
        c.translate(-viewL * sc, H + viewB * sc);
        c.scale(sc, -sc);
        art.drawGround(c, viewL - 2, viewL + W / sc + 2, viewB - 1, cur.theme);
        art.drawSlingBack(c, GameWorld.POUCH_X, GameWorld.POUCH_Y, skinNow());
        art.drawSlingFront(c, GameWorld.POUCH_X, GameWorld.POUCH_Y, skinNow());
        GameWorld.Block[] bs = cl.blocks.get(fi);
        for (int i = 0; i < bs.length; i++) art.drawBlockDepthAt(c, bs[i], bt[i * 4], bt[i * 4 + 1], bt[i * 4 + 2]);
        for (int i = 0; i < bs.length; i++) art.drawBlockAt(c, bs[i], bt[i * 4], bt[i * 4 + 1], bt[i * 4 + 2], bt[i * 4 + 3]);
        int[] st = cl.st.get(fi);
        for (int i = 0; i < st.length; i++) {
            c.save();
            c.translate(spf[i * 3], spf[i * 3 + 1]);
            c.rotate(spf[i * 3 + 2] * 57.29578f);
            art.drawAmmo(c, st[i]);
            c.restore();
        }
        c.restore();
        camX = saveX;
        camZ = saveZ;
        camY = saveY;
        c.save();
        c.translate(ox, oy);
        c.scale(k, k);
        p.setColor(0xFF000000);
        c.drawRect(L, T, R, T + 70, p);
        c.drawRect(L, Bm - 70, R, Bm, p);
        float blink = (float) Math.sin(time * 6) > 0 ? 1 : 0.3f;
        p.setColor(Defs.withAlpha(0xFFF2443A, (int) (255 * blink)));
        c.drawCircle(L + 50, T + 35, 12, p);
        ui.text(c, "REPLAY", L + 74, T + 35, 30, 0xFFFFFFFF, 0, Paint.Align.LEFT);
        String[] camName = {"WIDE SHOT", "CLOSE-UP", "BIRD'S EYE"};
        ui.text(c, "CAM " + (cam + 1) + "  •  " + camName[cam], R - 40, T + 35, 26, 0xCCFFFFFF, 0, Paint.Align.RIGHT);
        ui.textC(c, "+" + Math.round(cl.gain * 100) + "% IN ONE SHOT!", 800, Bm - 35, 30, 0xFFFFD23F, 0);
        ui.text(c, "TAP TO SKIP", R - 40, Bm - 35, 22, 0x99FFFFFF, 0, Paint.Align.RIGHT);
        c.restore();
        if (replayT > total + 0.6f) endReplay();
    }

    // ================================================================ menu

    private void drawMenu(Canvas c) {
        p.setShader(new LinearGradient(0, T, 0, Bm, 0xA60B0A2A, 0x1A0B0A2A, Shader.TileMode.CLAMP));
        c.drawRect(L, T, R, Bm, p);
        p.setShader(null);
        float bob = (float) Math.sin(time * 2.2f) * 5;
        c.save();
        c.rotate(3 + (float) Math.sin(time * 1.3f) * 1.2f, 800, 120);
        ui.title(c, "SLING", 800, 72 + bob, 118, 0xFFFFF39A, 0xFFFFB31F, 0xFF7A3E00);
        ui.title(c, "SMASH!", 800, 180 + bob, 136, 0xFFFF9A6A, 0xFFE8341C, 0xFF7A1A0A);
        c.restore();
        float pulse = 1f + (float) Math.sin(time * 4f) * 0.035f;
        c.save();
        c.scale(pulse, pulse, 800, 334);
        ui.button(c, B_PLAY, 800, 334, "PLAY", 64, Ui.GREEN, 320);
        c.restore();
        String[] lb = {"ENDLESS", "DAILY", "BUILD"};
        int[] ids = {B_ENDLESS, B_DAILY, B_BUILD};
        int[][] cols = {Ui.PURPLE, Ui.YELLOW, Ui.BLUE};
        float bw = 250, gap = 26, x0 = 800 - (3 * bw + 2 * gap) / 2;
        for (int i = 0; i < 3; i++) ui.button(c, ids[i], x0 + bw / 2 + i * (bw + gap), 462, lb[i], 36, cols[i], bw);
        ui.textC(c, "BEST WAVE " + pr.endlessBestWave(), x0 + bw / 2, 522, 20, 0xDDFFFFFF, 3);
        ui.textC(c, pr.dailyRewardClaimed() ? "BEST " + String.format(Locale.US, "%,d", pr.dailyBest()) : "NEW CHALLENGE!", x0 + bw * 1.5f + gap, 522, 20,
                pr.dailyRewardClaimed() ? 0xDDFFFFFF : 0xFFFFE066, 3);
        ui.textC(c, "EDITOR  •  2 PLAYERS", x0 + bw * 2.5f + gap * 2, 522, 20, 0xDDFFFFFF, 3);
        float bw2 = 300;
        ui.button(c, B_ARMORY, 800 - bw2 / 2 - 14, 604, "ARMORY", 36, Ui.ORANGE, bw2);
        ui.button(c, B_MISSIONS, 800 + bw2 / 2 + 14, 604, "MISSIONS", 36, Ui.RED, bw2);
        int ready = pr.missionsReady();
        if (ready > 0) badge(c, 800 + bw2 + 14 - 10, 570, String.valueOf(ready));
        float cw = ui.pill(c, R - 32, T + 28, 0, String.format(Locale.US, "%,d", pr.coins()), 0xFFFFE066, true);
        ui.pill(c, R - 32 - cw - 20, T + 28, 1, pr.totalStars() + " / " + Defs.LEVELS.length * 3, 0xFFFFFFFF, true);
        ui.iconButton(c, B_SOUND, L + 40, Bm - 120, 80, sfx.muted ? Ui.G_MUTE : Ui.G_SOUND, Ui.BLUE);
        ui.iconButton(c, B_VIBE, L + 140, Bm - 120, 80, vibeOn ? Ui.G_VIBE : Ui.G_NOVIBE, Ui.BLUE);
        ui.iconButton(c, B_CODES, L + 240, Bm - 120, 80, Ui.G_KEY, Ui.PURPLE);
        ui.textC(c, "CODES", L + 280, Bm - 22, 18, 0xFFFFFFFF, 3);
    }

    private void badge(Canvas c, float x, float y, String s) {
        float pulse = 1f + 0.1f * (float) Math.sin(time * 8);
        p.setColor(Ui.INK);
        c.drawCircle(x, y, 22 * pulse, p);
        p.setColor(0xFFF2443A);
        c.drawCircle(x, y, 18 * pulse, p);
        ui.textC(c, s, x, y, 24, 0xFFFFFFFF, 0);
    }

    private void header(Canvas c, String title, String sub) {
        ui.iconButton(c, B_BACK, L + 40, T + 28, 88, Ui.G_BACK, Ui.ORANGE);
        ui.title(c, title, 800, T + 62, 64, 0xFFFFF39A, 0xFFFFB31F, 0xFF7A3E00);
        if (sub != null) ui.textC(c, sub, 800, T + 118, 26, 0xFFFFFFFF, 4);
        ui.pill(c, R - 32, T + 34, 0, String.format(Locale.US, "%,d", pr.coins()), 0xFFFFE066, true);
    }

    // ================================================================ worlds / levels

    private void drawWorlds(Canvas c) {
        p.setShader(new LinearGradient(0, T, 0, Bm, 0xD10B0A2A, 0x8C0B0A2A, Shader.TileMode.CLAMP));
        c.drawRect(L, T, R, Bm, p);
        p.setShader(null);
        header(c, "CHOOSE A WORLD", "TOTAL STARS " + pr.totalStars() + " / " + Defs.LEVELS.length * 3);
        int[] showcase = {2, 9, 18, 28, 42, 53};
        int nw = Defs.WORLD_NAME.length;
        float cw = 238, gap = 14, cx0 = 800 - (nw * cw + (nw - 1) * gap) / 2;
        for (int i = 0; i < nw; i++) {
            float x = cx0 + i * (cw + gap), y = 150;
            boolean unlocked = pr.worldUnlocked(i);
            float enter = Math.min(1f, Math.max(0f, (1f - fade) * 1.6f - i * 0.08f));
            float s = (ui.pressed(B_WORLD + i) ? 0.95f : 1f) * (0.88f + 0.12f * enter);
            c.save();
            c.scale(s, s, x + cw / 2, y + 255);
            int theme = Defs.WORLD_THEME[i];
            int[] t = Art.THEMES[theme];
            rf.set(x, y + 14, x + cw, y + 524);
            p.setColor(0x73000000);
            c.drawRoundRect(rf, 32, 32, p);
            rf.set(x - 6, y - 6, x + cw + 6, y + 516);
            p.setColor(i == world && unlocked ? 0xFFFFD23F : Ui.INK);
            c.drawRoundRect(rf, 38, 38, p);
            c.save();
            path.reset();
            rf.set(x, y, x + cw, y + 510);
            path.addRoundRect(rf, 32, 32, Path.Direction.CW);
            c.clipPath(path);
            p.setShader(new LinearGradient(0, y, 0, y + 380, t[0], t[1], Shader.TileMode.CLAMP));
            c.drawRect(rf, p);
            p.setShader(null);
            path.reset();
            path.moveTo(x, y + 372);
            for (int j = 0; j <= 20; j++) {
                float u = j / 20f;
                path.lineTo(x + u * cw, y + 372 - 20 - (float) (Math.sin(u * 3 + i) * 0.5 + 0.5) * 90);
            }
            path.lineTo(x + cw, y + 372);
            path.close();
            p.setColor(t[3]);
            c.drawPath(path, p);
            p.setColor(Defs.shade(t[5], 0.9f));
            c.drawRect(x, y + 360, x + cw, y + 382, p);
            p.setColor(t[6]);
            c.drawRect(x, y + 380, x + cw, y + 510, p);
            drawBuildingPreview(c, Defs.LEVELS[showcase[i]], x + 14, y + 110, cw - 28, 250, y + 370);
            if (!unlocked) {
                p.setColor(0xB3120B2A);
                c.drawRect(rf, p);
            }
            c.restore();
            p.setColor(Ui.INK);
            c.drawCircle(x + 45, y + 45, 27, p);
            ui.textC(c, String.valueOf(i + 1), x + 45, y + 45, 34, 0xFFFFFFFF, 0);
            String nm = Defs.WORLD_NAME[i].toUpperCase(Locale.US);
            ui.textC(c, nm, x + cw / 2, y + 410, nm.length() > 11 ? 26 : 32, 0xFFFFFFFF, 6);
            if (unlocked) {
                int ws = pr.worldStars(i), maxS = Defs.LEVELS_PER_WORLD * 3;
                rf.set(x + 28, y + 442, x + cw - 28, y + 464);
                p.setColor(0xCC120B2A);
                c.drawRoundRect(rf, 11, 11, p);
                if (ws > 0) {
                    rf.set(x + 28, y + 442, x + 28 + Math.max(22, (cw - 56) * ws / maxS), y + 464);
                    p.setShader(new LinearGradient(x + 28, 0, x + cw - 28, 0, 0xFFFFE780, 0xFFFFB31F, Shader.TileMode.CLAMP));
                    c.drawRoundRect(rf, 11, 11, p);
                    p.setShader(null);
                }
                ui.star(c, x + cw / 2 - 40, y + 486, 17, true, 1, 0);
                ui.text(c, ws + "/" + maxS, x + cw / 2 - 18, y + 486, 28, 0xFFFFFFFF, 4, Paint.Align.LEFT);
            } else {
                ui.glyph(c, Ui.G_LOCK, x + cw / 2, y + 230, 60);
                ui.star(c, x + 62, y + 470, 18, true, 1, 0);
                ui.text(c, Defs.WORLD_REQ[i] + " TO OPEN", x + 86, y + 470, 24, 0xFFFFFFFF, 4, Paint.Align.LEFT);
            }
            c.restore();
            ui.hit(B_WORLD + i, x, y, x + cw, y + 510);
        }
    }

    private void drawBuildingPreview(Canvas c, Defs.LevelDef d, float x, float y, float w, float h, float groundY) {
        float minX = 1e9f, maxX = -1e9f, maxY = 0;
        ArrayList<Defs.Spec> l = new ArrayList<>();
        for (Defs.Spec s : d.specs) {
            if ((s.flags & Defs.F_PROTECT) != 0) continue;
            l.add(s);
            minX = Math.min(minX, s.x - s.w / 2);
            maxX = Math.max(maxX, s.x + s.w / 2);
            maxY = Math.max(maxY, s.verts != null ? s.y + s.h * 2f / 3f : s.y + s.h / 2);
        }
        if (minX > maxX) return;
        float scale = Math.min(w / (maxX - minX + Art.DX), (groundY - y) / (maxY + Art.DY + 0.3f));
        c.save();
        c.translate(x + w / 2 - (minX + maxX + Art.DX) / 2 * scale, groundY);
        c.scale(scale, -scale);
        art.drawSpecPreview(c, l);
        c.restore();
    }

    private static final String[] OBJ_TAG = {"SMASH", "CROWN", "TARGETS", "PROTECT", "TIMED", "BOSS"};
    private static final int[] OBJ_COL = {0xFF5B6CFF, 0xFFE0A520, 0xFFF2443A, 0xFF2FAE40, 0xFF8A4DFF, 0xFFB8000F};

    private void drawLevels(Canvas c) {
        p.setShader(new LinearGradient(0, T, 0, Bm, 0xD90B0A2A, 0x990B0A2A, Shader.TileMode.CLAMP));
        c.drawRect(L, T, R, Bm, p);
        p.setShader(null);
        header(c, Defs.WORLD_NAME[world].toUpperCase(Locale.US), "WORLD " + (world + 1) + "  •  " + pr.worldStars(world) + " / " + Defs.LEVELS_PER_WORLD * 3);
        float cw = 280, ch = 196, gx = 22, gy = 18;
        float x0 = 800 - (5 * cw + 4 * gx) / 2, y0 = 160;
        for (int i = 0; i < Defs.LEVELS_PER_WORLD; i++) {
            int lvl = world * Defs.LEVELS_PER_WORLD + i;
            Defs.LevelDef d = Defs.LEVELS[lvl];
            boolean unlocked = pr.levelUnlocked(lvl);
            int col = i % 5, row = i / 5;
            float x = x0 + col * (cw + gx) + (row == 1 ? (cw + gx) / 2 : 0), y = y0 + row * (ch + gy);
            boolean boss = d.boss;
            float enter = Math.min(1f, Math.max(0f, (1f - fade) * 1.6f - i * 0.05f));
            float s = (ui.pressed(B_LEVEL + i) ? 0.95f : 1f) * (0.86f + 0.14f * enter);
            c.save();
            c.scale(s, s, x + cw / 2, y + ch / 2);
            rf.set(x, y + 10, x + cw, y + ch + 10);
            p.setColor(0x73000000);
            c.drawRoundRect(rf, 26, 26, p);
            rf.set(x - 5, y - 5, x + cw + 5, y + ch + 5);
            p.setColor(boss ? 0xFFF2443A : Ui.INK);
            c.drawRoundRect(rf, 30, 30, p);
            rf.set(x, y, x + cw, y + ch);
            p.setColor(boss ? 0xFFFFE3DC : 0xFFFFF6E3);
            c.drawRoundRect(rf, 26, 26, p);
            c.save();
            path.reset();
            rf.set(x + 7, y + 7, x + cw - 7, y + ch - 52);
            path.addRoundRect(rf, 20, 20, Path.Direction.CW);
            c.clipPath(path);
            int[] t = Art.THEMES[d.theme];
            p.setShader(new LinearGradient(0, y + 7, 0, y + ch - 60, t[0], t[1], Shader.TileMode.CLAMP));
            c.drawRect(rf, p);
            p.setShader(null);
            p.setColor(Defs.shade(t[5], 1.05f));
            c.drawRect(x + 7, rf.bottom - 30, x + cw - 7, rf.bottom - 22, p);
            p.setColor(t[6]);
            c.drawRect(x + 7, rf.bottom - 22, x + cw - 7, rf.bottom, p);
            drawBuildingPreview(c, d, x + 30, y + 22, cw - 60, ch - 90, rf.bottom - 26);
            if (!unlocked) {
                p.setColor(0xB3120B2A);
                c.drawRect(rf, p);
                ui.glyph(c, Ui.G_LOCK, x + cw / 2, rf.centerY(), 34);
            }
            c.restore();
            p.setColor(Ui.INK);
            c.drawCircle(x + 34, y + 34, 21, p);
            ui.textC(c, String.valueOf(lvl + 1), x + 34, y + 34, 24, 0xFFFFFFFF, 0);
            String tag = OBJ_TAG[d.objective];
            float tw = ui.width(tag, 18) + 20;
            rf.set(x + cw - 14 - tw, y + 18, x + cw - 14, y + 48);
            p.setColor(Ui.INK);
            c.drawRoundRect(rf.left - 3, rf.top - 3, rf.right + 3, rf.bottom + 3, 18, 18, p);
            p.setColor(OBJ_COL[d.objective]);
            c.drawRoundRect(rf, 15, 15, p);
            ui.textC(c, tag, rf.centerX(), rf.centerY(), 18, 0xFFFFFFFF, 0);
            int st = pr.stars(lvl);
            String nm = d.name.replace("BOSS: ", "").toUpperCase(Locale.US);
            float ns = nm.length() > 15 ? 18 : (nm.length() > 12 ? 20 : 23);
            ui.text(c, nm, x + 16, y + ch - 26, ns, Ui.INK, 0, Paint.Align.LEFT);
            for (int j = 0; j < 3; j++) ui.star(c, x + cw - 24 - (2 - j) * 27, y + ch - 26, 12, j < st, 1, 0);
            c.restore();
            ui.hit(B_LEVEL + i, x, y, x + cw, y + ch);
        }
    }

    // ================================================================ HUD

    private float barX0, barY, barW, barVisW;
    private static final float SLOT = 80, SLOT_GAP = 14;

    private void modPill(Canvas c, float y, String s, int color, int bg) {
        float w = ui.width(s, 22) + 40;
        rf.set(L + 32, y, L + 32 + w, y + 44);
        p.setColor(bg);
        c.drawRoundRect(rf, 22, 22, p);
        ui.text(c, s, L + 52, y + 22, 22, color, 0, Paint.Align.LEFT);
    }

    private void drawHud(Canvas c) {
        Defs.LevelDef def = cur;
        ui.iconButton(c, B_PAUSE, L + 32, T + 24, 84, Ui.G_PAUSE, Ui.BLUE);
        ui.iconButton(c, B_RESTART, L + 132, T + 24, 84, Ui.G_RESTART, Ui.ORANGE);
        if (!planning && !planRun && state == ST_AIM && shotsLeft > 0) {
            boolean lab = def.theme == Defs.T_LAB;
            float ps = lab && shotsFired == 0 ? 1f + 0.06f * (float) Math.sin(time * 6) : 1f;
            c.save();
            c.scale(ps, ps, L + 322, T + 66);
            ui.button(c, B_PLAN, L + 322, T + 66, "PLAN", 30, Ui.PURPLE, 170);
            c.restore();
            if (mode == M_CAMPAIGN && Solutions.get(level) != null) {
                ui.iconButton(c, B_HINT, L + 420, T + 24, 84, Ui.G_BULB, Ui.YELLOW);
                if (!hintUnlocked() && solAds() < 2) {
                    rf.set(L + 452, T + 4, L + 512, T + 34);
                    p.setColor(Ui.INK);
                    c.drawRoundRect(rf, 15, 15, p);
                    rf.set(L + 455, T + 7, L + 509, T + 31);
                    p.setColor(0xFFF2443A);
                    c.drawRoundRect(rf, 12, 12, p);
                    ui.textC(c, "AD", L + 482, T + 19, 18, 0xFFFFFFFF, 0);
                }
            }
        }

        float d = game.destruction();
        String title;
        switch (mode) {
            case M_ENDLESS: title = "WAVE " + wave + "  •  " + def.name.toUpperCase(Locale.US); break;
            case M_DAILY: title = "DAILY  •  " + def.name.toUpperCase(Locale.US); break;
            case M_TEST: title = "TEST YOUR BUILDING"; break;
            case M_VERSUS: title = "PLAYER " + (vsPhase == 1 ? 2 : 1) + " - SMASH IT!"; break;
            default: title = (level + 1) + ". " + def.name.toUpperCase(Locale.US);
        }
        ui.textC(c, title, 800, T + 30, 26, 0xFFFFFFFF, 5);
        float[] th = mode == M_CAMPAIGN || mode == M_DAILY ? (def.objective == Defs.O_DESTROY ? new float[]{0.5f, def.star2} : new float[]{def.star2}) : new float[0];
        ui.meter(c, 520, T + 62, 560, d, th);
        int obj = game.objectiveState();
        if (!planning) {
        String ot = mode == M_TEST || mode == M_VERSUS ? Math.round(d * 100) + "% DESTROYED" : game.objectiveProgress();
        float ow = ui.width(ot, 24) + 70;
        rf.set(800 - ow / 2, T + 108, 800 + ow / 2, T + 148);
        p.setColor(mode == M_TEST || mode == M_VERSUS ? 0xB8120B2A : (obj == 1 ? 0xE62FAE40 : (obj == -1 ? 0xE6F2443A : 0xB8120B2A)));
        c.drawRoundRect(rf, 20, 20, p);
        boolean check = obj == 1 && mode != M_TEST && mode != M_VERSUS;
        if (check) ui.glyph(c, Ui.G_CHECK, rf.left + 26, rf.centerY(), 14);
        ui.textC(c, ot, 800 + (check ? 12 : 0), rf.centerY(), 24, 0xFFFFFFFF, 3);
        }
        if (def.objective == Defs.O_TIME && mode != M_TEST && !planning) {
            float tl = game.timeLeft();
            boolean urgent = tl < 4 && game.firstShotTime >= 0;
            float s = urgent ? 1f + 0.1f * (float) Math.sin(time * 14) : 1f;
            c.save();
            c.scale(s, s, 800, T + 192);
            ui.textC(c, String.format(Locale.US, "%.1f", tl), 800, T + 192, 48, urgent ? 0xFFFF6A5A : 0xFFFFFFFF, 6);
            c.restore();
        }
        float my = T + 130;
        if (game.wind != 0) {
            float w = Math.abs(game.wind);
            rf.set(L + 32, my, L + 232, my + 44);
            p.setColor(0xB8120B2A);
            c.drawRoundRect(rf, 22, 22, p);
            ui.text(c, "WIND", L + 52, my + 22, 22, 0xFFFFFFFF, 0, Paint.Align.LEFT);
            float ax = L + 130, dir = Math.signum(game.wind), len = 30 + w * 10;
            ui.ps.setColor(0xFF8FE3FF);
            ui.ps.setStrokeWidth(6);
            float sx0 = ax + (dir > 0 ? 0 : len), sx1 = ax + (dir > 0 ? len : 0);
            c.drawLine(sx0, my + 22, sx1, my + 22, ui.ps);
            path.reset();
            path.moveTo(sx1 + dir * 12, my + 22);
            path.lineTo(sx1 - dir * 4, my + 12);
            path.lineTo(sx1 - dir * 4, my + 32);
            path.close();
            p.setColor(0xFF8FE3FF);
            c.drawPath(path, p);
            my += 54;
        }
        if (def.quake > 0) {
            boolean shaking = game.quakeShow > 0;
            modPill(c, my, "EARTHQUAKES", shaking ? 0xFFFFFFFF : 0xFFFFB13B, shaking ? 0xE6F2443A : 0xB8120B2A);
            my += 54;
        }
        if (def.platformAmp > 0) {
            modPill(c, my, "MOVING TARGET", 0xFFFFE066, 0xB8120B2A);
            my += 54;
        }
        if (def.regen > 0 && game.coresLeft > 0) modPill(c, my, "REGENERATES", 0xFF7CFFB0, 0xB8120B2A);

        int shownScore = mode == M_ENDLESS ? endlessScore + game.score : game.score;
        ui.text(c, String.format(Locale.US, "%,d", shownScore), R - 32, T + 50, 54, 0xFFFFE066, 7, Paint.Align.RIGHT);
        if (game.coins > 0) ui.pill(c, R - 32, T + 92, 0, "+" + game.coins, 0xFFFFE066, true);
        if (mode == M_TEST) {
            ui.text(c, "FREE PLAY", R - 32, T + 182, 26, 0xFFFFFFFF, 4, Paint.Align.RIGHT);
        } else {
            int maxShots = mode == M_ENDLESS ? shotsLeft : (mode == M_VERSUS ? 4 : def.shots + pr.upg(Progress.UPG_SHOT));
            maxShots = Math.max(maxShots, shotsLeft);
            float sx = R - 32 - 13;
            int show = Math.min(maxShots, 10);
            for (int i = show - 1; i >= 0; i--) {
                boolean has = i < shotsLeft;
                p.setColor(Ui.INK);
                c.drawCircle(sx, T + 182, 15, p);
                p.setColor(has ? 0xFFFF7A3C : 0x4DFFFFFF);
                c.drawCircle(sx, T + 182, 11, p);
                sx -= 34;
            }
            ui.text(c, shotsLeft > 10 ? "SHOTS " + shotsLeft : "SHOTS", sx + 6, T + 182, 20, 0xFFFFFFFF, 4, Paint.Align.RIGHT);
            if ((mode == M_CAMPAIGN || mode == M_DAILY) && !planning) {
                int par = def.par;
                ui.text(c, "3 STARS: " + par + " SHOTS OR LESS", R - 32, T + 220, 18, shotsFired <= par ? 0xDDFFE066 : 0xAAFF8A7A, 3, Paint.Align.RIGHT);
            }
        }

        if (game.combo >= 3 && game.time - game.lastBreak < GameWorld.COMBO_WINDOW + 0.6f) {
            float pop = 1f + game.comboFlash * 0.9f;
            c.save();
            c.rotate(-6, 800, 270);
            c.scale(pop, pop, 800, 270);
            ui.title(c, "COMBO x" + game.combo + "!", 800, 270, 60, 0xFFFFF39A, 0xFFFF9A1F, 0xFF7A3E00);
            c.restore();
        }
        if (game.bannerT > 0 && game.banner != null) {
            float t = 1.6f - game.bannerT;
            float s = t < 0.15f ? t / 0.15f * 1.25f : (t < 0.3f ? 1.25f - (t - 0.15f) / 0.15f * 0.25f : 1f);
            float a = Math.min(1f, game.bannerT * 3f);
            c.save();
            c.scale(s, s, 800, 345);
            ui.textC(c, game.banner, 800, 345, 46, Defs.withAlpha(0xFFFFFFFF, (int) (255 * a)), 7);
            c.restore();
        }
        if (waveClearT >= 0 && mode == M_ENDLESS) {
            float s = Math.min(1.1f, 0.5f + waveClearT * 2);
            c.save();
            c.scale(s, s, 800, 300);
            ui.title(c, "WAVE " + wave + " CLEAR!", 800, 300, 70, 0xFF9AFFA8, 0xFF2FAE40, 0xFF135A20);
            c.restore();
            ui.textC(c, "+" + lastWaveBonus + " SHOTS", 800, 372, 34, 0xFFFFE066, 5);
        }
        if (game.canTrigger()) {
            String h = Defs.TAP_HINT[game.lastShot.type];
            if (h != null) {
                float pulse = 1f + (float) Math.sin(time * 10) * 0.06f;
                float w = ui.width(h, 32) + 50;
                c.save();
                c.rotate(3, 800, 430);
                c.scale(pulse, pulse, 800, 430);
                rf.set(800 - w / 2 - 4, 404, 800 + w / 2 + 4, 460);
                p.setColor(Ui.INK);
                c.drawRoundRect(rf, 28, 28, p);
                rf.set(800 - w / 2, 408, 800 + w / 2, 456);
                p.setColor(0xFF8A4DFF);
                c.drawRoundRect(rf, 24, 24, p);
                ui.textC(c, h, 800, 431, 32, 0xFFFFFFFF, 4);
                c.restore();
            }
        }

        // ammo bar
        ArrayList<Integer> bl = barList();
        int n = bl.size();
        barW = n * SLOT + (n - 1) * SLOT_GAP + 36;
        barVisW = Math.min(barW, (R - L) * 0.56f);
        float maxScroll = Math.max(0, barW - barVisW);
        barScroll = Math.max(0, Math.min(maxScroll, barScroll));
        barX0 = 800 - barVisW / 2;
        barY = Bm - 14 - (SLOT + 20);
        rf.set(barX0, barY, barX0 + barVisW, barY + SLOT + 20);
        p.setColor(0x9E120C26);
        c.drawRoundRect(rf, 60, 60, p);
        ui.ps.setColor(0x33FFFFFF);
        ui.ps.setStrokeWidth(3);
        c.drawRoundRect(rf, 60, 60, ui.ps);
        c.save();
        c.clipRect(barX0 + 6, barY - 30, barX0 + barVisW - 6, barY + SLOT + 40);
        float selX = -1;
        for (int i = 0; i < n; i++) {
            int t = bl.get(i);
            float cx = barX0 + 18 + SLOT / 2 + i * (SLOT + SLOT_GAP) - barScroll;
            float cy = barY + 10 + SLOT / 2;
            boolean sel = planning && planSel < plan.size() ? t == plan.get(planSel).ammo : t == ammo;
            float bob = sel ? (float) Math.sin(time * 5) * 3 : 0;
            boolean empty = uses[t] <= 0;
            ui.ammoSlot(c, cx, cy, SLOT / 2 * (sel ? 1.06f : 1f), empty ? 2 : (sel ? 1 : 0), t, art, bob);
            if (Defs.AMMO_PRICE[t] > 0 && mode != M_TEST) {
                float bx = cx + SLOT * 0.36f, by = cy - SLOT * 0.34f;
                p.setColor(Ui.INK);
                c.drawCircle(bx, by, 15, p);
                p.setColor(empty ? 0xFF6E6A8A : 0xFF3BC44B);
                c.drawCircle(bx, by, 12, p);
                ui.textC(c, String.valueOf(Math.max(0, uses[t])), bx, by, 18, 0xFFFFFFFF, 0);
            }
            if (sel) selX = cx;
        }
        c.restore();
        if (maxScroll > 0) {
            if (barScroll > 2) chevron(c, barX0 - 24, barY + 10 + SLOT / 2, -1);
            if (barScroll < maxScroll - 2) chevron(c, barX0 + barVisW + 24, barY + 10 + SLOT / 2, 1);
        }
        ui.hit(-2, barX0, barY - 10, barX0 + barVisW, Bm);
        if (planning) drawPlanner(c);
        else if (selX >= barX0 - 10 && selX <= barX0 + barVisW + 10) {
            String nm = Defs.AMMO_NAME[ammo].toUpperCase(Locale.US);
            float w = ui.width(nm, 26) + 34;
            float lx = Math.max(L + 20 + w / 2, Math.min(R - 20 - w / 2, selX));
            rf.set(lx - w / 2 - 4, barY - 56, lx + w / 2 + 4, barY - 12);
            p.setColor(Ui.INK);
            c.drawRoundRect(rf, 22, 22, p);
            rf.set(lx - w / 2, barY - 52, lx + w / 2, barY - 16);
            p.setColor(0xFFFFD23F);
            c.drawRoundRect(rf, 18, 18, p);
            ui.textC(c, nm, lx, barY - 34, 26, Ui.INK, 0);
        }
        if ((mode == M_CAMPAIGN || mode == M_DAILY) && obj == 1 && shotsLeft > 0 && !planning) {
            float pulse = 1f + 0.04f * (float) Math.sin(time * 5);
            c.save();
            c.scale(pulse, pulse, R - 130, Bm - 70);
            ui.button(c, B_FINISH, R - 130, Bm - 70, "FINISH", 34, Ui.GREEN, 200);
            c.restore();
        }
        if (mode == M_TEST && !planning) ui.button(c, B_TO_BUILDER, R - 130, Bm - 70, "EDIT", 34, Ui.BLUE, 200);

        if (level == 0 && mode == M_CAMPAIGN && shotsFired == 0 && !aiming && state == ST_AIM) {
            float a = 0.6f + 0.4f * (float) Math.sin(time * 4);
            ui.textC(c, "DRAG BACK ANYWHERE & RELEASE TO FIRE!", 800, 300, 40, Defs.withAlpha(0xFFFFFFFF, (int) (255 * a)), 6);
            ui.textC(c, "PICK YOUR PROJECTILE BELOW", 800, 352, 28, Defs.withAlpha(0xFFFFE066, (int) (255 * a)), 5);
        } else if (shotsFired == 0 && !aiming && !planning && state == ST_AIM && stateTime < (def.hint != null ? 5.5f : 3.5f) && mode != M_TEST && mode != M_VERSUS) {
            float a = Math.min(1f, ((def.hint != null ? 5.5f : 3.5f) - stateTime) * 2);
            ui.textC(c, def.objectiveText(), 800, 300, 40, Defs.withAlpha(0xFFFFFFFF, (int) (255 * a)), 6);
            if (def.hint != null) ui.textC(c, def.hint, 800, 352, 26, Defs.withAlpha(0xFFFFE066, (int) (255 * a)), 5);
        }
        if (state == ST_WAIT && mode != M_TEST && !planRun) ui.textC(c, "NO SHOTS LEFT...", 800, 240, 36, 0xEEFFFFFF, 5);
        if (planRun) ui.textC(c, "COMBO IN PROGRESS...", 800, 240, 34, 0xEEB07CFF, 5);
    }

    private void chevron(Canvas c, float x, float y, int dir) {
        ui.ps.setColor(Ui.INK);
        ui.ps.setStrokeWidth(14);
        path.reset();
        path.moveTo(x - 8 * dir, y - 16);
        path.lineTo(x + 8 * dir, y);
        path.lineTo(x - 8 * dir, y + 16);
        c.drawPath(path, ui.ps);
        ui.ps.setColor(0xFFFFFFFF);
        ui.ps.setStrokeWidth(7);
        c.drawPath(path, ui.ps);
    }

    private void drawPause(Canvas c) {
        ui.hits.clear();
        ui.scrim(c, L, T, R, Bm, 175);
        float top = 120;
        ui.panel(c, 800, top, 600, 520, "PAUSED", Ui.BLUE);
        ui.button(c, B_RESUME, 800, top + 130, "RESUME", 46, Ui.GREEN, 330);
        ui.button(c, B_RESTART, 800, top + 240, mode == M_ENDLESS ? "NEW RUN" : "RESTART", 40, Ui.ORANGE, 330);
        String back = mode == M_CAMPAIGN ? "LEVELS" : (mode == M_TEST ? "EDITOR" : "MENU");
        ui.button(c, B_LEVELS, 800, top + 340, back, 40, Ui.BLUE, 330);
        toggle(c, B_SOUND, 590, top + 450, "SOUND", !sfx.muted);
        toggle(c, B_VIBE, 810, top + 450, "VIBRATION", vibeOn);
    }

    private void toggle(Canvas c, int id, float x, float y, String label, boolean on) {
        ui.text(c, label, x, y, 26, 0xFFFFFFFF, 0, Paint.Align.LEFT);
        float tx = x + ui.width(label, 26) + 14;
        rf.set(tx - 4, y - 26, tx + 88, y + 26);
        p.setColor(Ui.INK);
        c.drawRoundRect(rf, 26, 26, p);
        rf.set(tx, y - 22, tx + 84, y + 22);
        p.setColor(on ? 0xFF3BC44B : 0xFF4A3D86);
        c.drawRoundRect(rf, 22, 22, p);
        p.setColor(0xFFFFFFFF);
        c.drawCircle(on ? tx + 61 : tx + 23, y, 17, p);
        ui.hit(id, x - 10, y - 34, tx + 100, y + 34);
    }

    // ---------------------------------------------------------------- results

    private void drawResult(Canvas c) {
        float appear = Math.min(1f, resultT * 3f);
        float ease = 1f - (1f - appear) * (1f - appear);
        ui.scrim(c, L, T, R, Bm, (int) (150 * ease));
        c.save();
        c.translate(0, (1f - ease) * 400);
        if (mode == M_ENDLESS) drawEndlessResult(c);
        else if (mode == M_VERSUS) drawVersusResult(c);
        else drawLevelResult(c);
        c.restore();
        if (appear < 1f) ui.hits.clear();
    }

    private void drawLevelResult(Canvas c) {
        float top = 92, w = 800, h = 580;
        String title = resultStars == 3 ? "DEMOLISHED!" : (resultStars > 0 ? "LEVEL CLEAR!" : (resultFailed ? "FAILED!" : "STILL STANDING"));
        ui.panel(c, 800, top, w, h, title, resultStars > 0 ? Ui.ORANGE : Ui.GREY);
        for (int i = 0; i < 3; i++) {
            float x = 800 + (i - 1) * 150, y = top + (i == 1 ? 112 : 132);
            float r = i == 1 ? 60 : 50;
            float rot = (1 - i) * 10;
            float st = resultT - (0.55f + i * 0.4f);
            if (i >= starsPlayed || st < 0.3f) ui.star(c, x, y, r, false, 1f, rot);
            if (i < starsPlayed) {
                float pop = st < 0.18f ? 0.3f + st / 0.18f : (st < 0.3f ? 1.3f - (st - 0.18f) / 0.12f * 0.3f : 1f);
                if (st < 0.5f) ui.glow(c, x, y, r * 2.2f * Math.min(1, st * 4), 0x99FFE780);
                ui.star(c, x, y, r, true, pop, rot);
            }
        }
        int par = cur.par;
        String[] goal = {cur.objectiveText(), "DESTROY " + Math.round(cur.star2 * 100) + "% OR MORE", "USE " + par + " SHOTS OR LESS (YOU: " + shotsFired + ")"};
        float gy = top + 214;
        float gw = 0;
        for (String g : goal) gw = Math.max(gw, ui.width(g, 24));
        float gx = 800 - (gw + 32) / 2;
        for (int i = 0; i < 3; i++) {
            float y = gy + i * 40;
            ui.star(c, gx + 12, y, 14, starOk[i], 1, 0);
            ui.text(c, goal[i], gx + 38, y, 24, starOk[i] ? 0xFFFFFFFF : 0x80FFFFFF, 0, Paint.Align.LEFT);
        }
        rf.set(560, top + 340, 1040, top + 462);
        p.setColor(0x8C120B2A);
        c.drawRoundRect(rf, 24, 24, p);
        float shown = Math.min(1f, resultT / 1.4f);
        int best = mode == M_DAILY ? pr.dailyBest() : pr.best(level);
        String[] a = {"SCORE", "COINS", mode == M_DAILY ? "TODAY'S BEST" : "BEST"};
        String[] b = {String.format(Locale.US, "%,d", (int) (resultScore * shown)), "+" + (int) (coinsEarned * shown),
                newBest ? "NEW BEST!" : String.format(Locale.US, "%,d", best)};
        int[] col = {0xFFFFE066, 0xFFFFD23F, newBest ? 0xFF7CFF8A : 0xFFFFFFFF};
        for (int i = 0; i < 3; i++) {
            float y = top + 368 + i * 34;
            ui.text(c, a[i], 590, y, 26, 0xCCFFFFFF, 0, Paint.Align.LEFT);
            ui.text(c, b[i], 1010, y, 28, col[i], 0, Paint.Align.RIGHT);
        }
        float by = top + 486;
        boolean hasReplay = game.bestClip != null;
        float x0 = hasReplay ? 800 - 50 - 210 : 800 - 50 - 140;
        ui.iconButton(c, B_LEVELS, x0, by, 100, mode == M_CAMPAIGN ? Ui.G_GRID : Ui.G_HOME, Ui.BLUE);
        ui.iconButton(c, B_RETRY, x0 + 140, by, 100, Ui.G_RESTART, Ui.ORANGE);
        boolean canNext = mode == M_CAMPAIGN && level + 1 < Defs.LEVELS.length && pr.levelUnlocked(level + 1);
        ui.iconButton(c, B_NEXT, x0 + 280, by, 100, Ui.G_NEXT, canNext ? Ui.GREEN : Ui.GREY);
        if (hasReplay) ui.iconButton(c, B_REPLAY, x0 + 420, by, 100, Ui.G_CAMERA, Ui.PURPLE);
    }

    private void drawEndlessResult(Canvas c) {
        float top = 110, w = 720, h = 540;
        ui.panel(c, 800, top, w, h, "GAME OVER", Ui.PURPLE);
        ui.textC(c, "YOU REACHED", 800, top + 90, 30, 0xCCFFFFFF, 0);
        ui.title(c, "WAVE " + wave, 800, top + 165, 96, 0xFFFFF39A, 0xFFFFB31F, 0xFF7A3E00);
        rf.set(590, top + 245, 1010, top + 385);
        p.setColor(0x8C120B2A);
        c.drawRoundRect(rf, 24, 24, p);
        String[] a = {"SCORE", "COINS", "BEST WAVE"};
        String[] b = {String.format(Locale.US, "%,d", resultScore), "+" + coinsEarned, String.valueOf(pr.endlessBestWave())};
        for (int i = 0; i < 3; i++) {
            float y = top + 275 + i * 40;
            ui.text(c, a[i], 620, y, 28, 0xCCFFFFFF, 0, Paint.Align.LEFT);
            ui.text(c, b[i], 980, y, 30, i == 0 ? 0xFFFFE066 : 0xFFFFFFFF, 0, Paint.Align.RIGHT);
        }
        if (newBest) ui.textC(c, "NEW HIGH SCORE!", 800, top + 412, 30, 0xFF7CFF8A, 4);
        ui.iconButton(c, B_LEVELS, 800 - 50 - 80, top + 440, 100, Ui.G_HOME, Ui.BLUE);
        ui.iconButton(c, B_RETRY, 800 - 50 + 80, top + 440, 100, Ui.G_RESTART, Ui.ORANGE);
    }

    private void drawVersusResult(Canvas c) {
        float top = 120, w = 720, h = 500;
        if (vsPhase < 3) {
            ui.panel(c, 800, top, w, h, "ROUND OVER", Ui.BLUE);
            ui.textC(c, "PLAYER 2 DESTROYED", 800, top + 110, 32, 0xCCFFFFFF, 0);
            ui.title(c, Math.round(vsScore[1] * 100) + "%", 800, top + 210, 110, 0xFFFFF39A, 0xFFFFB31F, 0xFF7A3E00);
            ui.textC(c, "NOW PLAYER 2 BUILDS A BUILDING", 800, top + 320, 28, 0xFFFFFFFF, 4);
            ui.textC(c, "AND PLAYER 1 TRIES TO SMASH IT!", 800, top + 358, 28, 0xFFFFFFFF, 4);
            ui.button(c, B_DONE, 800, top + 440, "CONTINUE", 40, Ui.GREEN, 320);
        } else {
            float a = vsScore[0], b = vsScore[1];
            String winner = Math.abs(a - b) < 0.005f ? "IT'S A DRAW!" : (a > b ? "PLAYER 1 WINS!" : "PLAYER 2 WINS!");
            ui.panel(c, 800, top, w, h, winner, Ui.ORANGE);
            for (int i = 0; i < 2; i++) {
                float x = 800 + (i == 0 ? -170 : 170);
                ui.textC(c, "PLAYER " + (i + 1), x, top + 120, 34, 0xFFFFFFFF, 4);
                ui.title(c, Math.round(vsScore[i] * 100) + "%", x, top + 210, 90, i == 0 ? 0xFF8FE3FF : 0xFFFF9A6A, i == 0 ? 0xFF3FA6E0 : 0xFFE8341C, Ui.INK);
                if ((i == 0 && a > b) || (i == 1 && b > a)) ui.star(c, x, top + 300, 34, true, 1f + 0.08f * (float) Math.sin(time * 6), 0);
            }
            ui.textC(c, "VS", 800, top + 200, 46, 0xFFFFD23F, 6);
            ui.iconButton(c, B_LEVELS, 800 - 50 - 80, top + 380, 100, Ui.G_HOME, Ui.BLUE);
            ui.iconButton(c, B_RETRY, 800 - 50 + 80, top + 380, 100, Ui.G_RESTART, Ui.ORANGE);
        }
    }

    private void drawInterstitial(Canvas c) {
        ui.hits.clear();
        ui.scrim(c, L, T, R, Bm, 245);
        int player = vsPhase == 1 ? 2 : 1;
        ui.title(c, "PLAYER " + player, 800, 220, 110, 0xFFFFF39A, 0xFFFFB31F, 0xFF7A3E00);
        ui.textC(c, "TAKE THE PHONE - IT'S YOUR TURN TO SMASH!", 800, 330, 32, 0xFFFFFFFF, 4);
        ui.textC(c, "4 SHOTS  •  DESTROY AS MUCH AS YOU CAN", 800, 380, 26, 0xCCFFE066, 3);
        ui.button(c, B_READY, 800, 500, "READY!", 52, Ui.GREEN, 320);
    }

    // ================================================================ missions & chests

    private void drawMissions(Canvas c) {
        p.setShader(new LinearGradient(0, T, 0, Bm, 0xFF3A1A4A, 0xFF140D33, Shader.TileMode.CLAMP));
        c.drawRect(L, T, R, Bm, p);
        p.setShader(null);
        header(c, "MISSIONS", "COMPLETE MISSIONS TO OPEN TREASURE CHESTS");
        for (int i = 0; i < 3; i++) {
            float w = 440, h = 430, x = 800 - (3 * w + 2 * 30) / 2 + i * (w + 30), y = 165;
            boolean done = pr.missionDone(i);
            rf.set(x, y + 12, x + w, y + h + 12);
            p.setColor(0x80000000);
            c.drawRoundRect(rf, 30, 30, p);
            rf.set(x - 6, y - 6, x + w + 6, y + h + 6);
            p.setColor(done ? 0xFFFFD23F : Ui.INK);
            c.drawRoundRect(rf, 36, 36, p);
            rf.set(x, y, x + w, y + h);
            p.setShader(new LinearGradient(0, y, 0, y + h, 0xFF4E3D9A, 0xFF2A1E5C, Shader.TileMode.CLAMP));
            c.drawRoundRect(rf, 30, 30, p);
            p.setShader(null);
            if (done) ui.glow(c, x + w / 2, y + 130, 130 + 10 * (float) Math.sin(time * 3), 0x88FFE780);
            drawChest(c, x + w / 2, y + 130, 1.0f, 0, done ? (float) Math.sin(time * 10) * 0.05f : 0);
            float ty = y + 238;
            for (String line : wrap(pr.missionText(i).toUpperCase(Locale.US), 30, w - 50)) {
                ui.textC(c, line, x + w / 2, ty, 30, 0xFFFFFFFF, 4);
                ty += 36;
            }
            int pg = pr.missionProgress(i), tg = pr.missionTarget(i);
            rf.set(x + 40, y + 318, x + w - 40, y + 344);
            p.setColor(0xCC120B2A);
            c.drawRoundRect(rf, 13, 13, p);
            if (pg > 0) {
                rf.set(x + 40, y + 318, x + 40 + Math.max(26, (w - 80) * pg / (float) tg), y + 344);
                p.setColor(done ? 0xFF3BC44B : 0xFFFFC93C);
                c.drawRoundRect(rf, 13, 13, p);
            }
            ui.textC(c, pg + " / " + tg, x + w / 2, y + 331, 20, 0xFFFFFFFF, 3);
            if (done) ui.button(c, B_CLAIM + i, x + w / 2, y + 390, "OPEN!", 34, Ui.YELLOW, 220);
            else ui.textC(c, "IN PROGRESS", x + w / 2, y + 390, 26, 0x80FFFFFF, 0);
        }
        ui.textC(c, "BLOCKS SMASHED: " + String.format(Locale.US, "%,d", pr.stat("smashed")) + "   •   SHOTS FIRED: "
                + String.format(Locale.US, "%,d", pr.stat("shots")) + "   •   BEST COMBO: x" + pr.stat("max_combo"), 800, Bm - 40, 22, 0xAAFFFFFF, 0);
    }

    /** Treasure chest. open: 0 closed .. 1 fully open. */
    private void drawChest(Canvas c, float cx, float cy, float s, float open, float wobble) {
        c.save();
        c.translate(cx, cy);
        c.rotate(wobble * 57.3f);
        c.scale(s, s);
        p.setColor(0x55000000);
        rf.set(-90, 46, 90, 70);
        c.drawOval(rf, p);
        if (open > 0) ui.glow(c, 0, -20, 150 * open, 0xCCFFF3B0);
        int frame = Math.max(0, Math.min(5, Math.round(open * 5)));
        if (!Sprites.drawUi(c, "chest" + frame, 0, 10, 92, 255)) {
            rf.set(-75, -50, 75, 50);
            p.setColor(0xFFB86A2A);
            c.drawRoundRect(rf, 16, 16, p);
        }
        c.restore();
    }

    private void openChest(Progress.Reward r) {
        if (r == null) return;
        chest = r;
        chestT = 0;
        loadOwned();
        sfx.play(Defs.S_CHEST, 1f, 0f);
    }

    private void drawChestOverlay(Canvas c) {
        ui.hits.clear();
        ui.scrim(c, L, T, R, Bm, 225);
        float t = chestT;
        float open = t < 0.9f ? 0 : Math.min(1, (t - 0.9f) * 4);
        float wob = t < 0.9f ? (float) Math.sin(t * 40) * 0.08f * (t / 0.9f) : 0;
        if (open > 0) {
            c.save();
            c.rotate(time * 20, 800, 330);
            p.setColor(Defs.withAlpha(0xFFFFE780, (int) (70 * open)));
            for (int i = 0; i < 12; i++) {
                double a0 = i * Math.PI / 6, a1 = a0 + 0.22;
                path.reset();
                path.moveTo(800, 330);
                path.lineTo(800 + (float) Math.cos(a0) * 900, 330 + (float) Math.sin(a0) * 900);
                path.lineTo(800 + (float) Math.cos(a1) * 900, 330 + (float) Math.sin(a1) * 900);
                path.close();
                c.drawPath(path, p);
            }
            c.restore();
        }
        drawChest(c, 800, 400, 1.8f, open, wob);
        if (t > 1.1f) {
            float a = Math.min(1, (t - 1.1f) * 3);
            float rise = (1 - a) * 60;
            int ai = (int) (255 * a);
            ui.title(c, "+" + chest.coins + " COINS", 800, 180 + rise, 64, 0xFFFFF39A, 0xFFFFB31F, 0xFF7A3E00);
            if (chest.skin >= 0) {
                ui.textC(c, "NEW SLINGSHOT: " + Defs.SKIN_NAME[chest.skin].toUpperCase(Locale.US) + "!", 800, 252 + rise, 34, Defs.withAlpha(0xFF8FE3FF, ai), 5);
            } else if (chest.ammo >= 0) {
                ui.textC(c, "NEW PROJECTILE: " + Defs.AMMO_NAME[chest.ammo].toUpperCase(Locale.US) + "!", 800, 252 + rise, 34, Defs.withAlpha(0xFF7CFF8A, ai), 5);
            }
        }
        if (t > 1.6f) ui.button(c, B_CHEST_OK, 800, Bm - 90, "AWESOME!", 40, Ui.GREEN, 300);
    }

    // ================================================================ armory

    private ArrayList<Integer> armoryList() {
        ArrayList<Integer> l = new ArrayList<>();
        for (int i = 0; i < Defs.NUM_AMMO; i++) if (armoryTab == 0 || Defs.AMMO_CAT[i] == armoryTab) l.add(i);
        return l;
    }

    private void drawArmory(Canvas c) {
        p.setShader(new LinearGradient(0, T, 0, Bm, 0xFF2B1F5C, 0xFF140D33, Shader.TileMode.CLAMP));
        c.drawRect(L, T, R, Bm, p);
        p.setShader(null);
        c.save();
        c.rotate(time * 6, R - 380, 400);
        p.setColor(0x0AFFFFFF);
        for (int i = 0; i < 16; i++) {
            double a0 = i * Math.PI / 8, a1 = a0 + 0.2;
            path.reset();
            path.moveTo(R - 380, 400);
            path.lineTo(R - 380 + (float) Math.cos(a0) * 1400, 400 + (float) Math.sin(a0) * 1400);
            path.lineTo(R - 380 + (float) Math.cos(a1) * 1400, 400 + (float) Math.sin(a1) * 1400);
            path.close();
            c.drawPath(path, p);
        }
        c.restore();
        ui.iconButton(c, B_BACK, L + 32, T + 24, 84, Ui.G_BACK, Ui.ORANGE);
        ui.title(c, "ARMORY", L + 140 + ui.width("ARMORY", 64) / 2, T + 62, 64, 0xFFFFF39A, 0xFFFFB31F, 0xFF7A3E00);
        ui.pill(c, R - 32, T + 32, 0, String.format(Locale.US, "%,d", pr.coins()), 0xFFFFE066, true);
        String[] pages = {"PROJECTILES", "UPGRADES", "SLINGSHOTS"};
        float tot = 0;
        for (String pg : pages) tot += ui.width(pg, 26) + 44 + 14;
        float px = 840 - tot / 2;
        for (int i = 0; i < 3; i++) {
            float w = ui.width(pages[i], 26) + 44;
            rf.set(px - 4, T + 36, px + w + 4, T + 90);
            p.setColor(Ui.INK);
            c.drawRoundRect(rf, 27, 27, p);
            rf.set(px, T + 40, px + w, T + 86);
            p.setColor(i == armoryPage ? 0xFFFF7A3C : 0xFF3A2A78);
            c.drawRoundRect(rf, 23, 23, p);
            ui.textC(c, pages[i], px + w / 2, T + 63, 26, 0xFFFFFFFF, i == armoryPage ? 3 : 0);
            ui.hit(B_TAB + 10 + i, px, T + 30, px + w, T + 96);
            px += w + 14;
        }
        if (armoryPage == 1) { drawUpgrades(c); return; }
        if (armoryPage == 2) { drawSkins(c); return; }
        String[] tabs = {"ALL", "HEAVY", "EXPLOSIVE", "SPECIAL"};
        float tx = L + 40;
        for (int i = 0; i < 4; i++) {
            float w = ui.width(tabs[i], 24) + 44;
            rf.set(tx - 4, T + 116, tx + w + 4, T + 166);
            p.setColor(Ui.INK);
            c.drawRoundRect(rf, 25, 25, p);
            rf.set(tx, T + 120, tx + w, T + 162);
            p.setColor(i == armoryTab ? 0xFFFFD23F : 0xFF3A2A78);
            c.drawRoundRect(rf, 21, 21, p);
            ui.textC(c, tabs[i], tx + w / 2, T + 141, 24, i == armoryTab ? Ui.INK : 0xFFFFFFFF, 0);
            ui.hit(B_TAB + i, tx, T + 110, tx + w, T + 172);
            tx += w + 14;
        }
        ArrayList<Integer> list = armoryList();
        float gx = L + 40, gy = T + 190;
        float panelW = 620, panelX = R - 32 - panelW;
        int cols = Math.max(3, Math.min(5, (int) ((panelX - 20 - gx + 16) / 182)));
        int rows = (list.size() + cols - 1) / cols;
        float viewH = Bm - 16 - gy;
        float maxScroll = Math.max(0, rows * 172 - viewH + 10);
        gridScroll = Math.max(0, Math.min(maxScroll, gridScroll));
        c.save();
        c.clipRect(gx - 10, gy - 6, gx + cols * 182, Bm - 6);
        for (int j = 0; j < list.size(); j++) {
            int t = list.get(j);
            float x = gx + (j % cols) * 182, y = gy + (j / cols) * 172 - gridScroll;
            if (y > Bm || y + 160 < gy - 10) continue;
            boolean own = pr.owned(t);
            boolean sel = t == armorySel;
            rf.set(x, y + 8, x + 166, y + 166);
            p.setColor(0x66000000);
            c.drawRoundRect(rf, 22, 22, p);
            rf.set(x - 4, y - 4, x + 170, y + 162);
            p.setColor(sel ? 0xFFFFD23F : Ui.INK);
            c.drawRoundRect(rf, 26, 26, p);
            rf.set(x, y, x + 166, y + 158);
            p.setShader(own ? new LinearGradient(0, y, 0, y + 158, 0xFF4E3D9A, 0xFF33266E, Shader.TileMode.CLAMP)
                    : new LinearGradient(0, y, 0, y + 158, 0xFF2A2050, 0xFF1E1640, Shader.TileMode.CLAMP));
            c.drawRoundRect(rf, 22, 22, p);
            p.setShader(null);
            Sprites.drawFit(c, Sprites.ammo(t), x + 83, y + 56, 120, 86, own ? 255 : 110);
            String nm = Defs.AMMO_NAME[t].toUpperCase(Locale.US);
            ui.textC(c, nm, x + 83, y + 112, nm.length() > 11 ? 17 : 20, 0xFFFFFFFF, 0);
            if (own) {
                String sub = t == ammo ? "EQUIPPED" : (Defs.AMMO_PRICE[t] > 0 ? "x" + pr.usesPerLevel(t) + " PER LEVEL" : "UNLIMITED");
                ui.textC(c, sub, x + 83, y + 138, 16, t == ammo ? 0xFFFFD23F : 0xFF7CFF8A, 0);
            } else {
                String pc = String.format(Locale.US, "%,d", Defs.AMMO_PRICE[t]);
                float pw = ui.width(pc, 20) + 26;
                ui.coin(c, x + 83 - pw / 2 + 9, y + 138, 9);
                ui.text(c, pc, x + 83 - pw / 2 + 24, y + 138, 20, pr.coins() >= Defs.AMMO_PRICE[t] ? 0xFFFFE066 : 0xFFFF8A7A, 0, Paint.Align.LEFT);
            }
            ui.hit(B_ITEM + t, x, Math.max(y, gy), x + 166, y + 158);
        }
        c.restore();
        int t = armorySel;
        float py = T + 150, ph = Math.min(540, Bm - 24 - py);
        rf.set(panelX - 6, py - 6, panelX + panelW + 6, py + ph + 6);
        p.setColor(Ui.INK);
        c.drawRoundRect(rf, 42, 42, p);
        rf.set(panelX, py, panelX + panelW, py + ph);
        p.setShader(new LinearGradient(0, py, 0, py + ph, 0xFF3A2A78, 0xFF231850, Shader.TileMode.CLAMP));
        c.drawRoundRect(rf, 36, 36, p);
        p.setShader(null);
        float cx = panelX + panelW / 2;
        ui.glow(c, cx, py + 110, 130, 0xAAC08CFF);
        c.save();
        c.rotate((float) Math.sin(time * 1.3f) * 6, cx, py + 110);
        Sprites.drawFit(c, Sprites.ammo(t), cx, py + 110 + (float) Math.sin(time * 2) * 6, 300, 175, 255);
        c.restore();
        ui.textC(c, Defs.AMMO_NAME[t].toUpperCase(Locale.US), cx, py + 228, 48, 0xFFFFFFFF, 7);
        boolean anySkin = false;
        for (int i = 0; i < Defs.ASKIN_TYPE.length; i++) if (Defs.ASKIN_TYPE[i] == t && pr.askinOwned(i)) anySkin = true;
        if (anySkin) {
            int sel = pr.askinSel(t);
            String lb = sel < 0 ? "SKIN: DEFAULT" : Defs.ASKIN_NAME[sel].toUpperCase(Locale.US);
            ui.button(c, B_ASKIN, cx, py + 40, lb, 20, sel < 0 ? Ui.BLUE : Ui.YELLOW, 200);
        }
        float ty = py + 274;
        for (String line : wrap(Defs.AMMO_DESC[t], 22, 520)) {
            ui.textC(c, line, cx, ty, 22, 0xCCFFFFFF, 0);
            ty += 28;
        }
        String[] sn = {"WEIGHT", "POWER", "CHAOS"};
        int[] sc2 = {0xFF5BC8FF, 0xFFFF7A3C, 0xFFB07CFF};
        float sy0 = py + ph - 190;
        for (int i = 0; i < 3; i++) {
            float y = sy0 + i * 32;
            ui.text(c, sn[i], panelX + 60, y, 22, 0xFFFFFFFF, 0, Paint.Align.LEFT);
            rf.set(panelX + 200, y - 9, panelX + 530, y + 9);
            p.setColor(0xCC120B2A);
            c.drawRoundRect(rf, 9, 9, p);
            rf.set(panelX + 200, y - 9, panelX + 200 + 330 * Defs.AMMO_STATS[t][i], y + 9);
            p.setColor(sc2[i]);
            c.drawRoundRect(rf, 9, 9, p);
        }
        float bcy = py + ph - 56;
        if (pr.owned(t)) {
            boolean premium = Defs.AMMO_PRICE[t] > 0;
            if (premium && pr.ammoUpg(t) < 3) {
                ui.button(c, B_BUY, cx - 140, bcy, t == ammo ? "EQUIPPED" : "EQUIP", 30, t == ammo ? Ui.GREY : Ui.GREEN, 230);
                int cost = pr.ammoUpgCost(t);
                ui.button(c, B_UPGRADE_AMMO, cx + 140, bcy, "+1 USE  " + String.format(Locale.US, "%,d", cost), 24,
                        pr.coins() >= cost ? Ui.YELLOW : Ui.GREY, 250);
            } else {
                ui.button(c, B_BUY, cx, bcy, t == ammo ? "EQUIPPED" : "EQUIP", 38, t == ammo ? Ui.GREY : Ui.GREEN, 300);
            }
        } else {
            boolean can = pr.coins() >= Defs.AMMO_PRICE[t];
            ui.button(c, B_BUY, cx, bcy, (can ? "BUY  " : "NEED  ") + String.format(Locale.US, "%,d", Defs.AMMO_PRICE[t]), 38,
                    can ? Ui.YELLOW : Ui.GREY, 300);
        }
    }

    private void drawUpgrades(Canvas c) {
        int[][] col = {Ui.RED, Ui.BLUE, Ui.GREEN};
        for (int i = 0; i < 3; i++) {
            float w = 440, h = 480, x = 800 - (3 * w + 60) / 2 + i * (w + 30), y = T + 140;
            rf.set(x - 6, y - 6, x + w + 6, y + h + 6);
            p.setColor(Ui.INK);
            c.drawRoundRect(rf, 36, 36, p);
            rf.set(x, y, x + w, y + h);
            p.setShader(new LinearGradient(0, y, 0, y + h, 0xFF4E3D9A, 0xFF2A1E5C, Shader.TileMode.CLAMP));
            c.drawRoundRect(rf, 30, 30, p);
            p.setShader(null);
            float icx = x + w / 2, icy = y + 110;
            ui.glow(c, icx, icy, 90, Defs.withAlpha(col[i][1], 140));
            if (i == 0) {
                c.save();
                c.translate(icx, icy + 10);
                c.scale(22, -22);
                art.drawSlingIcon(c, pr.skinFor(0));
                c.restore();
            } else if (i == 1) {
                for (int dd = 0; dd < 7; dd++) {
                    p.setColor(Defs.withAlpha(0xFFFFFFFF, 255 - dd * 30));
                    float t = dd / 6f;
                    c.drawCircle(icx - 110 + t * 220, icy + 40 - (float) Math.sin(t * Math.PI) * 90, 13 - dd, p);
                }
            } else {
                for (int dd = 0; dd < 3; dd++) {
                    p.setColor(Ui.INK);
                    c.drawCircle(icx - 60 + dd * 60, icy, 26, p);
                    p.setColor(dd == 2 ? 0xFF7CFF8A : 0xFFFF7A3C);
                    c.drawCircle(icx - 60 + dd * 60, icy, 20, p);
                }
                ui.textC(c, "+", icx + 60, icy - 2, 34, Ui.INK, 0);
            }
            ui.textC(c, Progress.UPG_NAME[i].toUpperCase(Locale.US), icx, y + 230, 34, 0xFFFFFFFF, 5);
            ui.textC(c, Progress.UPG_DESC[i].toUpperCase(Locale.US), icx, y + 274, 20, 0xCCFFFFFF, 0);
            int lv = pr.upg(i), mx = Progress.UPG_MAX[i];
            float pw = mx * 60, px0 = icx - pw / 2;
            for (int j = 0; j < mx; j++) {
                rf.set(px0 + j * 60 + 6, y + 312, px0 + j * 60 + 54, y + 336);
                p.setColor(Ui.INK);
                c.drawRoundRect(rf.left - 3, rf.top - 3, rf.right + 3, rf.bottom + 3, 14, 14, p);
                p.setColor(j < lv ? col[i][1] : 0xFF2B2150);
                c.drawRoundRect(rf, 11, 11, p);
            }
            ui.textC(c, "LEVEL " + lv + " / " + mx, icx, y + 362, 22, 0xFFFFFFFF, 0);
            int cost = pr.upgCost(i);
            if (cost < 0) ui.button(c, B_UPG + i, icx, y + 426, "MAXED", 34, Ui.GREY, 260);
            else ui.button(c, B_UPG + i, icx, y + 426, "UPGRADE  " + String.format(Locale.US, "%,d", cost), 28, pr.coins() >= cost ? Ui.YELLOW : Ui.GREY, 300);
        }
    }

    private void drawSkins(Canvas c) {
        int cols = 6;
        float cw = 212, ch = 236, gap = 16;
        float x0 = 800 - (cols * cw + (cols - 1) * gap) / 2, y0 = T + 118;
        for (int i = 0; i < Defs.NUM_SKINS; i++) {
            float x = x0 + (i % cols) * (cw + gap), y = y0 + (i / cols) * (ch + gap);
            boolean own = pr.skinOwned(i);
            boolean sel = pr.skinChoice() == i;
            rf.set(x - 5, y - 5, x + cw + 5, y + ch + 5);
            p.setColor(sel ? 0xFFFFD23F : Ui.INK);
            c.drawRoundRect(rf, 30, 30, p);
            rf.set(x, y, x + cw, y + ch);
            p.setShader(new LinearGradient(0, y, 0, y + ch, own ? 0xFF4E3D9A : 0xFF2A2050, own ? 0xFF2A1E5C : 0xFF1A1238, Shader.TileMode.CLAMP));
            c.drawRoundRect(rf, 26, 26, p);
            p.setShader(null);
            c.save();
            c.translate(x + cw / 2, y + 92);
            c.scale(21, -21);
            if (!own) {
                c.saveLayerAlpha(-3, -4, 3, 4, 70);
                art.drawSlingIcon(c, i);
                c.restore();
            } else art.drawSlingIcon(c, i);
            c.restore();
            if (!own) ui.glyph(c, Ui.G_LOCK, x + cw / 2, y + 92, 34);
            ui.textC(c, Defs.SKIN_NAME[i].toUpperCase(Locale.US), x + cw / 2, y + 186, 21, 0xFFFFFFFF, 0);
            ui.textC(c, own ? (sel ? "EQUIPPED" : "TAP TO EQUIP") : Defs.SKIN_HOW[i].toUpperCase(Locale.US), x + cw / 2, y + 216, 16,
                    own ? (sel ? 0xFFFFD23F : 0xFF7CFF8A) : 0x99FFFFFF, 0);
            ui.hit(B_SKIN + i, x, y, x + cw, y + ch);
        }
        boolean auto = pr.skinChoice() < 0;
        ui.button(c, B_SKIN_AUTO, 800, Bm - 46, auto ? "WORLD SKINS: ON" : "WORLD SKINS: OFF", 26, auto ? Ui.GREEN : Ui.GREY, 380);
    }

    private ArrayList<String> wrap(String s, float size, float maxW) {
        ArrayList<String> out = new ArrayList<>();
        String cu = "";
        for (String w : s.split(" ")) {
            String tryS = cu.isEmpty() ? w : cu + " " + w;
            if (ui.width(tryS, size) > maxW && !cu.isEmpty()) {
                out.add(cu);
                cu = w;
            } else cu = tryS;
        }
        if (!cu.isEmpty()) out.add(cu);
        return out;
    }

    // ================================================================ builder

    private Builder activeBuilder() {
        return mode == M_VERSUS ? vsBuilder : builder;
    }

    private void openBuilder(boolean versus) {
        if (versus) {
            mode = M_VERSUS;
            vsPhase = 0;
            vsScore[0] = vsScore[1] = 0;
            vsBuilder.items.clear();
            vsBuilder.max = 35;
        } else {
            mode = M_CAMPAIGN;
            builder.max = 80;
        }
        eraseMode = false;
        go(SC_BUILDER);
    }

    private void renderBuilderWorld(Canvas c) {
        camX = 31f;
        camZ = 1.15f;
        camY = 0;
        setupCamera();
        float horizon = H - (Art.DY - viewB) * s0;
        art.drawBackground(c, W, H, Defs.T_DAY, horizon, (camX - 19f) * s0, time);
        c.save();
        c.translate(-viewL * sc, H + viewB * sc);
        c.scale(sc, -sc);
        art.drawGround(c, viewL - 2, viewL + W / sc + 2, viewB - 1, Defs.T_DAY);
        p.setColor(0x22FFFFFF);
        c.drawRect(Builder.MIN_X, 0, Builder.MAX_X, Builder.MAX_Y, p);
        ui.ps.setColor(0x55FFFFFF);
        ui.ps.setStrokeWidth(0.04f);
        for (float x = Builder.MIN_X; x <= Builder.MAX_X + 0.01f; x += 1f) c.drawLine(x, 0, x, Builder.MAX_Y, ui.ps);
        for (float y = 0; y <= Builder.MAX_Y + 0.01f; y += 1f) c.drawLine(Builder.MIN_X, y, Builder.MAX_X, y, ui.ps);
        Builder b = activeBuilder();
        art.drawSpecReal(c, b.toLevel("", 0, 1).specs, 255);
        if (ghostOn && !eraseMode) {
            float[] g = b.ghost(palMat, palShape, ghostX);
            Defs.B gb = new Defs.B();
            if (Builder.SHAPES[palShape][2] > 0) gb.tri(g[0], g[1], g[2], g[3], palMat);
            else gb.box(g[0], g[1], g[2], g[3], palMat);
            c.saveLayerAlpha(Builder.MIN_X - 1, -1, Builder.MAX_X + 1, Builder.MAX_Y + 2, 150);
            art.drawSpecReal(c, gb.s, 255);
            c.restore();
            ui.ps.setColor(g[4] > 0 ? 0xFF7CFF8A : 0xFFFF4B2B);
            ui.ps.setStrokeWidth(0.08f);
            c.drawRect(g[0], g[1], g[0] + g[2], g[1] + g[3], ui.ps);
        }
        if (ghostOn && eraseMode) {
            p.setColor(0x66FF4B2B);
            c.drawCircle(ghostX, ghostY, 0.5f, p);
        }
        c.restore();
    }

    private void drawBuilderUi(Canvas c) {
        Builder b = activeBuilder();
        ui.iconButton(c, B_BACK, L + 32, T + 24, 84, Ui.G_BACK, Ui.ORANGE);
        String title = mode == M_VERSUS ? "PLAYER " + (vsPhase == 0 ? 1 : 2) + " - BUILD!" : "BUILDER";
        ui.title(c, title, 800, T + 54, 56, 0xFFFFF39A, 0xFFFFB31F, 0xFF7A3E00);
        ui.textC(c, b.items.size() + " / " + b.max + " BLOCKS  •  TAP TO DROP A BLOCK", 800, T + 104, 22, 0xFFFFFFFF, 4);
        if (mode == M_VERSUS) {
            boolean ok = b.items.size() >= 6;
            ui.button(c, B_DONE, R - 130, T + 64, "DONE", 36, ok ? Ui.GREEN : Ui.GREY, 200);
            if (!ok) ui.text(c, "AT LEAST 6 BLOCKS", R - 32, T + 132, 18, 0xCCFFFFFF, 3, Paint.Align.RIGHT);
            ui.textC(c, vsPhase == 0 ? "DON'T LET PLAYER 2 PEEK!" : "DON'T LET PLAYER 1 PEEK!", 800, T + 136, 20, 0xCCFFE066, 3);
        } else {
            ui.button(c, B_TEST, R - 330, T + 64, "TEST", 34, Ui.GREEN, 150);
            ui.button(c, B_VS, R - 130, T + 64, "2 PLAYERS", 28, Ui.PURPLE, 200);
        }
        float tx = L + 32, ty = T + 140;
        ui.iconButton(c, B_ERASE, tx, ty, 80, Ui.G_ERASE, eraseMode ? Ui.RED : Ui.BLUE);
        ui.iconButton(c, B_UNDO, tx, ty + 100, 80, Ui.G_UNDO, Ui.BLUE);
        ui.iconButton(c, B_CLEAR, tx, ty + 200, 80, Ui.G_TRASH, Ui.ORANGE);
        int nm = Builder.MATS.length, ns = Builder.SHAPES.length;
        float slot = 66, gap = 8, sep = 30;
        float total = (nm + ns) * (slot + gap) - gap + sep + 30;
        float px = 800 - total / 2, py = Bm - 14 - slot - 20;
        rf.set(px, py, px + total, py + slot + 20);
        p.setColor(0xB8120C26);
        c.drawRoundRect(rf, 44, 44, p);
        float x = px + 15;
        for (int i = 0; i < nm; i++) {
            int m = Builder.MATS[i];
            boolean sel = m == palMat && !eraseMode;
            rf.set(x, py + 10, x + slot, py + 10 + slot);
            p.setColor(sel ? 0xFFFFD23F : Ui.INK);
            c.drawRoundRect(rf.left - 3, rf.top - 3, rf.right + 3, rf.bottom + 3, 18, 18, p);
            p.setColor(0xFF3F3470);
            c.drawRoundRect(rf, 15, 15, p);
            c.save();
            c.translate(rf.centerX(), rf.centerY());
            c.scale(38, -38);
            art.drawBoxMat(c, m, 1f, 1f, 31 * (i + 1), 0, 0);
            c.restore();
            ui.hit(B_PAL_MAT + i, x, py, x + slot, py + slot + 20);
            x += slot + gap;
        }
        x += sep - gap;
        for (int i = 0; i < ns; i++) {
            boolean sel = i == palShape && !eraseMode;
            rf.set(x, py + 10, x + slot, py + 10 + slot);
            p.setColor(sel ? 0xFFFFD23F : Ui.INK);
            c.drawRoundRect(rf.left - 3, rf.top - 3, rf.right + 3, rf.bottom + 3, 18, 18, p);
            p.setColor(0xFF3F3470);
            c.drawRoundRect(rf, 15, 15, p);
            float sw = Builder.SHAPES[i][0], sh = Builder.SHAPES[i][1];
            float kk = 48f / Math.max(sw, sh * 1.2f);
            c.save();
            c.translate(rf.centerX(), rf.centerY());
            c.scale(kk, -kk);
            if (Builder.SHAPES[i][2] > 0) art.drawPolyMat(c, palMat, new float[]{-sw / 2, -sh / 2, sw / 2, -sh / 2, 0, sh / 2}, 5, 0, 0);
            else art.drawBoxMat(c, palMat, sw, sh, 17 * (i + 1), 0, 0);
            c.restore();
            ui.hit(B_PAL_SHAPE + i, x, py, x + slot, py + slot + 20);
            x += slot + gap;
        }
        ui.textC(c, eraseMode ? "ERASER - TAP A BLOCK TO REMOVE IT" : Defs.MAT_NAME[palMat].toUpperCase(Locale.US), 800, py - 26, 26,
                eraseMode ? 0xFFFF8A7A : 0xFFFFFFFF, 4);
    }

    private boolean inBuildArea(float px, float py) {
        float dx = (px - ox) / k, dy = (py - oy) / k;
        if (dy > Bm - 120 || dy < T + 150) return false;
        if (dx < L + 130) return false;
        setupCamera();
        float x = wx(px);
        return x > Builder.MIN_X - 1 && x < Builder.MAX_X + 1;
    }

    private void builderDone() {
        Builder b = activeBuilder();
        if (mode != M_VERSUS) return;
        if (b.items.size() < 6) {
            showToast("BUILD AT LEAST 6 BLOCKS!");
            return;
        }
        Defs.LevelDef d = b.toLevel("Player " + (vsPhase == 0 ? 1 : 2) + "'s Building", Defs.T_SUNSET, 4);
        vsPhase = vsPhase == 0 ? 1 : 3;
        pr.addStat("built", 1);
        startGame(d);
        vsInterstitial = true;
    }

    // ================================================================ input




    // ================================================================ secret codes

    private String codeText = "", codeMsg;
    private int codeMsgCol;
    private float codeMsgT;
    private int codeRewardSkin = -1, codeRewardAskin = -1;
    private static final String KEYS = "1234567890QWERTYUIOPASDFGHJKLZXCVBNM";

    private void applyAmmoSkins() {
        for (int t = 0; t < Defs.NUM_AMMO; t++) {
            int i = pr.askinSel(t);
            Sprites.setAmmoSkin(t, i >= 0 ? Defs.ASKIN_STYLE[i] : null);
        }
    }

    private void codeKey(int k) {
        if (k < KEYS.length()) {
            if (codeText.length() < 14) codeText += KEYS.charAt(k);
            return;
        }
        if (k == 50) {
            if (!codeText.isEmpty()) codeText = codeText.substring(0, codeText.length() - 1);
            return;
        }
        if (k == 51) redeem();
    }

    private void redeem() {
        String c = codeText.trim().toUpperCase(Locale.US);
        codeMsgT = 0;
        codeRewardSkin = codeRewardAskin = -1;
        int idx = -1;
        for (int i = 0; i < Defs.CODE.length; i++) if (Defs.CODE[i].equals(c)) idx = i;
        if (idx < 0) {
            codeMsg = "INVALID CODE";
            codeMsgCol = 0xFFFF7A6A;
            sfx.play(Defs.S_THUD, 0.6f, 0f);
            vibrate(60);
            return;
        }
        if (pr.codeUsed(c)) {
            codeMsg = "CODE ALREADY USED";
            codeMsgCol = 0xFFFFB13B;
            return;
        }
        pr.useCode(c);
        StringBuilder sb = new StringBuilder();
        if (Defs.CODE_COINS[idx] > 0) {
            pr.addCoins(Defs.CODE_COINS[idx]);
            sb.append("+").append(String.format(Locale.US, "%,d", Defs.CODE_COINS[idx])).append(" COINS");
        }
        int sk = Defs.CODE_SKIN[idx];
        if (sk >= 0) {
            pr.unlockSkin(sk);
            codeRewardSkin = sk;
            if (sb.length() > 0) sb.append("  •  ");
            sb.append(Defs.SKIN_NAME[sk].toUpperCase(Locale.US)).append(" SLINGSHOT");
        }
        for (int a : Defs.CODE_ASKINS[idx]) {
            pr.unlockAskin(a);
            if (codeRewardAskin < 0) codeRewardAskin = a;
            if (sb.length() > 0) sb.append("  •  ");
            sb.append(Defs.ASKIN_NAME[a].toUpperCase(Locale.US));
        }
        codeMsg = sb.toString();
        codeMsgCol = 0xFF7CFF8A;
        codeText = "";
        sfx.play(Defs.S_CHEST, 1f, 0f);
        sfx.play(Defs.S_COIN, 1f, 0f);
        vibrate(80);
    }

    private void drawCodes(Canvas c) {
        p.setShader(new LinearGradient(0, T, 0, Bm, 0xFF2A1A66, 0xFF120B2A, Shader.TileMode.CLAMP));
        c.drawRect(L, T, R, Bm, p);
        p.setShader(null);
        codeMsgT += dtLast;
        header(c, "SECRET CODES", "ENTER A CODE TO UNLOCK SECRET SKINS AND COINS");
        // input field
        rf.set(800 - 380, T + 150, 800 + 380, T + 236);
        p.setColor(Ui.INK);
        c.drawRoundRect(rf, 30, 30, p);
        rf.set(800 - 375, T + 155, 800 + 375, T + 231);
        p.setColor(0xFFF4EEFF);
        c.drawRoundRect(rf, 26, 26, p);
        boolean blink = ((int) (time * 2.5f)) % 2 == 0;
        String shown = codeText.isEmpty() ? "" : codeText;
        float tw = ui.width(shown, 50);
        if (codeText.isEmpty()) ui.textC(c, "TYPE YOUR CODE", 800, T + 193, 34, 0x66322060, 0);
        else ui.textC(c, shown, 800, T + 193, 50, Ui.INK, 0);
        if (blink) {
            p.setColor(0xFF8A4DFF);
            float cx = codeText.isEmpty() ? 800 - 150 : 800 + tw / 2 + 8;
            c.drawRect(cx, T + 170, cx + 5, T + 216, p);
        }
        // result
        if (codeMsg != null) {
            float pop = Math.min(1f, codeMsgT * 5f);
            c.save();
            c.scale(0.7f + 0.3f * pop, 0.7f + 0.3f * pop, 800, T + 270);
            ui.textC(c, codeMsg, 800, T + 270, codeMsg.length() > 40 ? 22 : 28, codeMsgCol, 4);
            c.restore();
            float ix = R - 170, iy = T + 220;
            if (codeRewardSkin >= 0 && codeMsgCol == 0xFF7CFF8A) {
                ui.glow(c, ix, iy, 120, 0x88FFE780);
                c.save();
                c.translate(ix, iy);
                c.scale(17, -17);
                art.drawSlingIcon(c, codeRewardSkin);
                c.restore();
            } else if (codeRewardAskin >= 0 && codeMsgCol == 0xFF7CFF8A) {
                ui.glow(c, ix, iy, 120, 0x88FFE780);
                Sprites.drawFit(c, "a" + Defs.ASKIN_TYPE[codeRewardAskin] + "_" + Defs.ASKIN_STYLE[codeRewardAskin], ix, iy, 170, 150, 255);
            }
        }
        // keyboard
        String[] rows = {"1234567890", "QWERTYUIOP", "ASDFGHJKL", "ZXCVBNM"};
        float kw = 104, kh = 76, gap = 12, ky = T + 318;
        int idx = 0;
        for (int r = 0; r < rows.length; r++) {
            String row = rows[r];
            float rowW = row.length() * kw + (row.length() - 1) * gap + (r == 3 ? 2 * (gap + kw * 1.6f) : 0);
            float x = 800 - rowW / 2;
            if (r == 3) {
                rf.set(x, ky, x + kw * 1.6f, ky + kh);
                ui.buttonRect(c, B_KEY + 50, rf, "DEL", 28, Ui.RED);
                x += kw * 1.6f + gap;
            }
            for (int i = 0; i < row.length(); i++) {
                rf.set(x, ky, x + kw, ky + kh);
                ui.buttonRect(c, B_KEY + KEYS.indexOf(row.charAt(i)), rf, String.valueOf(row.charAt(i)), 36, Ui.BLUE);
                x += kw + gap;
                idx++;
            }
            if (r == 3) {
                rf.set(x, ky, x + kw * 1.6f, ky + kh);
                ui.buttonRect(c, B_KEY + 51, rf, "OK", 30, Ui.GREEN);
            }
            ky += kh + gap + 6;
        }
        ui.textC(c, "EVERY CODE WORKS ONCE  •  TELL YOUR FRIENDS!", 800, Bm - 24, 18, 0x99FFFFFF, 0);
    }

    // ================================================================ hints & rewarded videos

    private boolean hintUnlocked() {
        return pr.p.getBoolean("hint" + level, false);
    }

    private int solAds() {
        return pr.p.getInt("solads" + level, 0);
    }

    private void watchAd(final Runnable reward) {
        if (ads != null && ads.ready()) {
            adShowing = true;
            aiming = false;
            ads.show(new Runnable() {
                @Override
                public void run() {
                    reward.run();
                }
            }, new Runnable() {
                @Override
                public void run() {
                    adShowing = false;
                    lastNs = 0;
                }
            });
        } else {
            // no video available (offline / no ad loaded): short wait instead
            adWaitMax = adWaitT = 8f;
            adReward = reward;
        }
    }

    private void hintButton(int id) {
        switch (id) {
            case B_HINT:
                if (state == ST_AIM && !planRun) {
                    hintOpen = true;
                    aiming = false;
                }
                break;
            case B_HINT_CLOSE: hintOpen = false; break;
            case B_HINT_A:
                if (hintUnlocked() || solAds() >= 2) applySolution(false);
                else watchAd(new Runnable() {
                    @Override
                    public void run() {
                        pr.p.edit().putBoolean("hint" + level, true).apply();
                        sfx.play(Defs.S_WIN, 0.7f, 0f);
                        applySolution(false);
                    }
                });
                break;
            case B_SOL_A:
                if (solAds() >= 2) applySolution(true);
                else watchAd(new Runnable() {
                    @Override
                    public void run() {
                        int n = solAds() + 1;
                        pr.p.edit().putInt("solads" + level, n).apply();
                        sfx.play(Defs.S_WIN, 0.7f, 0f);
                        if (n >= 2) applySolution(true);
                        else {
                            showToast("1 OF 2 WATCHED - WATCH 1 MORE FOR THE SOLUTION");
                            hintOpen = true;
                        }
                    }
                });
                break;
        }
    }

    /** Restarts the level and loads the verified solution (or just its first move) into the planner. */
    private void applySolution(boolean full) {
        float[] f = Solutions.get(level);
        if (f == null) return;
        hintOpen = false;
        startCampaign(level);
        ArrayList<Plan.Step> l = Plan.decode(f);
        if (!full) while (l.size() > 1) l.remove(l.size() - 1);
        plan.clear();
        plan.addAll(l);
        planSel = 0;
        planning = true;
        solutionPlan = true;
        holdWorld = true;
        game.dmgBoost = 1f;
        showToast(full ? "SOLUTION LOADED - PRESS GO!" : "HINT LOADED - PRESS GO OR CHANGE IT");
    }

    private void drawHintPanel(Canvas c) {
        ui.hits.clear();
        ui.scrim(c, L, T, R, Bm, 175);
        float top = 96;
        ui.panel(c, 800, top, 820, 540, "NEED HELP?", Ui.YELLOW);
        boolean hu = hintUnlocked() || solAds() >= 2;
        int sa = solAds();
        float[] ys = {top + 150, top + 300};
        String[] t = {"HINT", "FULL SOLUTION"};
        String[] d = {"SHOWS THE PERFECT FIRST MOVE", "THE WHOLE LEVEL - JUST PRESS GO"};
        for (int i = 0; i < 2; i++) {
            float y = ys[i];
            rf.set(430, y - 62, 1170, y + 62);
            p.setColor(0x8C120B2A);
            c.drawRoundRect(rf, 26, 26, p);
            p.setColor(Ui.INK);
            c.drawCircle(500, y, 44, p);
            p.setColor(i == 0 ? 0xFFFFC93C : 0xFF3BC44B);
            c.drawCircle(500, y, 38, p);
            ui.glyph(c, i == 0 ? Ui.G_BULB : Ui.G_CHECK, 500, y, 24);
            ui.text(c, t[i], 565, y - 16, 34, 0xFFFFFFFF, 4, Paint.Align.LEFT);
            ui.text(c, d[i], 565, y + 24, 20, 0xCCFFFFFF, 0, Paint.Align.LEFT);
            boolean open = i == 0 ? hu : sa >= 2;
            String lb = open ? (i == 0 ? "SHOW" : "PLAY IT") : "WATCH AD";
            ui.button(c, i == 0 ? B_HINT_A : B_SOL_A, 1040, y, lb, 28, open ? Ui.GREEN : Ui.PURPLE, 200);
            String sub = open ? "UNLOCKED - FREE" : (i == 0 ? "1 VIDEO" : (sa == 0 ? "2 VIDEOS NEEDED" : "WATCHED 1 OF 2 - 1 MORE"));
            ui.textC(c, sub, 1040, y + 48, 16, open ? 0xFF7CFF8A : (i == 1 && sa == 1 ? 0xFFFFE066 : 0xAAFFFFFF), 0);
        }
        ui.button(c, B_HINT_CLOSE, 800, top + 450, "CLOSE", 30, Ui.BLUE, 240);
    }

    private void drawAdWait(Canvas c) {
        ui.hits.clear();
        ui.scrim(c, L, T, R, Bm, 210);
        ui.panel(c, 800, 170, 640, 360, "UNLOCKING...", Ui.PURPLE);
        ui.textC(c, ads == null ? "NO VIDEO IN THIS BUILD" : "NO VIDEO AVAILABLE RIGHT NOW", 800, 300, 26, 0xFFFFFFFF, 3);
        ui.textC(c, "FREE UNLOCK IN " + (int) Math.ceil(Math.max(0, adWaitT)) + "s", 800, 350, 34, 0xFFFFE066, 4);
        ui.meter(c, 560, 410, 480, 1f - Math.max(0, adWaitT) / adWaitMax, new float[0]);
    }

    // ================================================================ combo planner

    private int planUses(int t, Plan.Step except) {
        int n = 0;
        for (Plan.Step st : plan) if (st != except && st.ammo == t) n++;
        return n;
    }

    private boolean ammoFree(int t, Plan.Step st) {
        if (mode == M_TEST || Defs.AMMO_PRICE[t] == 0) return true;
        return planUses(t, st) < uses[t];
    }

    private Plan.Step newStep(Plan.Step prev) {
        Plan.Step st = new Plan.Step();
        st.ammo = prev != null ? prev.ammo : ammo;
        st.px = prev != null ? prev.px : GameWorld.POUCH_X;
        st.py = prev != null ? prev.py : GameWorld.POUCH_Y;
        st.vx = prev != null ? prev.vx : lastVx;
        st.vy = prev != null ? prev.vy : lastVy;
        st.delayMs = prev != null ? 350 : 0;
        st.fuseMs = prev != null ? prev.fuseMs : 1200;
        if (!ammoFree(st.ammo, st)) {
            for (int t : barList()) if (ammoFree(t, st)) { st.ammo = t; break; }
        }
        return st;
    }

    private void enterPlanner() {
        if (state != ST_AIM || shotsLeft <= 0) return;
        while (plan.size() > Math.min(MAX_STEPS, shotsLeft)) plan.remove(plan.size() - 1);
        for (Plan.Step st : plan) {
            st.shot = null;
            st.fired = st.fused = false;
            if (!ammoFree(st.ammo, st)) for (int t : barList()) if (ammoFree(t, st)) { st.ammo = t; break; }
        }
        if (plan.isEmpty()) plan.add(newStep(null));
        plan.get(0).delayMs = 0;
        planSel = Math.min(planSel, plan.size() - 1);
        planning = true;
        aiming = false;
    }

    private void setStepAmmo(int t) {
        if (planSel >= plan.size()) return;
        Plan.Step st = plan.get(planSel);
        if (!ammoFree(t, st)) {
            showToast("NO MORE " + Defs.AMMO_NAME[t].toUpperCase(Locale.US) + " LEFT FOR THIS PLAN");
            return;
        }
        st.ammo = t;
        click();
    }

    private void storeAim() {
        float len = (float) Math.hypot(pullX, pullY);
        if (len < 0.35f || planSel >= plan.size()) return;
        Plan.Step st = plan.get(planSel);
        st.px = GameWorld.POUCH_X + pullX;
        st.py = GameWorld.POUCH_Y + pullY;
        st.vx = -pullX * MAX_SPEED / MAX_PULL;
        st.vy = -pullY * MAX_SPEED / MAX_PULL;
        sfx.play(Defs.S_CLICK, 0.5f, 0.1f);
    }

    private void planButton(int id) {
        if (id >= B_STEP_FP && id < B_STEP_FP + 10) { stepFuse(id - B_STEP_FP, 1); return; }
        if (id >= B_STEP_FM && id < B_STEP_FM + 10) { stepFuse(id - B_STEP_FM, -1); return; }
        if (id >= B_STEP_WP && id < B_STEP_WP + 10) { stepDelay(id - B_STEP_WP, 1); return; }
        if (id >= B_STEP_WM && id < B_STEP_WM + 10) { stepDelay(id - B_STEP_WM, -1); return; }
        if (id >= B_STEP && id < B_STEP + 10) { planSel = id - B_STEP; return; }
        switch (id) {
            case B_PLAN: enterPlanner(); break;
            case B_PLAN_CANCEL:
                planning = false;
                holdWorld = false;
                solutionPlan = false;
                break;
            case B_PLAN_ADD:
                if (plan.size() < Math.min(MAX_STEPS, shotsLeft)) {
                    plan.add(newStep(plan.get(plan.size() - 1)));
                    planSel = plan.size() - 1;
                } else showToast(shotsLeft <= plan.size() ? "NOT ENOUGH SHOTS FOR MORE STEPS" : "MAX " + MAX_STEPS + " STEPS");
                break;
            case B_PLAN_DEL:
                if (plan.size() > 1) {
                    plan.remove(planSel);
                    planSel = Math.max(0, Math.min(planSel, plan.size() - 1));
                    plan.get(0).delayMs = 0;
                }
                break;
            case B_PLAN_GO: startPlan(); break;
        }
    }

    private void stepDelay(int i, int dir) {
        if (i <= 0 || i >= plan.size()) return;
        Plan.Step st = plan.get(i);
        planSel = i;
        int step = (dir > 0 ? st.delayMs >= 500 : st.delayMs > 500) ? 100 : 50;
        st.delayMs = Math.max(0, Math.min(3000, st.delayMs + dir * step));
    }

    private void stepFuse(int i, int dir) {
        if (i < 0 || i >= plan.size()) return;
        Plan.Step st = plan.get(i);
        planSel = i;
        st.fuseMs = Math.max(100, Math.min(4000, st.fuseMs + dir * 100));
    }

    private float launchAt(int i) {
        return cplan.launchTick(i) * GameWorld.STEP;
    }

    private void startPlan() {
        if (plan.isEmpty() || (plan.size() > shotsLeft && !solutionPlan)) return;
        if (!solutionPlan) for (Plan.Step st : plan) {
            if (mode != M_TEST && Defs.AMMO_PRICE[st.ammo] > 0 && planUses(st.ammo, null) > uses[st.ammo]) {
                showToast("NOT ENOUGH " + Defs.AMMO_NAME[st.ammo].toUpperCase(Locale.US));
                return;
            }
        }
        solutionRun = solutionPlan && plan.size() > 1;
        planning = false;
        planRun = true;
        holdWorld = false;
        cplan.begin(game.stepNo);
        state = ST_FLY;
        stateTime = 0;
        sfx.play(Defs.S_STRETCH, 0.7f, 0f);
    }

    private final Plan.Listener planListener = new Plan.Listener() {
        @Override
        public void launched(Plan.Step st) {
            if (st.ammo == Defs.A_COW) game.launchedCows++;
            if (Defs.tappable(st.ammo)) game.launchedSpecial++;
            if (mode != M_TEST && Defs.AMMO_PRICE[st.ammo] > 0 && uses[st.ammo] > 0) uses[st.ammo]--;
            if (mode != M_TEST) shotsLeft = Math.max(0, shotsLeft - 1);
            shotsFired++;
            shotsThisWave++;
            vibrate(12);
        }

        @Override
        public void finished() {
            planRun = false;
            solutionPlan = false;
            state = ST_FLY;
            stateTime = 0;
            if (uses[ammo] <= 0) for (int tt : barList()) if (uses[tt] > 0) { ammo = tt; break; }
        }
    };

    /** Ballistic position of a planned step at time t after its launch (gravity + wind, no drag). */
    private float[] stepPos(Plan.Step st, float vx, float vy, float x0, float y0, float t) {
        float a = game.wind;
        return new float[]{x0 + vx * t + 0.5f * a * t * t, y0 + vy * t + 0.5f * GameWorld.GRAVITY * t * t};
    }

    private void drawPlanPreview(Canvas c) {
        int n = plan.size();
        float[] lx = new float[n], ly = new float[n], lvx = new float[n], lvy = new float[n], la = new float[n], fz = new float[n];
        for (int i = 0; i < n; i++) {
            Plan.Step st = plan.get(i);
            boolean live = aiming && i == planSel && Math.hypot(pullX, pullY) >= 0.35f;
            lx[i] = live ? GameWorld.POUCH_X + pullX : st.px;
            ly[i] = live ? GameWorld.POUCH_Y + pullY : st.py;
            lvx[i] = live ? -pullX * MAX_SPEED / MAX_PULL : st.vx;
            lvy[i] = live ? -pullY * MAX_SPEED / MAX_PULL : st.vy;
            la[i] = launchAt(i);
            fz[i] = Defs.tappable(st.ammo) ? st.fuseMs / 1000f : 99f;
        }
        // ghost markers of the other projectiles at each fuse moment
        for (int i = 0; i < n; i++) {
            Plan.Step st = plan.get(i);
            if (fz[i] > 50) continue;
            float tf = la[i] + fz[i];
            for (int j = 0; j < n; j++) {
                if (j == i || la[j] > tf || la[j] + fz[j] < tf) continue;
                float[] q = stepPos(plan.get(j), lvx[j], lvy[j], lx[j], ly[j], tf - la[j]);
                if (q[1] < 0) continue;
                ui.ps.setColor(Defs.withAlpha(STEP_COL[j % 4], 220));
                ui.ps.setStrokeWidth(5 * k);
                c.drawCircle(sx(q[0]), sy(q[1]), 20 * k, ui.ps);
                ui.textC(c, String.valueOf(j + 1), sx(q[0]), sy(q[1]), 22 * k, 0xFFFFFFFF, 3 * k);
            }
        }
        for (int i = 0; i < n; i++) {
            Plan.Step st = plan.get(i);
            int col = STEP_COL[i % 4];
            boolean sel = i == planSel;
            float tEnd = Math.min(3.2f, fz[i]);
            float[] q = null;
            int dots = 0;
            for (float t = 0.07f; t <= tEnd + 1e-4f; t += 0.07f) {
                q = stepPos(st, lvx[i], lvy[i], lx[i], ly[i], t);
                if (q[1] < 0 || q[0] > viewL + W / sc + 4) break;
                float a = sel ? 1f : 0.55f;
                p.setColor(Ui.INK);
                c.drawCircle(sx(q[0]), sy(q[1]), (sel ? 10f : 7.5f) * k, p);
                p.setColor(Defs.withAlpha(col, (int) (255 * a)));
                c.drawCircle(sx(q[0]), sy(q[1]), (sel ? 7f : 5f) * k, p);
                dots++;
            }
            if (fz[i] < 50 && fz[i] <= 3.2f) {
                float[] e = stepPos(st, lvx[i], lvy[i], lx[i], ly[i], fz[i]);
                if (e[1] >= -0.5f) {
                    float ex = sx(e[0]), ey = sy(Math.max(0, e[1]));
                    float rr = (st.ammo == Defs.A_TNT ? 6.0f : 2.2f) * sc;
                    float pulse = 1f + 0.05f * (float) Math.sin(time * 6 + i);
                    p.setColor(Defs.withAlpha(col, sel ? 46 : 26));
                    c.drawCircle(ex, ey, rr * pulse, p);
                    ui.ps.setColor(Defs.withAlpha(col, sel ? 230 : 140));
                    ui.ps.setStrokeWidth(4 * k);
                    c.drawCircle(ex, ey, rr * pulse, ui.ps);
                    c.drawCircle(ex, ey, rr * 0.3f, ui.ps);
                    ui.textC(c, "BOOM " + (i + 1), ex, ey - rr * 0.3f - 22 * k, 24 * k, 0xFFFFFFFF, 4 * k);
                }
            }
            // step number at launch point
            float bx = sx(lx[i]) - 46 * k, by = sy(ly[i] + 0.6f) - i * 36 * k;
            p.setColor(Ui.INK);
            c.drawCircle(bx, by, 17 * k, p);
            p.setColor(col);
            c.drawCircle(bx, by, 13 * k, p);
            ui.textC(c, String.valueOf(i + 1), bx, by, 20 * k, Ui.INK, 0);
        }
    }

    private void drawPlanner(Canvas c) {
        int n = plan.size();
        boolean compact = n > 4;
        float cw = compact ? 158 : 236, gap = 14, chh = 128;
        boolean canAdd = n < Math.min(MAX_STEPS, shotsLeft) && !compact;
        float total = n * cw + (n - 1) * gap + (canAdd ? gap + 96 : 0);
        float x0 = (compact ? 740 : 800) - total / 2, y0 = T + 100;
        // header strip
        rf.set(800 - 360, T + 250, 800 + 360, T + 296);
        p.setColor(0xD9241650);
        c.drawRoundRect(rf, 23, 23, p);
        if (solutionPlan) ui.textC(c, (n > 1 ? "SOLUTION READY" : "HINT: YOUR FIRST MOVE") + "  •  PRESS GO!", 800, T + 273, 24, 0xFFFFE066, 3);
        else ui.textC(c, "COMBO PLANNER  •  DRAG TO AIM STEP " + (planSel + 1) + "  •  SET WAIT & FUSE", 800, T + 273, 22, 0xFFFFFFFF, 3);
        for (int i = 0; i < n; i++) {
            Plan.Step st = plan.get(i);
            float x = x0 + i * (cw + gap);
            boolean sel = i == planSel;
            int col = STEP_COL[i % 4];
            rf.set(x - 4, y0 - 4, x + cw + 4, y0 + chh + 4);
            p.setColor(sel ? col : Ui.INK);
            c.drawRoundRect(rf, 24, 24, p);
            rf.set(x, y0, x + cw, y0 + chh);
            p.setColor(sel ? 0xF2302064 : 0xE6120B2A);
            c.drawRoundRect(rf, 20, 20, p);
            ui.hit(B_STEP + i, x, y0, x + 96, y0 + chh);
            p.setColor(Ui.INK);
            c.drawCircle(x + 22, y0 + 22, 16, p);
            p.setColor(col);
            c.drawCircle(x + 22, y0 + 22, 12, p);
            ui.textC(c, String.valueOf(i + 1), x + 22, y0 + 22, 20, Ui.INK, 0);
            if (compact) {
                Sprites.drawFit(c, Sprites.ammo(st.ammo), x + 46, y0 + 74, 60, 60, 255);
                ui.text(c, i == 0 ? "START" : String.format(Locale.US, "+%.2fs", st.delayMs / 1000f), x + 86, y0 + 44, 20, 0xFFFFFFFF, 3, Paint.Align.LEFT);
                if (Defs.tappable(st.ammo)) ui.text(c, String.format(Locale.US, "%.1fs", st.fuseMs / 1000f), x + 86, y0 + 92, 20, 0xFFFFB13B, 3, Paint.Align.LEFT);
                continue;
            }
            if (!Sprites.drawFit(c, Sprites.ammo(st.ammo), x + 52, y0 + 76, 72, 72, 255)) {
                c.save();
                c.translate(x + 52, y0 + 76);
                c.scale(40, -40);
                art.drawAmmo(c, st.ammo);
                c.restore();
            }
            String nm = Defs.AMMO_NAME[st.ammo].toUpperCase(Locale.US);
            ui.textC(c, nm, x + 52, y0 + chh - 12, nm.length() > 8 ? 13 : 16, 0xFFFFE066, 2);
            // WAIT row
            float rx = x + 100, ry = y0 + 44;
            ui.text(c, i == 0 ? "LAUNCH" : "WAIT AFTER " + i, rx, y0 + 14, 14, 0xAAFFFFFF, 0, Paint.Align.LEFT);
            if (i == 0) ui.textC(c, "AT 0.00s", rx + 64, ry + 4, 22, 0xFFFFFFFF, 3);
            else {
                miniBtn(c, B_STEP_WM + i, rx, ry, "-");
                ui.textC(c, String.format(Locale.US, "%.2fs", st.delayMs / 1000f), rx + 64, ry + 2, 21, 0xFFFFFFFF, 3);
                miniBtn(c, B_STEP_WP + i, rx + 98, ry, "+");
            }
            float fy = y0 + 98;
            if (Defs.tappable(st.ammo)) {
                ui.text(c, st.ammo == Defs.A_TNT ? "FUSE (BOOM)" : "TRIGGER AT", rx, y0 + 74, 14, 0xAAFFFFFF, 0, Paint.Align.LEFT);
                miniBtn(c, B_STEP_FM + i, rx, fy, "-");
                ui.textC(c, String.format(Locale.US, "%.1fs", st.fuseMs / 1000f), rx + 64, fy + 2, 21, 0xFFFFB13B, 3);
                miniBtn(c, B_STEP_FP + i, rx + 98, fy, "+");
            } else {
                ui.text(c, "NO FUSE", rx, y0 + 74, 14, 0x66FFFFFF, 0, Paint.Align.LEFT);
                ui.textC(c, "IMPACT", rx + 64, fy + 2, 20, 0x99FFFFFF, 2);
            }
        }
        if (canAdd) {
            float x = x0 + n * (cw + gap);
            rf.set(x, y0 + 14, x + 96, y0 + chh - 14);
            ui.buttonRect(c, B_PLAN_ADD, rf, "+", 50, Ui.PURPLE);
            ui.textC(c, "ADD STEP", x + 48, y0 + chh + 8, 16, 0xFFFFFFFF, 3);
        }
        float pulse = 1f + 0.04f * (float) Math.sin(time * 5);
        c.save();
        c.scale(pulse, pulse, R - 130, Bm - 70);
        ui.button(c, B_PLAN_GO, R - 130, Bm - 70, "GO!", 40, Ui.GREEN, 200);
        c.restore();
        ui.button(c, B_PLAN_CANCEL, R - 130, Bm - 178, "CANCEL", 26, Ui.GREY, 200);
        if (n > 1) ui.button(c, B_PLAN_DEL, L + 130, Bm - 70, "DELETE " + (planSel + 1), 26, Ui.RED, 200);
    }

    private void miniBtn(Canvas c, int id, float x, float cy, String s) {
        rf.set(x, cy - 15, x + 30, cy + 15);
        ui.buttonRect(c, id, rf, s, 24, Ui.BLUE);
    }

    @Override
    public boolean onTouchEvent(MotionEvent e) {
        int action = e.getActionMasked();
        int idx = e.getActionIndex();
        float x = e.getX(idx), y = e.getY(idx);
        float dx = (x - ox) / k, dy = (y - oy) / k;
        if (replay != null) {
            if (action == MotionEvent.ACTION_DOWN) endReplay();
            return true;
        }
        switch (action) {
            case MotionEvent.ACTION_DOWN:
            case MotionEvent.ACTION_POINTER_DOWN: {
                if (action == MotionEvent.ACTION_POINTER_DOWN && (aiming || barDrag || gridDrag || ghostOn)) return true;
                int id = ui.find(dx, dy);
                if (id == -2 && screen == SC_GAME) {
                    barDrag = true;
                    barMoved = false;
                    dragX0 = dx;
                    scroll0 = barScroll;
                    return true;
                }
                if (screen == SC_ARMORY && armoryPage == 0 && id >= B_ITEM && id < B_ITEM + 50) {
                    gridDrag = true;
                    gridMoved = false;
                    dragY0 = dy;
                    scroll0 = gridScroll;
                    pendingItem = id;
                    return true;
                }
                if (id > 0) {
                    onButton(id);
                    return true;
                }
                if (screen == SC_BUILDER && inBuildArea(x, y)) {
                    ghostOn = true;
                    ghostX = wx(x);
                    ghostY = wy(y);
                    return true;
                }
                if (screen == SC_ARMORY && armoryPage == 0 && dx < R - 680 && dy > T + 180) {
                    gridDrag = true;
                    gridMoved = false;
                    dragY0 = dy;
                    scroll0 = gridScroll;
                    pendingItem = -1;
                    return true;
                }
                if (screen == SC_GAME && !paused && !showResult && !vsInterstitial && chest == null && !hintOpen && adWaitT < 0 && !adShowing) {
                    if (planRun) return true;
                    if (game.canTrigger() && !planning) {
                        if (game.trigger()) vibrate(30);
                        return true;
                    }
                    if (state == ST_AIM && !aiming) {
                        aiming = true;
                        aimId = e.getPointerId(idx);
                        tx0 = x;
                        ty0 = y;
                        pullX = pullY = 0;
                        sfx.play(Defs.S_STRETCH, 0.6f, 0.05f);
                    }
                }
                return true;
            }
            case MotionEvent.ACTION_MOVE: {
                if (aiming) {
                    int pi = e.findPointerIndex(aimId);
                    if (pi >= 0) updatePull(e.getX(pi), e.getY(pi));
                } else if (barDrag) {
                    float ddx = (e.getX(0) - ox) / k - dragX0;
                    if (Math.abs(ddx) > 14) barMoved = true;
                    if (barMoved) barScroll = scroll0 - ddx;
                } else if (gridDrag) {
                    float ddy = (e.getY(0) - oy) / k - dragY0;
                    if (Math.abs(ddy) > 14) gridMoved = true;
                    if (gridMoved) gridScroll = scroll0 - ddy;
                } else if (ghostOn) {
                    ghostX = wx(e.getX(0));
                    ghostY = wy(e.getY(0));
                }
                return true;
            }
            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_POINTER_UP:
            case MotionEvent.ACTION_CANCEL: {
                if (aiming && e.getPointerId(idx) == aimId) {
                    updatePull(x, y);
                    if (action != MotionEvent.ACTION_CANCEL) {
                        if (planning) storeAim();
                        else fire();
                    }
                    aiming = false;
                    aimId = -1;
                } else if (barDrag) {
                    barDrag = false;
                    if (!barMoved && action != MotionEvent.ACTION_CANCEL) {
                        ArrayList<Integer> bl = barList();
                        float rel = dx - barX0 - 18 + barScroll;
                        int slot = (int) Math.floor(rel / (SLOT + SLOT_GAP));
                        if (slot >= 0 && slot < bl.size()) {
                            int t = bl.get(slot);
                            if (planning) setStepAmmo(t);
                            else if (uses[t] <= 0) showToast("NO " + Defs.AMMO_NAME[t].toUpperCase(Locale.US) + " LEFT THIS LEVEL");
                            else {
                                ammo = t;
                                pr.p.edit().putInt("ammo", ammo).apply();
                                click();
                            }
                        }
                    }
                } else if (gridDrag) {
                    gridDrag = false;
                    if (!gridMoved && pendingItem >= B_ITEM && action != MotionEvent.ACTION_CANCEL) onButton(pendingItem);
                } else if (ghostOn) {
                    ghostOn = false;
                    if (action != MotionEvent.ACTION_CANCEL) {
                        Builder b = activeBuilder();
                        if (eraseMode) {
                            if (b.erase(wx(x), wy(y))) sfx.play(Defs.S_WOOD, 0.5f, 0.2f);
                        } else if (b.place(palMat, palShape, wx(x))) {
                            sfx.play(Defs.S_THUD, 0.6f, 0.2f);
                            vibrate(10);
                        } else {
                            showToast(b.items.size() >= b.max ? "BLOCK LIMIT REACHED" : "CAN'T PLACE THERE");
                        }
                        if (mode != M_VERSUS) pr.setSave(0, builder.encode());
                    }
                }
                return true;
            }
        }
        return true;
    }

    private void updatePull(float x, float y) {
        float dx = (x - tx0) / sc * 0.85f, dy = -(y - ty0) / sc * 0.85f;
        float len = (float) Math.hypot(dx, dy);
        if (len > MAX_PULL) {
            dx *= MAX_PULL / len;
            dy *= MAX_PULL / len;
        }
        if (GameWorld.POUCH_Y + dy < 1.0f) dy = 1.0f - GameWorld.POUCH_Y;
        pullX = dx;
        pullY = dy;
    }

    private void fire() {
        float len = (float) Math.hypot(pullX, pullY);
        if (len < 0.35f || state != ST_AIM) return;
        if (uses[ammo] <= 0) {
            showToast("NO " + Defs.AMMO_NAME[ammo].toUpperCase(Locale.US) + " LEFT - PICK ANOTHER");
            return;
        }
        float vx = -pullX * MAX_SPEED / MAX_PULL, vy = -pullY * MAX_SPEED / MAX_PULL;
        game.launch(ammo, pouchX(), pouchY(), vx, vy);
        lastVx = vx;
        lastVy = vy;
        if (ammo == Defs.A_COW) game.launchedCows++;
        if (Defs.tappable(ammo)) game.launchedSpecial++;
        if (mode != M_TEST && Defs.AMMO_PRICE[ammo] > 0) uses[ammo]--;
        if (mode != M_TEST) shotsLeft--;
        shotsFired++;
        shotsThisWave++;
        state = ST_FLY;
        stateTime = 0;
        vibrate(15);
        if (uses[ammo] <= 0) {
            for (int t : barList()) if (uses[t] > 0) { ammo = t; break; }
        }
    }

    private void onButton(int id) {
        ui.pressedId = id;
        ui.pressedT = 0.12f;
        click();
        if (id >= B_STEP && id < B_STEP + 50) { planButton(id); return; }
        if (id >= B_PLAN && id <= B_PLAN_DEL) { planButton(id); return; }
        if (id >= B_HINT && id <= B_HINT_CLOSE) { hintButton(id); return; }
        if (id >= B_PAL_SHAPE && id < B_PAL_SHAPE + 20) { palShape = id - B_PAL_SHAPE; eraseMode = false; return; }
        if (id >= B_PAL_MAT && id < B_PAL_MAT + 40) { palMat = Builder.MATS[id - B_PAL_MAT]; eraseMode = false; return; }
        if (id >= B_CLAIM && id < B_CLAIM + 3) { openChest(pr.claimMission(id - B_CLAIM)); return; }
        if (id >= B_SKIN && id < B_SKIN + 20) {
            int s = id - B_SKIN;
            if (pr.skinOwned(s)) pr.setSkinChoice(s);
            else showToast(Defs.SKIN_HOW[s].toUpperCase(Locale.US) + " TO UNLOCK");
            return;
        }
        if (id >= B_UPG && id < B_UPG + 3) {
            int u = id - B_UPG, cost = pr.upgCost(u);
            if (cost < 0) return;
            if (pr.spend(cost)) {
                pr.incUpg(u);
                sfx.play(Defs.S_COIN, 1f, 0f);
                sfx.play(Defs.S_WIN, 0.6f, 0f);
                showToast(Progress.UPG_NAME[u].toUpperCase(Locale.US) + " UPGRADED!");
            } else showToast("NOT ENOUGH COINS - SMASH MORE BUILDINGS!");
            return;
        }
        if (id >= B_ITEM && id < B_ITEM + 50) { armorySel = id - B_ITEM; return; }
        if (id >= B_TAB + 10 && id < B_TAB + 13) { armoryPage = id - B_TAB - 10; gridScroll = 0; return; }
        if (id >= B_TAB && id < B_TAB + 10) { armoryTab = id - B_TAB; gridScroll = 0; return; }
        if (id >= B_LEVEL && id < B_LEVEL + 50) {
            int lvl = world * Defs.LEVELS_PER_WORLD + id - B_LEVEL;
            if (pr.levelUnlocked(lvl)) startCampaign(lvl);
            else showToast("BEAT THE PREVIOUS LEVEL FIRST");
            return;
        }
        if (id >= B_WORLD && id < B_WORLD + 10) {
            int w = id - B_WORLD;
            if (pr.worldUnlocked(w)) {
                world = w;
                go(SC_LEVELS);
            } else showToast("COLLECT " + (Defs.WORLD_REQ[w] - pr.totalStars()) + " MORE STARS TO OPEN");
            return;
        }
        if (id >= B_KEY && id < B_KEY + 60) { codeKey(id - B_KEY); return; }
        switch (id) {
            case B_CODES: codeText = ""; codeMsg = null; go(SC_CODES); break;
            case B_ASKIN: {
                int t = armorySel, cur0 = pr.askinSel(t), next = -1;
                for (int k = 1; k <= Defs.ASKIN_TYPE.length + 1; k++) {
                    int i = cur0 + k;
                    if (i >= Defs.ASKIN_TYPE.length) { next = -1; break; }
                    if (Defs.ASKIN_TYPE[i] == t && pr.askinOwned(i)) { next = i; break; }
                }
                pr.setAskinSel(t, next);
                applyAmmoSkins();
                break;
            }
            case B_PLAY: go(SC_WORLDS); break;
            case B_ENDLESS: startEndless(); break;
            case B_DAILY: startDaily(); break;
            case B_BUILD: openBuilder(false); break;
            case B_MISSIONS: go(SC_MISSIONS); break;
            case B_ARMORY:
                armoryReturn = screen;
                go(SC_ARMORY);
                break;
            case B_SOUND:
                sfx.muted = !sfx.muted;
                pr.setBool("muted", sfx.muted);
                break;
            case B_VIBE:
                vibeOn = !vibeOn;
                pr.setBool("vibe", vibeOn);
                if (vibeOn) vibrate(40);
                break;
            case B_BACK: onBack(); break;
            case B_PAUSE:
                paused = true;
                aiming = false;
                break;
            case B_RESUME: paused = false; break;
            case B_RESTART:
            case B_RETRY:
                commitStats();
                if (mode == M_ENDLESS) startEndless();
                else if (mode == M_VERSUS) openBuilder(true);
                else if (mode == M_CAMPAIGN) startCampaign(level);
                else startGame(cur);
                break;
            case B_LEVELS: leaveGame(); break;
            case B_NEXT:
                if (mode == M_CAMPAIGN && level + 1 < Defs.LEVELS.length && pr.levelUnlocked(level + 1)) startCampaign(level + 1);
                else if (mode == M_CAMPAIGN) showToast("GET AT LEAST 1 STAR TO CONTINUE");
                break;
            case B_FINISH: finishLevel(false); break;
            case B_REPLAY: if (game.bestClip != null) startReplay(game.bestClip); break;
            case B_CHEST_OK: chest = null; break;
            case B_TEST: startTest(); break;
            case B_TO_BUILDER: commitStats(); go(SC_BUILDER); break;
            case B_VS: openBuilder(true); break;
            case B_ERASE: eraseMode = !eraseMode; break;
            case B_UNDO:
                activeBuilder().undo();
                if (mode != M_VERSUS) pr.setSave(0, builder.encode());
                break;
            case B_CLEAR:
                activeBuilder().items.clear();
                if (mode != M_VERSUS) pr.setSave(0, builder.encode());
                break;
            case B_DONE:
                if (screen == SC_BUILDER) builderDone();
                else if (mode == M_VERSUS && showResult && vsPhase == 1) {
                    vsPhase = 2;
                    vsBuilder.items.clear();
                    go(SC_BUILDER);
                }
                break;
            case B_READY: vsInterstitial = false; break;
            case B_SKIN_AUTO: pr.setSkinChoice(pr.skinChoice() < 0 ? pr.skinFor(0) : -1); break;
            case B_UPGRADE_AMMO: {
                int t = armorySel, cost = pr.ammoUpgCost(t);
                if (pr.spend(cost)) {
                    pr.incAmmoUpg(t);
                    sfx.play(Defs.S_COIN, 1f, 0f);
                    showToast(Defs.AMMO_NAME[t].toUpperCase(Locale.US) + ": " + pr.usesPerLevel(t) + " USES PER LEVEL");
                } else showToast("NOT ENOUGH COINS!");
                break;
            }
            case B_BUY: {
                int t = armorySel;
                if (pr.owned(t)) {
                    ammo = t;
                    pr.p.edit().putInt("ammo", ammo).apply();
                } else if (pr.spend(Defs.AMMO_PRICE[t])) {
                    pr.unlockAmmo(t);
                    loadOwned();
                    ammo = t;
                    pr.p.edit().putInt("ammo", ammo).apply();
                    sfx.play(Defs.S_COIN, 1f, 0f);
                    sfx.play(Defs.S_WIN, 0.7f, 0f);
                    vibrate(40);
                    showToast(Defs.AMMO_NAME[t].toUpperCase(Locale.US) + " UNLOCKED!");
                } else showToast("NOT ENOUGH COINS - SMASH MORE BUILDINGS!");
                break;
            }
        }
    }
}
