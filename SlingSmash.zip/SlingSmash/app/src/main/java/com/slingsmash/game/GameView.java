package com.slingsmash.game;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.Shader;
import android.os.Build;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.view.MotionEvent;
import android.view.View;

import org.jbox2d.common.Vec2;

import java.util.ArrayList;

public final class GameView extends View implements GameWorld.Fx {

    private static final int SC_MENU = 0, SC_LEVELS = 1, SC_GAME = 2;
    private static final int ST_AIM = 0, ST_FLY = 1, ST_WAIT = 2;
    private static final float MAX_PULL = 3.4f, MAX_SPEED = 27f;

    private static final int B_PLAY = 1, B_SOUND = 2, B_BACK = 3, B_PAUSE = 4, B_RESTART = 5, B_RESUME = 6,
            B_LEVELS = 7, B_NEXT = 8, B_RETRY = 9, B_LEVEL = 100, B_AMMO = 200;

    private final Art art = new Art();
    private final Sfx sfx;
    private final Vibrator vibrator;
    private final SharedPreferences prefs;
    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint ps = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint tp = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint bmp = new Paint(Paint.FILTER_BITMAP_FLAG);
    private final RectF rf = new RectF();
    private final RectF rf2 = new RectF();
    private final Rect dst = new Rect();
    private final Path path = new Path();

    // worlds
    private final GameWorld game;
    private final GameWorld demo;
    private int screen = SC_MENU;
    private int level, ammo, state, shotsLeft, shotsFired;
    private float stateTime, settleTime, completeTime;
    private boolean paused, showResult;
    private float resultT;
    private int resultStars, resultScore, starsPlayed;
    private float resultDestr;
    private boolean newBest;

    // demo
    private int demoLevel;
    private float demoTimer;
    private int demoShots;

    // view
    private int W, H;
    private float sc, viewL, viewB, u, inset;
    private final Bitmap[] bgs = new Bitmap[5];
    private Bitmap[] previews;
    private float time, fade;
    private long lastNs;
    private boolean running = true;

    // aiming
    private boolean aiming;
    private int aimId = -1;
    private float tx0, ty0, pullX, pullY;

    // buttons (rebuilt every frame)
    private final ArrayList<float[]> btns = new ArrayList<>();
    private int pressedId = -1;
    private float pressedT;

    public GameView(Context ctx) {
        super(ctx);
        sfx = new Sfx(ctx);
        vibrator = (Vibrator) ctx.getSystemService(Context.VIBRATOR_SERVICE);
        prefs = ctx.getSharedPreferences("slingsmash", Context.MODE_PRIVATE);
        sfx.muted = prefs.getBoolean("muted", false);
        tp.setTypeface(art.bold);
        tp.setTextAlign(Paint.Align.CENTER);
        ps.setStyle(Paint.Style.STROKE);
        ps.setStrokeJoin(Paint.Join.ROUND);
        ps.setStrokeCap(Paint.Cap.ROUND);
        game = new GameWorld(this);
        demo = new GameWorld(new GameWorld.Fx() {
            @Override public void sound(int id, float vol, float pv) {}
            @Override public void vibrate(int ms) {}
        });
        demoLevel = (int) (Math.random() * Defs.LEVELS.length);
        demo.load(Defs.LEVELS[demoLevel]);
        setFocusable(true);
    }

    // ================================================================ lifecycle

    void onPauseGame() {
        running = false;
        if (screen == SC_GAME && !showResult) paused = true;
    }

    void onResumeGame() {
        running = true;
        lastNs = 0;
        postInvalidateOnAnimation();
    }

    void release() {
        sfx.release();
    }

    boolean onBack() {
        click();
        if (screen == SC_GAME) {
            if (showResult) go(SC_LEVELS);
            else paused = !paused;
            return true;
        }
        if (screen == SC_LEVELS) {
            go(SC_MENU);
            return true;
        }
        return false;
    }

    @Override
    protected void onSizeChanged(int w, int h, int ow, int oh) {
        W = w;
        H = h;
        u = H / 100f;
        inset = Math.max(2 * u, W * 0.025f);
        sc = Math.min(W / 54f, H / 24.5f);
        float viewW = W / sc;
        viewL = 19f - viewW / 2f;
        viewB = -2.6f;
        for (int i = 0; i < bgs.length; i++) {
            if (bgs[i] != null) bgs[i].recycle();
            bgs[i] = null;
        }
        previews = null;
    }

    // ================================================================ Fx

    @Override
    public void sound(int id, float vol, float pitchVar) {
        sfx.play(id, vol, pitchVar);
    }

    @Override
    public void vibrate(int ms) {
        if (vibrator == null || sfx.muted) return;
        try {
            if (Build.VERSION.SDK_INT >= 26) vibrator.vibrate(VibrationEffect.createOneShot(ms, VibrationEffect.DEFAULT_AMPLITUDE));
            else vibrator.vibrate(ms);
        } catch (Exception ignored) {
        }
    }

    private void click() {
        sfx.play(Defs.S_CLICK, 0.6f, 0.05f);
    }

    // ================================================================ flow

    private void go(int sc) {
        screen = sc;
        fade = 1f;
        paused = false;
        showResult = false;
        aiming = false;
    }

    private void startLevel(int idx) {
        level = idx;
        game.load(Defs.LEVELS[idx]);
        shotsLeft = Defs.LEVELS[idx].shots;
        shotsFired = 0;
        state = ST_AIM;
        stateTime = 0;
        settleTime = 0;
        completeTime = 0;
        go(SC_GAME);
    }

    private void finishLevel() {
        if (showResult) return;
        float d = game.destruction();
        resultDestr = d;
        resultStars = d >= 0.85f ? 3 : (d >= 0.65f ? 2 : (d >= 0.4f ? 1 : 0));
        resultScore = game.score + (int) (d * 5000) + (resultStars > 0 ? shotsLeft * 1500 : 0);
        int best = prefs.getInt("best" + level, 0);
        int stars = prefs.getInt("stars" + level, 0);
        newBest = resultScore > best;
        SharedPreferences.Editor e = prefs.edit();
        if (newBest) e.putInt("best" + level, resultScore);
        if (resultStars > stars) e.putInt("stars" + level, resultStars);
        e.apply();
        showResult = true;
        resultT = 0;
        starsPlayed = 0;
        aiming = false;
        sfx.play(resultStars > 0 ? Defs.S_WIN : Defs.S_THUD, 0.8f, 0f);
    }

    private int totalStars() {
        int s = 0;
        for (int i = 0; i < Defs.LEVELS.length; i++) s += prefs.getInt("stars" + i, 0);
        return s;
    }

    // ================================================================ loop

    @Override
    protected void onDraw(Canvas c) {
        long now = System.nanoTime();
        float dt = lastNs == 0 ? 1 / 60f : Math.min(0.05f, (now - lastNs) / 1e9f);
        lastNs = now;
        time += dt;
        if (W > 0) {
            update(dt);
            render(c);
        }
        if (running) postInvalidateOnAnimation();
    }

    private void update(float dt) {
        fade = Math.max(0, fade - dt * 3.5f);
        if (pressedT > 0) pressedT -= dt;
        if (screen != SC_GAME) {
            updateDemo(dt);
            return;
        }
        if (paused) return;
        game.update(dt);
        if (showResult) {
            resultT += dt;
            while (starsPlayed < resultStars && resultT > 0.55f + starsPlayed * 0.4f) {
                starsPlayed++;
                sfx.play(Defs.S_STAR, 0.8f, 0f);
                sfx.play(Defs.S_THUD, 0.4f, 0f);
            }
            return;
        }
        stateTime += dt;
        if (state == ST_FLY && stateTime > 1.1f) {
            if (shotsLeft > 0) state = ST_AIM;
            else {
                state = ST_WAIT;
                stateTime = 0;
                settleTime = 0;
            }
        } else if (state == ST_WAIT) {
            if (game.settled()) settleTime += dt;
            else settleTime = 0;
            if (settleTime > 1.0f || stateTime > 7f) finishLevel();
        }
        if (shotsFired > 0 && game.destruction() >= 0.97f) {
            completeTime += dt;
            if (completeTime > 1.8f) finishLevel();
        }
    }

    private void updateDemo(float dt) {
        demo.update(dt);
        demoTimer += dt;
        if (demoShots < 4 && demoTimer > 2.4f) {
            demoTimer = 0;
            demoShots++;
            float minX = 99, maxX = 0, maxY = 0;
            for (Defs.Spec s : Defs.LEVELS[demoLevel].specs) {
                minX = Math.min(minX, s.x);
                maxX = Math.max(maxX, s.x);
                maxY = Math.max(maxY, s.y);
            }
            float tx = minX + (float) Math.random() * (maxX - minX) * 0.5f;
            float ty = 0.5f + (float) Math.random() * maxY;
            float th = (float) Math.toRadians(18 + Math.random() * 25);
            float dx = tx - GameWorld.POUCH_X, dy = ty - GameWorld.POUCH_Y;
            float den = (float) (2 * Math.cos(th) * Math.cos(th) * (dx * Math.tan(th) - dy));
            float v = den > 0 ? (float) Math.sqrt(-GameWorld.GRAVITY * dx * dx / den) : MAX_SPEED;
            v = Math.min(v, MAX_SPEED);
            int type = (int) (Math.random() * Defs.NUM_AMMO);
            demo.launch(type, GameWorld.POUCH_X, GameWorld.POUCH_Y, (float) Math.cos(th) * v, (float) Math.sin(th) * v);
        } else if (demoShots >= 4 && demoTimer > 4f) {
            demoLevel = (demoLevel + 1) % Defs.LEVELS.length;
            demo.load(Defs.LEVELS[demoLevel]);
            demoShots = 0;
            demoTimer = 0;
        }
    }

    // ================================================================ drawing: world

    private float sx(float wx) { return (wx - viewL) * sc; }

    private float sy(float wy) { return H - (wy - viewB) * sc; }

    private Bitmap bg(int theme) {
        if (bgs[theme] == null) {
            int bw = Math.max(1, W / 2), bh = Math.max(1, H / 2);
            bgs[theme] = art.makeBackground(bw, bh, theme, sy(0) / 2f, 1234 + theme);
        }
        return bgs[theme];
    }

    private void drawWorld(Canvas c, GameWorld g, int theme, boolean loaded, int loadedAmmo, float px, float py) {
        dst.set(0, 0, W, H);
        c.drawBitmap(bg(theme), null, dst, bmp);
        art.drawClouds(c, W, H, theme, time);

        float shx = 0, shy = 0;
        if (g.shake > 0) {
            shx = (float) (Math.random() - 0.5) * g.shake * 0.6f * sc;
            shy = (float) (Math.random() - 0.5) * g.shake * 0.6f * sc;
        }
        c.save();
        c.translate(-viewL * sc + shx, H + viewB * sc + shy);
        c.scale(sc, -sc);
        art.drawGround(c, viewL - 2, viewL + W / sc + 2, viewB - 1, theme);
        // soft shadows under blocks
        p.setColor(0x22000000);
        for (GameWorld.Block b : g.blocks) {
            Vec2 bp = b.body.getPosition();
            if (bp.y < 3f) {
                rf.set(bp.x - b.w * 0.55f, -0.12f, bp.x + b.w * 0.55f, 0.08f);
                c.drawOval(rf, p);
            }
        }
        art.drawSlingBack(c, px, py, theme == Defs.T_NIGHT);
        if (loaded) {
            c.save();
            c.translate(px, py);
            art.drawAmmo(c, loadedAmmo);
            c.restore();
        }
        art.drawSlingFront(c, px, py);
        for (int i = 0, n = g.blocks.size(); i < n; i++) art.drawBlock(c, g.blocks.get(i));
        for (int i = 0, n = g.shots.size(); i < n; i++) {
            GameWorld.Shot s = g.shots.get(i);
            if (s.gone) continue;
            Vec2 sp = s.body.getPosition();
            c.save();
            c.translate(sp.x, sp.y);
            c.rotate(s.body.getAngle() * 57.29578f);
            art.drawAmmo(c, s.type);
            c.restore();
        }
        art.drawParticles(c, g.particles);
        c.restore();

        // floating score texts
        for (GameWorld.FloatText t : g.texts) {
            float a = Math.min(1f, t.life * 2.5f);
            float pop = 1f + Math.max(0, (t.life - 0.85f)) * 2f;
            outlined(c, t.text, sx(t.x) + shx, sy(t.y) + shy, 4.2f * u * pop, Defs.withAlpha(t.color, (int) (255 * a)),
                    Defs.withAlpha(0xFF2A1A0A, (int) (255 * a)), Paint.Align.CENTER);
        }
        // projectiles above the screen
        for (GameWorld.Shot s : g.shots) {
            if (s.gone) continue;
            Vec2 sp = s.body.getPosition();
            if (sy(sp.y) < 0) {
                float x = sx(sp.x);
                path.reset();
                path.moveTo(x, 1.2f * u);
                path.lineTo(x - 1.8f * u, 4.2f * u);
                path.lineTo(x + 1.8f * u, 4.2f * u);
                path.close();
                p.setColor(0xCCFFFFFF);
                c.drawPath(path, p);
            }
        }
    }

    private float pouchX() { return GameWorld.POUCH_X + (aiming ? pullX : 0); }

    private float pouchY() { return GameWorld.POUCH_Y + (aiming ? pullY : 0); }

    // ================================================================ drawing: screens

    private void render(Canvas c) {
        btns.clear();
        if (screen == SC_GAME) drawGame(c);
        else {
            drawWorld(c, demo, Defs.LEVELS[demoLevel].theme, false, 0, GameWorld.POUCH_X, GameWorld.POUCH_Y);
            if (screen == SC_MENU) drawMenu(c);
            else drawLevels(c);
        }
        if (fade > 0) {
            p.setColor(Defs.withAlpha(0xFF0B0820, (int) (fade * 255)));
            c.drawRect(0, 0, W, H, p);
        }
    }

    private void drawMenu(Canvas c) {
        p.setShader(new LinearGradient(0, 0, 0, H, 0xAA0B0A2A, 0x330B0A2A, Shader.TileMode.CLAMP));
        c.drawRect(0, 0, W, H, p);
        p.setShader(null);

        float cx = W / 2f;
        float bob = (float) Math.sin(time * 2.2f) * 1.2f * u;
        c.save();
        c.rotate((float) Math.sin(time * 1.3f) * 1.5f, cx, 24 * u);
        title(c, "SLING", cx, 22 * u + bob, 17 * u, 0xFFFFD23F);
        title(c, "SMASH!", cx, 40 * u + bob, 19 * u, 0xFFFF5A3C);
        c.restore();
        outlined(c, "Launch anything. Destroy everything.", cx, 50 * u, 4.2f * u, 0xFFFFFFFF, 0xFF1B1238, Paint.Align.CENTER);

        float pulse = 1f + (float) Math.sin(time * 4f) * 0.04f;
        float bw = 38 * u * pulse, bh = 15 * u * pulse;
        rf.set(cx - bw / 2, 63 * u - bh / 2, cx + bw / 2, 63 * u + bh / 2);
        button(c, rf, "PLAY", 0xFF3BC44B, B_PLAY, 0);

        // stars badge
        String st = totalStars() + " / " + (Defs.LEVELS.length * 3);
        tp.setTextSize(4.4f * u);
        float tw = tp.measureText(st);
        rf.set(W - inset - tw - 13 * u, 4 * u, W - inset, 13 * u);
        p.setColor(0x99000000);
        c.drawRoundRect(rf, 4.5f * u, 4.5f * u, p);
        star(c, rf.left + 5 * u, rf.centerY(), 3.2f * u, true, 1f);
        outlined(c, st, rf.left + 9.5f * u + tw / 2, rf.centerY() + 1.6f * u, 4.4f * u, 0xFFFFFFFF, 0xFF000000, Paint.Align.CENTER);

        // sound toggle
        rf.set(W - inset - 12 * u, H - 15 * u, W - inset, H - 3 * u);
        button(c, rf, null, 0xFF5B6CFF, B_SOUND, sfx.muted ? 5 : 4);

        outlined(c, "20 buildings  •  10 crazy projectiles", cx, H - 6 * u, 3.4f * u, 0xDDFFFFFF, 0xFF1B1238, Paint.Align.CENTER);
    }

    private void title(Canvas c, String s, float x, float y, float size, int color) {
        tp.setTextSize(size);
        tp.setStyle(Paint.Style.FILL);
        tp.setColor(0x66000000);
        c.drawText(s, x + size * 0.04f, y + size * 0.08f, tp);
        tp.setStyle(Paint.Style.STROKE);
        tp.setStrokeWidth(size * 0.16f);
        tp.setStrokeJoin(Paint.Join.ROUND);
        tp.setColor(0xFF22123A);
        c.drawText(s, x, y, tp);
        tp.setStyle(Paint.Style.FILL);
        tp.setShader(new LinearGradient(0, y - size * 0.75f, 0, y, Defs.shade(color, 1.35f), Defs.shade(color, 0.85f), Shader.TileMode.CLAMP));
        c.drawText(s, x, y, tp);
        tp.setShader(null);
        tp.setColor(0x55FFFFFF);
        c.save();
        c.clipRect(0, y - size * 0.75f, W, y - size * 0.5f);
        c.drawText(s, x, y, tp);
        c.restore();
    }

    private void drawLevels(Canvas c) {
        p.setColor(0xB80B0A24);
        c.drawRect(0, 0, W, H, p);
        rf.set(inset, 3 * u, inset + 11 * u, 14 * u);
        button(c, rf, null, 0xFFFF7A3C, B_BACK, 1);
        outlined(c, "CHOOSE YOUR TARGET", W / 2f, 11.5f * u, 7 * u, 0xFFFFD23F, 0xFF22123A, Paint.Align.CENTER);
        String st = totalStars() + " / " + (Defs.LEVELS.length * 3);
        tp.setTextSize(4.2f * u);
        float tw = tp.measureText(st);
        star(c, W - inset - tw - 4.5f * u, 8.5f * u, 3 * u, true, 1f);
        outlined(c, st, W - inset - tw / 2, 10 * u, 4.2f * u, 0xFFFFFFFF, 0xFF000000, Paint.Align.CENTER);

        int cols = 5, rows = 4;
        float top = 18 * u, bottom = H - 3 * u, gap = 2.2f * u;
        float cw = (W - 2 * inset - (cols - 1) * gap) / cols;
        float ch = (bottom - top - (rows - 1) * gap) / rows;
        ensurePreviews((int) cw, (int) (ch * 0.72f));
        for (int i = 0; i < Defs.LEVELS.length; i++) {
            int col = i % cols, row = i / cols;
            float x = inset + col * (cw + gap), y = top + row * (ch + gap);
            float press = (pressedId == B_LEVEL + i && pressedT > 0) ? 0.94f : 1f;
            float enter = Math.min(1f, Math.max(0f, (1f - fade) * 1.4f - i * 0.02f));
            float s = press * (0.85f + 0.15f * enter);
            c.save();
            c.scale(s, s, x + cw / 2, y + ch / 2);
            rf.set(x, y + 0.8f * u, x + cw, y + ch + 0.8f * u);
            p.setColor(0x66000000);
            c.drawRoundRect(rf, 2.4f * u, 2.4f * u, p);
            rf.set(x, y, x + cw, y + ch);
            p.setColor(0xFFFFF6E3);
            c.drawRoundRect(rf, 2.4f * u, 2.4f * u, p);
            float ph = ch * 0.72f;
            c.save();
            path.reset();
            rf2.set(x + 0.6f * u, y + 0.6f * u, x + cw - 0.6f * u, y + ph);
            path.addRoundRect(rf2, 1.9f * u, 1.9f * u, Path.Direction.CW);
            c.clipPath(path);
            if (previews != null && previews[i] != null) {
                dst.set((int) rf2.left, (int) rf2.top, (int) rf2.right, (int) rf2.bottom);
                c.drawBitmap(previews[i], null, dst, bmp);
            }
            c.restore();
            // number badge
            p.setColor(0xFF22123A);
            c.drawCircle(x + 3.4f * u, y + 3.4f * u, 2.6f * u, p);
            outlined(c, String.valueOf(i + 1), x + 3.4f * u, y + 4.6f * u, 3.2f * u, 0xFFFFFFFF, 0xFF22123A, Paint.Align.CENTER);
            // stars
            int stars = prefs.getInt("stars" + i, 0);
            rf2.set(x + cw - 12.6f * u, y + 1.2f * u, x + cw - 1.2f * u, y + 5.6f * u);
            p.setColor(0x88000000);
            c.drawRoundRect(rf2, 2.2f * u, 2.2f * u, p);
            for (int k = 0; k < 3; k++) star(c, rf2.left + 2.1f * u + k * 3.6f * u, rf2.centerY(), 1.65f * u, k < stars, 1f);
            // name
            tp.setTextSize(Math.min(3.6f * u, cw * 0.085f));
            tp.setColor(0xFF2A1C3E);
            c.drawText(Defs.LEVELS[i].name, x + cw / 2, y + ph + (ch - ph) * 0.62f, tp);
            c.restore();
            btns.add(new float[]{B_LEVEL + i, x, y, x + cw, y + ch});
        }
    }

    private void ensurePreviews(int w, int h) {
        if (previews != null || w <= 0 || h <= 0) return;
        previews = new Bitmap[Defs.LEVELS.length];
        for (int i = 0; i < previews.length; i++) {
            Defs.LevelDef d = Defs.LEVELS[i];
            Bitmap b = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
            Canvas c = new Canvas(b);
            int[] t = Art.THEMES[d.theme];
            p.setShader(new LinearGradient(0, 0, 0, h, t[0], t[1], Shader.TileMode.CLAMP));
            c.drawRect(0, 0, w, h, p);
            p.setShader(null);
            float minX = 1e9f, maxX = -1e9f, maxY = 0;
            for (Defs.Spec s : d.specs) {
                minX = Math.min(minX, s.x - s.w / 2);
                maxX = Math.max(maxX, s.x + s.w / 2);
                maxY = Math.max(maxY, s.y + s.h / 2);
                if (s.verts != null) maxY = Math.max(maxY, s.y + s.h);
            }
            float groundH = h * 0.14f;
            float k = Math.min((w * 0.84f) / (maxX - minX), (h - groundH - h * 0.1f) / maxY);
            p.setColor(t[5]);
            c.drawRect(0, h - groundH, w, h, p);
            p.setColor(t[6]);
            c.drawRect(0, h - groundH * 0.6f, w, h, p);
            c.save();
            c.translate(w / 2f - (minX + maxX) / 2f * k, h - groundH);
            c.scale(k, -k);
            for (Defs.Spec s : d.specs) art.drawSpecFlat(c, s);
            c.restore();
            previews[i] = b;
        }
    }

    // ---------------------------------------------------------------- game screen

    private void drawGame(Canvas c) {
        Defs.LevelDef def = Defs.LEVELS[level];
        boolean loaded = state == ST_AIM && !showResult;
        drawWorld(c, game, def.theme, loaded, ammo, pouchX(), pouchY());

        if (aiming && loaded) drawTrajectory(c);

        if (!showResult) drawHud(c, def);
        if (paused) drawPause(c);
        if (showResult) drawResult(c);
    }

    private void drawTrajectory(Canvas c) {
        float len = (float) Math.hypot(pullX, pullY);
        if (len < 0.35f) return;
        float vx = -pullX * MAX_SPEED / MAX_PULL, vy = -pullY * MAX_SPEED / MAX_PULL;
        float x = pouchX(), y = pouchY();
        for (int i = 1; i <= 22; i++) {
            float t = i * 0.075f;
            float wx = x + vx * t, wy = y + vy * t + 0.5f * GameWorld.GRAVITY * t * t;
            if (wy < 0) break;
            float a = 1f - i / 24f;
            p.setColor(Defs.withAlpha(0xFFFFFFFF, (int) (230 * a)));
            c.drawCircle(sx(wx), sy(wy), (1.05f - i * 0.025f) * u, p);
        }
        // power label
        int pct = Math.round(Math.min(1f, len / MAX_PULL) * 100);
        outlined(c, pct + "%", sx(pouchX()), sy(pouchY()) - 5 * u, 3.6f * u, 0xFFFFFFFF, 0xFF22123A, Paint.Align.CENTER);
    }

    private void drawHud(Canvas c, Defs.LevelDef def) {
        // top-left buttons
        rf.set(inset, 3 * u, inset + 11 * u, 14 * u);
        button(c, rf, null, 0xFF5B6CFF, B_PAUSE, 2);
        rf.set(inset + 13 * u, 3 * u, inset + 24 * u, 14 * u);
        button(c, rf, null, 0xFFFF7A3C, B_RESTART, 3);

        // destruction meter
        float d = game.destruction();
        float mw = Math.min(W * 0.36f, 70 * u), mx = W / 2f - mw / 2, my = 8.5f * u, mh = 4.4f * u;
        outlined(c, (level + 1) + ". " + def.name.toUpperCase(), W / 2f, 6.2f * u, 3.6f * u, 0xFFFFFFFF, 0xFF22123A, Paint.Align.CENTER);
        rf.set(mx - 0.6f * u, my - 0.6f * u, mx + mw + 0.6f * u, my + mh + 0.6f * u);
        p.setColor(0xCC1B1238);
        c.drawRoundRect(rf, mh, mh, p);
        if (d > 0.005f) {
            rf.set(mx, my, mx + mw * Math.max(d, 0.06f), my + mh);
            p.setShader(new LinearGradient(mx, 0, mx + mw, 0, 0xFFFFC93C, 0xFFFF4B2B, Shader.TileMode.CLAMP));
            c.drawRoundRect(rf, mh / 2, mh / 2, p);
            p.setShader(null);
            p.setColor(0x55FFFFFF);
            rf.set(rf.left + mh * 0.3f, my + mh * 0.15f, rf.right - mh * 0.3f, my + mh * 0.42f);
            c.drawRoundRect(rf, mh / 4, mh / 4, p);
        }
        float[] th = {0.4f, 0.65f, 0.85f};
        for (float t : th) star(c, mx + mw * t, my + mh / 2, 2.6f * u, d >= t, 1f);
        outlined(c, Math.round(d * 100) + "% DESTROYED", W / 2f, my + mh + 4.6f * u, 3.2f * u, 0xFFFFFFFF, 0xFF22123A, Paint.Align.CENTER);

        // score + shots
        outlined(c, String.format(java.util.Locale.US, "%,d", game.score), W - inset, 9 * u, 6 * u, 0xFFFFE066, 0xFF22123A, Paint.Align.RIGHT);
        outlined(c, "SHOTS", W - inset - (def.shots) * 3.4f * u - 1.5f * u, 15.2f * u, 2.8f * u, 0xFFFFFFFF, 0xFF22123A, Paint.Align.RIGHT);
        for (int i = 0; i < def.shots; i++) {
            float x = W - inset - 1.5f * u - (def.shots - 1 - i) * 3.4f * u;
            boolean has = i < shotsLeft;
            p.setColor(0xFF22123A);
            c.drawCircle(x, 14.2f * u, 1.45f * u, p);
            p.setColor(has ? 0xFFFF7A3C : 0x55FFFFFF);
            c.drawCircle(x, 14.2f * u, 1.05f * u, p);
        }

        // ammo bar
        float slot = 11.5f * u, gap = 1.2f * u;
        float barW = Defs.NUM_AMMO * slot + (Defs.NUM_AMMO - 1) * gap + 2.4f * u;
        float bx = Math.max(inset, (W - barW) / 2f), by = H - slot - 4 * u;
        rf.set(bx, by - 1.2f * u, bx + barW, H - 2.2f * u);
        p.setColor(0x8C120C26);
        c.drawRoundRect(rf, 4 * u, 4 * u, p);
        for (int i = 0; i < Defs.NUM_AMMO; i++) {
            float x = bx + 1.2f * u + i * (slot + gap), cx = x + slot / 2, cy = by + slot / 2;
            boolean sel = i == ammo;
            float s = sel ? 1.08f + (float) Math.sin(time * 6) * 0.03f : ((pressedId == B_AMMO + i && pressedT > 0) ? 0.9f : 1f);
            float rr = slot / 2 * s;
            p.setColor(sel ? 0xFFFFD23F : 0xFF2B2150);
            c.drawCircle(cx, cy, rr, p);
            p.setColor(sel ? 0xFFFFF3C4 : 0xFF3F3470);
            c.drawCircle(cx, cy, rr * 0.86f, p);
            float br = ammoRadius(i);
            float k = rr * 0.62f / br;
            c.save();
            c.translate(cx, cy);
            c.scale(k, -k);
            c.rotate(i == Defs.A_CAR || i == Defs.A_BRICK ? 0 : 0);
            art.drawAmmo(c, i);
            c.restore();
            btns.add(new float[]{B_AMMO + i, x - gap / 2, by - 1.2f * u, x + slot + gap / 2, H});
        }
        float selX = bx + 1.2f * u + ammo * (slot + gap) + slot / 2;
        String nm = Defs.AMMO_NAME[ammo].toUpperCase();
        tp.setTextSize(3.4f * u);
        float nw = tp.measureText(nm) + 4 * u;
        float lx = Math.max(nw / 2 + inset, Math.min(W - inset - nw / 2, selX));
        rf.set(lx - nw / 2, by - 7.2f * u, lx + nw / 2, by - 2.2f * u);
        p.setColor(0xFFFFD23F);
        c.drawRoundRect(rf, 2.5f * u, 2.5f * u, p);
        tp.setColor(0xFF22123A);
        c.drawText(nm, lx, by - 3.5f * u, tp);

        // tutorial hint
        if (level == 0 && shotsFired == 0 && !aiming && state == ST_AIM) {
            float a = 0.6f + 0.4f * (float) Math.sin(time * 4);
            float hx = sx(GameWorld.POUCH_X), hy = sy(GameWorld.POUCH_Y);
            float t = (time % 1.6f) / 1.6f;
            p.setColor(Defs.withAlpha(0xFFFFFFFF, (int) (200 * (1 - t))));
            c.drawCircle(hx - t * 9 * u, hy + t * 7 * u, 2.4f * u, p);
            outlined(c, "Drag back anywhere & release to FIRE!", W / 2f, H * 0.42f, 4.6f * u,
                    Defs.withAlpha(0xFFFFFFFF, (int) (255 * a)), Defs.withAlpha(0xFF22123A, (int) (255 * a)), Paint.Align.CENTER);
            outlined(c, "Pick your projectile below", W / 2f, H * 0.42f + 6 * u, 3.4f * u,
                    Defs.withAlpha(0xFFFFE066, (int) (255 * a)), Defs.withAlpha(0xFF22123A, (int) (255 * a)), Paint.Align.CENTER);
        }
        if (state == ST_WAIT) {
            outlined(c, "No shots left...", W / 2f, H * 0.3f, 4.6f * u, 0xEEFFFFFF, 0xFF22123A, Paint.Align.CENTER);
        }
    }

    private float ammoRadius(int t) {
        float[] s = Defs.AMMO_SIZE[t];
        if (Defs.AMMO_SHAPE[t] == Defs.SH_BOX) return (float) Math.hypot(s[0], s[1]) * 0.92f;
        return s[0];
    }

    private void panel(Canvas c, float w, float h, String title, int titleColor) {
        p.setColor(0xAA07051A);
        c.drawRect(0, 0, W, H, p);
        float x = W / 2f - w / 2, y = H / 2f - h / 2;
        rf.set(x, y + 1.4f * u, x + w, y + h + 1.4f * u);
        p.setColor(0x88000000);
        c.drawRoundRect(rf, 4 * u, 4 * u, p);
        rf.set(x, y, x + w, y + h);
        p.setShader(new LinearGradient(0, y, 0, y + h, 0xFF3A2A78, 0xFF231850, Shader.TileMode.CLAMP));
        c.drawRoundRect(rf, 4 * u, 4 * u, p);
        p.setShader(null);
        ps.setColor(0x55FFFFFF);
        ps.setStrokeWidth(0.5f * u);
        c.drawRoundRect(rf, 4 * u, 4 * u, ps);
        // ribbon
        float rw = w * 0.82f;
        rf.set(W / 2f - rw / 2, y - 5 * u, W / 2f + rw / 2, y + 7 * u);
        p.setColor(Defs.shade(titleColor, 0.7f));
        c.drawRoundRect(rf.left - 2 * u, rf.top + 2 * u, rf.right + 2 * u, rf.bottom + 2 * u, 3 * u, 3 * u, p);
        p.setColor(titleColor);
        c.drawRoundRect(rf, 3 * u, 3 * u, p);
        outlined(c, title, W / 2f, y + 3.6f * u, 7 * u, 0xFFFFFFFF, 0xFF22123A, Paint.Align.CENTER);
    }

    private void drawPause(Canvas c) {
        btns.clear();
        float w = 56 * u, h = 60 * u;
        panel(c, w, h, "PAUSED", 0xFF5B6CFF);
        float x = W / 2f - 22 * u, y = H / 2f - h / 2 + 14 * u;
        rf.set(x, y, x + 44 * u, y + 11 * u);
        button(c, rf, "RESUME", 0xFF3BC44B, B_RESUME, 0);
        rf.set(x, y + 14 * u, x + 44 * u, y + 25 * u);
        button(c, rf, "RESTART", 0xFFFF7A3C, B_RESTART, 0);
        rf.set(x, y + 28 * u, x + 44 * u, y + 39 * u);
        button(c, rf, "LEVELS", 0xFF5B6CFF, B_LEVELS, 0);
    }

    private void drawResult(Canvas c) {
        float appear = Math.min(1f, resultT * 3f);
        float ease = 1f - (1f - appear) * (1f - appear);
        c.save();
        c.translate(0, (1f - ease) * H * 0.3f);
        float w = 74 * u, h = 72 * u;
        String title = resultStars == 3 ? "DEMOLISHED!" : (resultStars > 0 ? "NICE SMASH!" : "STILL STANDING");
        panel(c, w, h, title, resultStars > 0 ? 0xFFFF7A3C : 0xFF8A8AA0);
        float top = H / 2f - h / 2;
        for (int k = 0; k < 3; k++) {
            float sxp = W / 2f + (k - 1) * 14 * u;
            float syp = top + 20 * u - (k == 1 ? 2.5f * u : 0);
            star(c, sxp, syp, 6.2f * u, false, 1f);
            if (k < starsPlayed) {
                float st = resultT - (0.55f + k * 0.4f);
                float pop = st < 0.18f ? 0.3f + st / 0.18f * 1.0f : (st < 0.3f ? 1.3f - (st - 0.18f) / 0.12f * 0.3f : 1f);
                star(c, sxp, syp, 6.2f * u, true, pop);
            }
        }
        outlined(c, Math.round(resultDestr * 100) + "% DESTROYED", W / 2f, top + 36 * u, 4.8f * u, 0xFFFFFFFF, 0xFF120B2A, Paint.Align.CENTER);
        float shown = Math.min(1f, resultT / 1.4f);
        outlined(c, "SCORE " + String.format(java.util.Locale.US, "%,d", (int) (resultScore * shown)), W / 2f, top + 45 * u, 6 * u,
                0xFFFFE066, 0xFF120B2A, Paint.Align.CENTER);
        int best = prefs.getInt("best" + level, 0);
        outlined(c, newBest ? "NEW BEST!" : "BEST " + String.format(java.util.Locale.US, "%,d", best), W / 2f, top + 51.5f * u, 3.4f * u,
                newBest ? 0xFF7CFF8A : 0xCCFFFFFF, 0xFF120B2A, Paint.Align.CENTER);
        float by = top + h - 16 * u, bw = 20 * u, bh = 11 * u, gap = 2.5f * u;
        float bx = W / 2f - (bw * 3 + gap * 2) / 2;
        rf.set(bx, by, bx + bw, by + bh);
        button(c, rf, null, 0xFF5B6CFF, B_LEVELS, 6);
        rf.set(bx + bw + gap, by, bx + 2 * bw + gap, by + bh);
        button(c, rf, null, 0xFFFF7A3C, B_RETRY, 3);
        rf.set(bx + 2 * (bw + gap), by, bx + 3 * bw + 2 * gap, by + bh);
        button(c, rf, null, 0xFF3BC44B, B_NEXT, 7);
        c.restore();
        if (appear < 1f) btns.clear();
    }

    // ================================================================ widgets

    /** icon: 0 none, 1 back, 2 pause, 3 restart, 4 sound on, 5 sound off, 6 grid, 7 next */
    private void button(Canvas c, RectF r, String label, int color, int id, int icon) {
        boolean pressed = pressedId == id && pressedT > 0;
        float s = pressed ? 0.92f : 1f;
        c.save();
        c.scale(s, s, r.centerX(), r.centerY());
        float rad = Math.min(r.height(), r.width()) * 0.3f;
        float lip = r.height() * 0.1f;
        rf2.set(r.left, r.top + lip, r.right, r.bottom + lip);
        p.setColor(0x66000000);
        c.drawRoundRect(rf2.left, rf2.top + lip * 0.6f, rf2.right, rf2.bottom + lip * 0.6f, rad, rad, p);
        p.setColor(Defs.shade(color, 0.62f));
        c.drawRoundRect(rf2, rad, rad, p);
        p.setShader(new LinearGradient(0, r.top, 0, r.bottom, Defs.shade(color, 1.28f), color, Shader.TileMode.CLAMP));
        c.drawRoundRect(r, rad, rad, p);
        p.setShader(null);
        p.setColor(0x40FFFFFF);
        rf2.set(r.left + rad * 0.5f, r.top + r.height() * 0.08f, r.right - rad * 0.5f, r.top + r.height() * 0.38f);
        c.drawRoundRect(rf2, rad * 0.6f, rad * 0.6f, p);
        ps.setColor(0xFF22123A);
        ps.setStrokeWidth(0.45f * u);
        c.drawRoundRect(r, rad, rad, ps);
        if (label != null) {
            float ts = r.height() * 0.45f;
            outlined(c, label, r.centerX(), r.centerY() + ts * 0.36f, ts, 0xFFFFFFFF, 0xFF22123A, Paint.Align.CENTER);
        }
        if (icon > 0) icon(c, icon, r.centerX(), r.centerY(), r.height() * 0.27f);
        c.restore();
        btns.add(new float[]{id, r.left, r.top, r.right, r.bottom});
    }

    private void icon(Canvas c, int icon, float x, float y, float s) {
        ps.setColor(0xFF22123A);
        ps.setStrokeWidth(s * 0.62f);
        Paint fg = p;
        fg.setColor(0xFFFFFFFF);
        for (int pass = 0; pass < 2; pass++) {
            boolean outline = pass == 0;
            Paint sp = outline ? ps : null;
            switch (icon) {
                case 1: case 7: {
                    float d = icon == 1 ? 1 : -1;
                    path.reset();
                    path.moveTo(x + s * 0.5f * d, y - s);
                    path.lineTo(x - s * 0.6f * d, y);
                    path.lineTo(x + s * 0.5f * d, y + s);
                    strokePath(c, path, s, outline);
                    break;
                }
                case 2:
                    line(c, x - s * 0.4f, y - s * 0.8f, x - s * 0.4f, y + s * 0.8f, s, outline);
                    line(c, x + s * 0.4f, y - s * 0.8f, x + s * 0.4f, y + s * 0.8f, s, outline);
                    break;
                case 3: {
                    path.reset();
                    rf2.set(x - s * 0.85f, y - s * 0.85f, x + s * 0.85f, y + s * 0.85f);
                    path.addArc(rf2, -60, 290);
                    strokePath(c, path, s, outline);
                    path.reset();
                    float ax = x + s * 0.85f * (float) Math.cos(Math.toRadians(-60)), ay = y + s * 0.85f * (float) Math.sin(Math.toRadians(-60));
                    path.moveTo(ax - s * 0.55f, ay - s * 0.15f);
                    path.lineTo(ax + s * 0.05f, ay + s * 0.05f);
                    path.lineTo(ax + s * 0.25f, ay - s * 0.6f);
                    strokePath(c, path, s, outline);
                    break;
                }
                case 4: case 5: {
                    path.reset();
                    path.moveTo(x - s * 1.0f, y - s * 0.35f);
                    path.lineTo(x - s * 0.5f, y - s * 0.35f);
                    path.lineTo(x, y - s * 0.85f);
                    path.lineTo(x, y + s * 0.85f);
                    path.lineTo(x - s * 0.5f, y + s * 0.35f);
                    path.lineTo(x - s * 1.0f, y + s * 0.35f);
                    path.close();
                    strokePath(c, path, s * 0.6f, outline);
                    if (!outline) c.drawPath(path, fg);
                    if (icon == 4) {
                        path.reset();
                        rf2.set(x - s * 0.2f, y - s * 0.7f, x + s * 0.9f, y + s * 0.7f);
                        path.addArc(rf2, -50, 100);
                        strokePath(c, path, s * 0.8f, outline);
                    } else {
                        line(c, x + s * 0.35f, y - s * 0.4f, x + s * 1.05f, y + s * 0.4f, s * 0.8f, outline);
                        line(c, x + s * 1.05f, y - s * 0.4f, x + s * 0.35f, y + s * 0.4f, s * 0.8f, outline);
                    }
                    break;
                }
                case 6:
                    for (int i = 0; i < 2; i++)
                        for (int j = 0; j < 2; j++) {
                            float cx = x + (i - 0.5f) * s * 0.95f, cy = y + (j - 0.5f) * s * 0.95f;
                            rf2.set(cx - s * 0.32f, cy - s * 0.32f, cx + s * 0.32f, cy + s * 0.32f);
                            if (outline) c.drawRoundRect(rf2, s * 0.12f, s * 0.12f, ps);
                            else c.drawRoundRect(rf2, s * 0.12f, s * 0.12f, fg);
                        }
                    break;
            }
            if (sp != null) sp.setStrokeWidth(s * 0.62f);
        }
    }

    private void strokePath(Canvas c, Path pth, float s, boolean outline) {
        if (outline) {
            ps.setColor(0xFF22123A);
            ps.setStrokeWidth(s * 0.62f);
        } else {
            ps.setColor(0xFFFFFFFF);
            ps.setStrokeWidth(s * 0.32f);
        }
        c.drawPath(pth, ps);
    }

    private void line(Canvas c, float x1, float y1, float x2, float y2, float s, boolean outline) {
        if (outline) {
            ps.setColor(0xFF22123A);
            ps.setStrokeWidth(s * 0.62f);
        } else {
            ps.setColor(0xFFFFFFFF);
            ps.setStrokeWidth(s * 0.32f);
        }
        c.drawLine(x1, y1, x2, y2, ps);
    }

    private void star(Canvas c, float x, float y, float r, boolean filled, float scale) {
        path.reset();
        float ro = r * scale, ri = ro * 0.48f;
        for (int i = 0; i < 10; i++) {
            double a = -Math.PI / 2 + i * Math.PI / 5;
            float rr = i % 2 == 0 ? ro : ri;
            float px = x + (float) Math.cos(a) * rr, py = y + (float) Math.sin(a) * rr;
            if (i == 0) path.moveTo(px, py);
            else path.lineTo(px, py);
        }
        path.close();
        ps.setStrokeWidth(ro * 0.28f);
        ps.setColor(filled ? 0xFF8A4A00 : 0xAA0B0820);
        c.drawPath(path, ps);
        if (filled) {
            p.setShader(new LinearGradient(0, y - ro, 0, y + ro, 0xFFFFF09A, 0xFFFFB31F, Shader.TileMode.CLAMP));
            c.drawPath(path, p);
            p.setShader(null);
        } else {
            p.setColor(0x55FFFFFF);
            c.drawPath(path, p);
        }
    }

    private void outlined(Canvas c, String s, float x, float y, float size, int fill, int stroke, Paint.Align align) {
        tp.setTextAlign(align);
        tp.setTextSize(size);
        tp.setStyle(Paint.Style.STROKE);
        tp.setStrokeWidth(size * 0.2f);
        tp.setStrokeJoin(Paint.Join.ROUND);
        tp.setColor(stroke);
        c.drawText(s, x, y, tp);
        tp.setStyle(Paint.Style.FILL);
        tp.setColor(fill);
        c.drawText(s, x, y, tp);
        tp.setTextAlign(Paint.Align.CENTER);
    }

    // ================================================================ input

    @Override
    public boolean onTouchEvent(MotionEvent e) {
        int action = e.getActionMasked();
        int idx = e.getActionIndex();
        float x = e.getX(idx), y = e.getY(idx);
        switch (action) {
            case MotionEvent.ACTION_DOWN:
            case MotionEvent.ACTION_POINTER_DOWN: {
                for (int i = btns.size() - 1; i >= 0; i--) {
                    float[] b = btns.get(i);
                    if (x >= b[1] && x <= b[3] && y >= b[2] && y <= b[4]) {
                        onButton((int) b[0]);
                        return true;
                    }
                }
                if (screen == SC_GAME && !paused && !showResult && state == ST_AIM && !aiming) {
                    aiming = true;
                    aimId = e.getPointerId(idx);
                    tx0 = x;
                    ty0 = y;
                    pullX = pullY = 0;
                    sfx.play(Defs.S_STRETCH, 0.6f, 0.05f);
                } else if (screen == SC_MENU) {
                    // tapping anywhere on the title also starts
                    if (y > H * 0.5f && y < H * 0.75f) onButton(B_PLAY);
                }
                return true;
            }
            case MotionEvent.ACTION_MOVE: {
                if (aiming) {
                    int pi = e.findPointerIndex(aimId);
                    if (pi >= 0) updatePull(e.getX(pi), e.getY(pi));
                }
                return true;
            }
            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_POINTER_UP:
            case MotionEvent.ACTION_CANCEL: {
                if (aiming && e.getPointerId(idx) == aimId) {
                    updatePull(x, y);
                    if (action != MotionEvent.ACTION_CANCEL) fire();
                    aiming = false;
                    aimId = -1;
                }
                return true;
            }
        }
        return true;
    }

    private void updatePull(float x, float y) {
        float dx = (x - tx0) / sc * 0.85f, dy = -(y - ty0) / sc * 0.85f;
        float len = (float) Math.hypot(dx, dy);
        if (len > MAX_PULL) {
            dx *= MAX_PULL / len;
            dy *= MAX_PULL / len;
        }
        if (GameWorld.POUCH_Y + dy < 1.0f) dy = 1.0f - GameWorld.POUCH_Y;
        pullX = dx;
        pullY = dy;
    }

    private void fire() {
        float len = (float) Math.hypot(pullX, pullY);
        if (len < 0.35f || state != ST_AIM) return;
        float vx = -pullX * MAX_SPEED / MAX_PULL, vy = -pullY * MAX_SPEED / MAX_PULL;
        game.launch(ammo, pouchX(), pouchY(), vx, vy);
        shotsLeft--;
        shotsFired++;
        state = ST_FLY;
        stateTime = 0;
        vibrate(15);
    }

    private void onButton(int id) {
        pressedId = id;
        pressedT = 0.12f;
        click();
        if (id >= B_AMMO) {
            ammo = id - B_AMMO;
            return;
        }
        if (id >= B_LEVEL) {
            startLevel(id - B_LEVEL);
            return;
        }
        switch (id) {
            case B_PLAY:
                go(SC_LEVELS);
                break;
            case B_SOUND:
                sfx.muted = !sfx.muted;
                prefs.edit().putBoolean("muted", sfx.muted).apply();
                break;
            case B_BACK:
                go(SC_MENU);
                break;
            case B_PAUSE:
                paused = true;
                aiming = false;
                break;
            case B_RESUME:
                paused = false;
                break;
            case B_RESTART:
            case B_RETRY:
                startLevel(level);
                break;
            case B_LEVELS:
                go(SC_LEVELS);
                break;
            case B_NEXT:
                if (level + 1 < Defs.LEVELS.length) startLevel(level + 1);
                else go(SC_LEVELS);
                break;
        }
    }
}
