package com.slingsmash.game;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Canvas;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.Typeface;
import android.os.Build;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.view.MotionEvent;
import android.view.View;

import org.jbox2d.common.Vec2;

import java.util.ArrayList;
import java.util.Locale;

public final class GameView extends View implements GameWorld.Fx {

    private static final int SC_MENU = 0, SC_WORLDS = 1, SC_LEVELS = 2, SC_GAME = 3, SC_ARMORY = 4;
    private static final int ST_AIM = 0, ST_FLY = 1, ST_WAIT = 2;
    private static final float MAX_PULL = 3.4f, MAX_SPEED = 27f;
    private static final float[] STAR_TH = {0.4f, 0.65f, 0.85f};

    // button ids
    private static final int B_PLAY = 1, B_ARMORY = 2, B_SANDBOX = 3, B_SOUND = 4, B_VIBE = 5, B_BACK = 6, B_PAUSE = 7,
            B_RESTART = 8, B_RESUME = 9, B_LEVELS = 10, B_NEXT = 11, B_RETRY = 12, B_BUY = 13, B_HOME = 14,
            B_WORLD = 100, B_LEVEL = 200, B_TAB = 300, B_ITEM = 400;

    private final Typeface font;
    private final Art art;
    private final Ui ui;
    private final Sfx sfx;
    private final Vibrator vibrator;
    private final SharedPreferences prefs;
    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final RectF rf = new RectF();
    private final Path path = new Path();

    private final GameWorld game;
    private final GameWorld demo;
    private int screen = SC_MENU, armoryReturn = SC_MENU;
    private boolean sandbox;
    private int world, level, ammo, state, shotsLeft, shotsFired;
    private float stateTime, settleTime, completeTime;
    private boolean paused, showResult, vibeOn = true;
    private float resultT;
    private int resultStars, resultScore, starsPlayed, coinsEarned, resultCombo;
    private float resultDestr;
    private boolean newBest;
    private int coins;
    private String toast;
    private float toastT;

    // demo
    private int demoLevel;
    private float demoTimer;
    private int demoShots;

    // view / camera
    private int W, H;
    private float s0, sc, viewL, viewB = -4.6f, camX = 19f, camZ = 1f;
    private float k, ox, oy, L, R, T, Bm; // design space mapping
    private float time, fade, dtLast;
    private long lastNs;
    private boolean running = true;

    // aiming / dragging
    private boolean aiming;
    private int aimId = -1;
    private float tx0, ty0, pullX, pullY;
    private boolean barDrag, barMoved, gridDrag, gridMoved;
    private float dragX0, dragY0, scroll0;
    private float barScroll, gridScroll;
    private int armoryTab, armorySel = Defs.A_HOLE;
    private final ArrayList<Integer> owned = new ArrayList<>();

    public GameView(Context ctx) {
        super(ctx);
        Typeface tf;
        try {
            tf = Typeface.createFromAsset(ctx.getAssets(), "LilitaOne.ttf");
        } catch (Exception e) {
            tf = Typeface.create("sans-serif-black", Typeface.NORMAL);
        }
        font = tf;
        art = new Art(font);
        ui = new Ui(font);
        sfx = new Sfx(ctx);
        vibrator = (Vibrator) ctx.getSystemService(Context.VIBRATOR_SERVICE);
        prefs = ctx.getSharedPreferences("slingsmash", Context.MODE_PRIVATE);
        sfx.muted = prefs.getBoolean("muted", false);
        vibeOn = prefs.getBoolean("vibe", true);
        if (!prefs.contains("coins")) prefs.edit().putInt("coins", 500).apply();
        coins = prefs.getInt("coins", 500);
        loadOwned();
        ammo = prefs.getInt("ammo", 0);
        if (!isOwned(ammo)) ammo = 0;
        game = new GameWorld(this);
        demo = new GameWorld(new GameWorld.Fx() {
            @Override public void sound(int id, float vol, float pv) {}
            @Override public void vibrate(int ms) {}
        });
        demoLevel = 32 + (int) (Math.random() * 3);
        demo.load(Defs.LEVELS[demoLevel]);
        setFocusable(true);
    }

    // ================================================================ persistence

    private void loadOwned() {
        owned.clear();
        String s = prefs.getString("owned", "");
        for (int i = 0; i < Defs.NUM_AMMO; i++) {
            if (Defs.AMMO_PRICE[i] == 0 || s.contains("," + i + ",")) owned.add(i);
        }
    }

    private boolean isOwned(int t) {
        return owned.contains(t);
    }

    private void buy(int t) {
        int price = Defs.AMMO_PRICE[t];
        if (coins < price || isOwned(t)) return;
        coins -= price;
        String s = prefs.getString("owned", ",");
        if (!s.startsWith(",")) s = "," + s;
        s = s + t + ",";
        prefs.edit().putString("owned", s).putInt("coins", coins).apply();
        loadOwned();
        ammo = t;
        prefs.edit().putInt("ammo", ammo).apply();
        sfx.play(Defs.S_COIN, 1f, 0f);
        sfx.play(Defs.S_WIN, 0.7f, 0f);
        vibrate(40);
        showToast(Defs.AMMO_NAME[t].toUpperCase(Locale.US) + " UNLOCKED!");
    }

    private int stars(int lvl) { return prefs.getInt("stars" + lvl, 0); }

    private int worldStars(int w) {
        int s = 0;
        for (int i = 0; i < Defs.LEVELS_PER_WORLD; i++) s += stars(w * Defs.LEVELS_PER_WORLD + i);
        return s;
    }

    private int totalStars() {
        int s = 0;
        for (int i = 0; i < Defs.LEVELS.length; i++) s += stars(i);
        return s;
    }

    // ================================================================ lifecycle

    void onPauseGame() {
        running = false;
        if (screen == SC_GAME && !showResult) paused = true;
    }

    void onResumeGame() {
        running = true;
        lastNs = 0;
        postInvalidateOnAnimation();
    }

    void release() {
        sfx.release();
    }

    boolean onBack() {
        click();
        switch (screen) {
            case SC_GAME:
                if (showResult) go(SC_LEVELS);
                else paused = !paused;
                return true;
            case SC_LEVELS: go(SC_WORLDS); return true;
            case SC_WORLDS: go(SC_MENU); return true;
            case SC_ARMORY: go(armoryReturn); return true;
        }
        return false;
    }

    @Override
    protected void onSizeChanged(int w, int h, int ow, int oh) {
        W = w;
        H = h;
        s0 = Math.min(W / 56f, H / 27.5f);
        k = Math.min(W / 1600f, H / 720f);
        ox = (W - 1600 * k) / 2f;
        oy = (H - 720 * k) / 2f;
        L = -ox / k;
        R = 1600 + ox / k;
        T = -oy / k;
        Bm = 720 + oy / k;
    }

    // ================================================================ Fx

    @Override
    public void sound(int id, float vol, float pitchVar) {
        sfx.play(id, vol, pitchVar);
    }

    @Override
    public void vibrate(int ms) {
        if (vibrator == null || !vibeOn) return;
        try {
            if (Build.VERSION.SDK_INT >= 26) vibrator.vibrate(VibrationEffect.createOneShot(ms, VibrationEffect.DEFAULT_AMPLITUDE));
            else vibrator.vibrate(ms);
        } catch (Exception ignored) {
        }
    }

    private void click() {
        sfx.play(Defs.S_CLICK, 0.6f, 0.05f);
    }

    private void showToast(String s) {
        toast = s;
        toastT = 2.2f;
    }

    // ================================================================ flow

    private void go(int s) {
        screen = s;
        fade = 1f;
        paused = false;
        showResult = false;
        aiming = false;
        gridScroll = 0;
    }

    private void startLevel(int idx) {
        level = idx;
        world = Defs.worldOf(idx);
        game.load(Defs.LEVELS[idx]);
        shotsLeft = sandbox ? 9999 : Defs.LEVELS[idx].shots;
        shotsFired = 0;
        state = ST_AIM;
        stateTime = 0;
        settleTime = 0;
        completeTime = 0;
        camX = 19f;
        camZ = 1f;
        int ai = Math.max(0, owned.indexOf(ammo));
        barScroll = ai * (SLOT + SLOT_GAP) + SLOT / 2 + 18 - (R - L) * 0.28f;
        go(SC_GAME);
    }

    private void finishLevel() {
        if (showResult || sandbox) return;
        float d = game.destruction();
        resultDestr = d;
        resultStars = d >= STAR_TH[2] ? 3 : (d >= STAR_TH[1] ? 2 : (d >= STAR_TH[0] ? 1 : 0));
        resultCombo = game.comboBonus;
        resultScore = game.score + (int) (d * 5000) + (resultStars > 0 ? shotsLeft * 1500 : 0);
        coinsEarned = (int) (d * 100) + resultStars * 40 + game.coins + game.maxCombo * 2;
        coins += coinsEarned;
        int best = prefs.getInt("best" + level, 0);
        int st = stars(level);
        newBest = resultScore > best;
        SharedPreferences.Editor e = prefs.edit();
        if (newBest) e.putInt("best" + level, resultScore);
        if (resultStars > st) e.putInt("stars" + level, resultStars);
        e.putInt("coins", coins);
        e.apply();
        showResult = true;
        resultT = 0;
        starsPlayed = 0;
        aiming = false;
        sfx.play(resultStars > 0 ? Defs.S_WIN : Defs.S_THUD, 0.8f, 0f);
    }

    // ================================================================ loop

    @Override
    protected void onDraw(Canvas c) {
        long now = System.nanoTime();
        float dt = lastNs == 0 ? 1 / 60f : Math.min(0.05f, (now - lastNs) / 1e9f);
        lastNs = now;
        time += dt;
        dtLast = dt;
        if (W > 0) {
            update(dt);
            render(c);
        }
        if (running) postInvalidateOnAnimation();
    }

    private void update(float dt) {
        fade = Math.max(0, fade - dt * 3.5f);
        if (ui.pressedT > 0) ui.pressedT -= dt;
        if (toastT > 0) toastT -= dt;
        if (screen != SC_GAME) {
            updateDemo(dt);
            camX = 19f;
            camZ = 1f;
            return;
        }
        if (paused) return;
        game.update(dt);
        updateCamera(dt);
        if (showResult) {
            resultT += dt;
            while (starsPlayed < resultStars && resultT > 0.55f + starsPlayed * 0.4f) {
                starsPlayed++;
                sfx.play(Defs.S_STAR, 0.8f, 0f);
                sfx.play(Defs.S_THUD, 0.4f, 0f);
                vibrate(20);
            }
            return;
        }
        stateTime += dt;
        if (state == ST_FLY && stateTime > 1.1f) {
            if (shotsLeft > 0) state = ST_AIM;
            else {
                state = ST_WAIT;
                stateTime = 0;
                settleTime = 0;
            }
        } else if (state == ST_WAIT) {
            if (game.settled()) settleTime += dt;
            else settleTime = 0;
            if (settleTime > 1.0f || stateTime > 8f) finishLevel();
        }
        if (!sandbox && shotsFired > 0 && game.destruction() >= 0.97f) {
            completeTime += dt;
            if (completeTime > 1.8f) finishLevel();
        }
    }

    private void updateCamera(float dt) {
        float tx = 19f, tz = 1f;
        GameWorld.Shot a = game.activeShot();
        if (game.vortexT > 0) {
            tx = game.vortexX;
            tz = 1.1f;
        } else if (a != null && !aiming && (state != ST_AIM || stateTime < 2.5f)) {
            Vec2 pp = a.body.getPosition();
            tx = pp.x;
            tz = 1.14f;
        }
        tx = Math.max(19f, Math.min(29f, tx));
        float kk = Math.min(1f, dt * 2.2f);
        camX += (tx - camX) * kk;
        camZ += (tz - camZ) * kk;
    }

    private void updateDemo(float dt) {
        demo.update(dt);
        demoTimer += dt;
        if (demoShots < 4 && demoTimer > 2.4f) {
            demoTimer = 0;
            demoShots++;
            float minX = 99, maxX = 0, maxY = 0;
            for (Defs.Spec s : Defs.LEVELS[demoLevel].specs) {
                minX = Math.min(minX, s.x);
                maxX = Math.max(maxX, s.x);
                maxY = Math.max(maxY, s.y);
            }
            float tx = minX + (float) Math.random() * (maxX - minX) * 0.5f;
            float ty = 0.5f + (float) Math.random() * maxY;
            float th = (float) Math.toRadians(18 + Math.random() * 25);
            float dx = tx - GameWorld.POUCH_X, dy = ty - GameWorld.POUCH_Y;
            float den = (float) (2 * Math.cos(th) * Math.cos(th) * (dx * Math.tan(th) - dy));
            float v = den > 0 ? (float) Math.sqrt(-GameWorld.GRAVITY * dx * dx / den) : MAX_SPEED;
            v = Math.min(v, MAX_SPEED);
            int type = (int) (Math.random() * Defs.NUM_AMMO);
            demo.launch(type, GameWorld.POUCH_X, GameWorld.POUCH_Y, (float) Math.cos(th) * v, (float) Math.sin(th) * v);
            if (Defs.tappable(type)) demoTrigger = 0.55f;
        } else if (demoShots >= 4 && demoTimer > 4f) {
            demoLevel = (demoLevel + 5) % Defs.LEVELS.length;
            demo.load(Defs.LEVELS[demoLevel]);
            demoShots = 0;
            demoTimer = 0;
        }
        if (demoTrigger > 0) {
            demoTrigger -= dt;
            if (demoTrigger <= 0) demo.trigger();
        }
    }

    private float demoTrigger;

    // ================================================================ world rendering

    private float sx(float wx) { return (wx - viewL) * sc; }

    private float sy(float wy) { return H - (wy - viewB) * sc; }

    private void setupCamera() {
        sc = s0 * camZ;
        float viewW = W / sc;
        viewL = camX - viewW / 2f;
    }

    private void drawWorld(Canvas c, GameWorld g, int theme, boolean loaded, int loadedAmmo, float px, float py) {
        setupCamera();
        float horizon = H - (Art.DY - viewB) * s0;
        art.drawBackground(c, W, H, theme, horizon, (camX - 19f) * s0, time);

        float shx = 0, shy = 0;
        if (g.shake > 0) {
            shx = (float) (Math.random() - 0.5) * g.shake * 0.6f * sc;
            shy = (float) (Math.random() - 0.5) * g.shake * 0.6f * sc;
        }
        c.save();
        c.translate(-viewL * sc + shx, H + viewB * sc + shy);
        c.scale(sc, -sc);
        art.drawGround(c, viewL - 2, viewL + W / sc + 2, viewB - 1, theme);
        // contact shadows on the ground band
        p.setColor(0x26000000);
        for (GameWorld.Block b : g.blocks) {
            Vec2 bp = b.body.getPosition();
            if (bp.y < 2.5f) {
                rf.set(bp.x - b.w * 0.5f + 0.1f, 0.02f, bp.x + b.w * 0.5f + Art.DX, Art.DY);
                c.drawRect(rf, p);
            }
        }
        art.drawSlingBack(c, px, py);
        if (loaded) {
            c.save();
            c.translate(px, py);
            art.drawAmmo(c, loadedAmmo);
            c.restore();
        }
        art.drawSlingFront(c, px, py);
        // 2.5D: all depth faces first, then front faces
        for (int i = 0, n = g.blocks.size(); i < n; i++) art.drawBlockDepth(c, g.blocks.get(i));
        for (int i = 0, n = g.shots.size(); i < n; i++) {
            GameWorld.Shot s = g.shots.get(i);
            if (!s.gone) art.drawShotDepth(c, s);
        }
        for (int i = 0, n = g.blocks.size(); i < n; i++) art.drawBlock(c, g.blocks.get(i));
        for (int i = 0, n = g.shots.size(); i < n; i++) {
            GameWorld.Shot s = g.shots.get(i);
            if (s.gone) continue;
            Vec2 sp = s.body.getPosition();
            c.save();
            c.translate(sp.x, sp.y);
            c.rotate(s.body.getAngle() * 57.29578f);
            art.drawAmmo(c, s.type);
            c.restore();
        }
        if (g.vortexT > 0) art.drawVortex(c, g.vortexX, g.vortexY, g.vortexT, time);
        art.drawParticles(c, g.particles);
        c.restore();
        art.drawAmbient(c, W, H, theme, dtLast, time);
    }

    private float pouchX() { return GameWorld.POUCH_X + (aiming ? pullX : 0); }

    private float pouchY() { return GameWorld.POUCH_Y + (aiming ? pullY : 0); }

    // ================================================================ render

    private void render(Canvas c) {
        ui.hits.clear();
        if (screen == SC_GAME) {
            Defs.LevelDef def = Defs.LEVELS[level];
            boolean loaded = state == ST_AIM && !showResult;
            drawWorld(c, game, def.theme, loaded, ammo, pouchX(), pouchY());
            if (aiming && loaded) drawTrajectory(c);
            drawWorldTexts(c, game);
        } else if (screen != SC_ARMORY) {
            drawWorld(c, demo, Defs.LEVELS[demoLevel].theme, false, 0, GameWorld.POUCH_X, GameWorld.POUCH_Y);
        }
        c.save();
        c.translate(ox, oy);
        c.scale(k, k);
        switch (screen) {
            case SC_MENU: drawMenu(c); break;
            case SC_WORLDS: drawWorlds(c); break;
            case SC_LEVELS: drawLevels(c); break;
            case SC_ARMORY: drawArmory(c); break;
            case SC_GAME:
                if (!showResult) drawHud(c);
                if (paused) drawPause(c);
                if (showResult) drawResult(c);
                break;
        }
        if (toastT > 0 && toast != null) {
            float a = Math.min(1f, toastT * 3f);
            float w = ui.width(toast, 30) + 60;
            rf.set(800 - w / 2, Bm - 170, 800 + w / 2, Bm - 120);
            p.setColor(Defs.withAlpha(0xFF22123A, (int) (230 * a)));
            c.drawRoundRect(rf, 25, 25, p);
            ui.textC(c, toast, 800, rf.centerY(), 30, Defs.withAlpha(0xFFFFD23F, (int) (255 * a)), 0);
        }
        c.restore();
        if (fade > 0) {
            p.setColor(Defs.withAlpha(0xFF0B0820, (int) (fade * 255)));
            c.drawRect(0, 0, W, H, p);
        }
    }

    private void drawWorldTexts(Canvas c, GameWorld g) {
        for (GameWorld.FloatText t : g.texts) {
            float a = Math.min(1f, t.life * 2.5f);
            float pop = 1f + Math.max(0, (t.life - 0.85f)) * 2f;
            float size = 42 * k * pop * t.size;
            ui.tp.setTextAlign(Paint.Align.CENTER);
            ui.tp.setTextSize(size);
            float x = sx(t.x), y = sy(t.y);
            ui.tp.setStyle(Paint.Style.STROKE);
            ui.tp.setStrokeWidth(size * 0.2f);
            ui.tp.setColor(Defs.withAlpha(Ui.INK, (int) (255 * a)));
            c.drawText(t.text, x, y, ui.tp);
            ui.tp.setStyle(Paint.Style.FILL);
            ui.tp.setColor(Defs.withAlpha(t.color, (int) (255 * a)));
            c.drawText(t.text, x, y, ui.tp);
        }
        for (GameWorld.Shot s : g.shots) {
            if (s.gone) continue;
            Vec2 sp = s.body.getPosition();
            if (sy(sp.y) < 0) {
                float x = sx(sp.x), u = H / 100f;
                path.reset();
                path.moveTo(x, 1.2f * u);
                path.lineTo(x - 1.8f * u, 4.2f * u);
                path.lineTo(x + 1.8f * u, 4.2f * u);
                path.close();
                p.setColor(0xCCFFFFFF);
                c.drawPath(path, p);
            }
        }
    }

    private void drawTrajectory(Canvas c) {
        float len = (float) Math.hypot(pullX, pullY);
        if (len < 0.35f) return;
        float vx = -pullX * MAX_SPEED / MAX_PULL, vy = -pullY * MAX_SPEED / MAX_PULL;
        float x = pouchX(), y = pouchY();
        for (int i = 1; i <= 24; i++) {
            float t = i * 0.075f;
            float wx = x + vx * t, wy = y + vy * t + 0.5f * GameWorld.GRAVITY * t * t;
            if (wy < 0) break;
            float a = 1f - i / 26f;
            p.setColor(Defs.withAlpha(0xFFFFFFFF, (int) (235 * a)));
            c.drawCircle(sx(wx), sy(wy), (11f - i * 0.3f) * k, p);
        }
        int pct = Math.round(Math.min(1f, len / MAX_PULL) * 100);
        ui.tp.setTextAlign(Paint.Align.CENTER);
        float size = 34 * k;
        ui.tp.setTextSize(size);
        float bx = sx(pouchX()), by = sy(pouchY()) - 70 * k;
        ui.tp.setStyle(Paint.Style.STROKE);
        ui.tp.setStrokeWidth(size * 0.22f);
        ui.tp.setColor(Ui.INK);
        c.drawText(pct + "%", bx, by, ui.tp);
        ui.tp.setStyle(Paint.Style.FILL);
        ui.tp.setColor(0xFFFFFFFF);
        c.drawText(pct + "%", bx, by, ui.tp);
    }

    // ================================================================ screens

    private void drawMenu(Canvas c) {
        p.setShader(new LinearGradient(0, T, 0, Bm, 0x9A0B0A2A, 0x0D0B0A2A, Shader.TileMode.CLAMP));
        c.drawRect(L, T, R, Bm, p);
        p.setShader(null);
        float bob = (float) Math.sin(time * 2.2f) * 6;
        c.save();
        c.rotate(3 + (float) Math.sin(time * 1.3f) * 1.2f, 800, 140);
        ui.title(c, "SLING", 800, 92 + bob, 150, 0xFFFFF39A, 0xFFFFB31F, 0xFF7A3E00);
        ui.title(c, "SMASH!", 800, 230 + bob, 170, 0xFFFF9A6A, 0xFFE8341C, 0xFF7A1A0A);
        c.restore();
        ui.textC(c, "LAUNCH ANYTHING. DESTROY EVERYTHING.", 800, 372, 30, 0xFFFFFFFF, 5);
        float pulse = 1f + (float) Math.sin(time * 4f) * 0.035f;
        c.save();
        c.scale(pulse, pulse, 800, 478);
        ui.button(c, B_PLAY, 800, 478, "PLAY", 72, Ui.GREEN, 300);
        c.restore();
        float wa = ui.width("ARMORY", 38) + 38 * 1.9f;
        float wb = ui.width("SANDBOX", 38) + 38 * 1.9f;
        ui.button(c, B_ARMORY, 800 - 16 - wa / 2, 600, "ARMORY", 38, Ui.ORANGE, 0);
        ui.button(c, B_SANDBOX, 816 + wb / 2, 600, "SANDBOX", 38, Ui.PURPLE, 0);
        float cw = ui.pill(c, R - 32, T + 28, 0, String.format(Locale.US, "%,d", coins), 0xFFFFE066, true);
        ui.pill(c, R - 32 - cw - 20, T + 28, 1, totalStars() + " / " + Defs.LEVELS.length * 3, 0xFFFFFFFF, true);
        ui.iconButton(c, B_SOUND, L + 40, Bm - 120, 80, sfx.muted ? Ui.G_MUTE : Ui.G_SOUND, Ui.BLUE);
        ui.iconButton(c, B_VIBE, L + 140, Bm - 120, 80, vibeOn ? Ui.G_VIBE : Ui.G_NOVIBE, Ui.BLUE);
        ui.text(c, "40 BUILDINGS  •  20 CRAZY PROJECTILES  •  5 WORLDS", R - 32, Bm - 36, 22, 0xFFFFFFFF, 4, Paint.Align.RIGHT);
    }

    private void header(Canvas c, String title, String sub) {
        ui.iconButton(c, B_BACK, L + 40, T + 28, 88, Ui.G_BACK, Ui.ORANGE);
        ui.title(c, title, 800, T + 62, 64, 0xFFFFF39A, 0xFFFFB31F, 0xFF7A3E00);
        if (sub != null) ui.textC(c, sub, 800, T + 118, 26, 0xFFFFFFFF, 4);
        ui.pill(c, R - 32, T + 34, 0, String.format(Locale.US, "%,d", coins), 0xFFFFE066, true);
    }

    private void drawWorlds(Canvas c) {
        p.setShader(new LinearGradient(0, T, 0, Bm, 0xD10B0A2A, 0x8C0B0A2A, Shader.TileMode.CLAMP));
        c.drawRect(L, T, R, Bm, p);
        p.setShader(null);
        header(c, sandbox ? "SANDBOX" : "CHOOSE A WORLD", sandbox ? "UNLIMITED SHOTS  •  PICK ANY BUILDING" : null);
        int[] showcase = {2, 8, 16, 31, 39};
        for (int i = 0; i < 5; i++) {
            float x = 64 + i * 300, y = 140;
            float enter = Math.min(1f, Math.max(0f, (1f - fade) * 1.6f - i * 0.08f));
            float s = (ui.pressed(B_WORLD + i) ? 0.95f : 1f) * (0.88f + 0.12f * enter);
            c.save();
            c.scale(s, s, x + 138, y + 260);
            int theme = Defs.WORLD_THEME[i];
            int[] t = Art.THEMES[theme];
            rf.set(x, y + 14, x + 276, y + 534);
            p.setColor(0x73000000);
            c.drawRoundRect(rf, 32, 32, p);
            rf.set(x - 6, y - 6, x + 282, y + 526);
            p.setColor(i == world && !sandbox ? 0xFFFFD23F : Ui.INK);
            c.drawRoundRect(rf, 38, 38, p);
            c.save();
            path.reset();
            rf.set(x, y, x + 276, y + 520);
            path.addRoundRect(rf, 32, 32, Path.Direction.CW);
            c.clipPath(path);
            p.setShader(new LinearGradient(0, y, 0, y + 380, t[0], t[1], Shader.TileMode.CLAMP));
            c.drawRect(rf, p);
            p.setShader(null);
            // hills + ground
            path.reset();
            path.moveTo(x, y + 382);
            for (int j = 0; j <= 20; j++) {
                float u = j / 20f;
                float hy = y + 382 - 20 - (float) (Math.sin(u * 3 + i) * 0.5 + 0.5) * 90;
                path.lineTo(x + u * 276, hy);
            }
            path.lineTo(x + 276, y + 382);
            path.close();
            p.setColor(t[3]);
            c.drawPath(path, p);
            p.setColor(Defs.shade(t[5], 0.9f));
            c.drawRect(x, y + 370, x + 276, y + 392, p);
            p.setColor(t[6]);
            c.drawRect(x, y + 390, x + 276, y + 520, p);
            drawBuildingPreview(c, Defs.LEVELS[showcase[i]], x + 18, y + 120, 240, 250, y + 380);
            c.restore();
            p.setColor(Ui.INK);
            c.drawCircle(x + 45, y + 45, 27, p);
            ui.textC(c, String.valueOf(i + 1), x + 45, y + 45, 34, 0xFFFFFFFF, 0);
            String nm = Defs.WORLD_NAME[i].toUpperCase(Locale.US);
            ui.textC(c, nm, x + 138, y + 420, nm.length() > 12 ? 30 : 34, 0xFFFFFFFF, 6);
            int ws = worldStars(i);
            rf.set(x + 28, y + 452, x + 248, y + 474);
            p.setColor(0xCC120B2A);
            c.drawRoundRect(rf, 11, 11, p);
            if (ws > 0) {
                rf.set(x + 28, y + 452, x + 28 + Math.max(22, 220f * ws / 24f), y + 474);
                p.setShader(new LinearGradient(x + 28, 0, x + 248, 0, 0xFFFFE780, 0xFFFFB31F, Shader.TileMode.CLAMP));
                c.drawRoundRect(rf, 11, 11, p);
                p.setShader(null);
            }
            ui.star(c, x + 110, y + 495, 17, true, 1, 0);
            ui.text(c, ws + "/24", x + 132, y + 495, 28, 0xFFFFFFFF, 4, Paint.Align.LEFT);
            c.restore();
            ui.hit(B_WORLD + i, x, y, x + 276, y + 520);
        }
    }

    private void drawBuildingPreview(Canvas c, Defs.LevelDef d, float x, float y, float w, float h, float groundY) {
        float minX = 1e9f, maxX = -1e9f, maxY = 0;
        for (Defs.Spec s : d.specs) {
            minX = Math.min(minX, s.x - s.w / 2);
            maxX = Math.max(maxX, s.x + s.w / 2);
            maxY = Math.max(maxY, s.verts != null ? s.y + s.h * 2f / 3f : s.y + s.h / 2);
        }
        float scale = Math.min(w / (maxX - minX + Art.DX), (groundY - y) / (maxY + Art.DY));
        c.save();
        c.translate(x + w / 2 - (minX + maxX + Art.DX) / 2 * scale, groundY);
        c.scale(scale, -scale);
        art.drawSpecPreview(c, d.specs);
        c.restore();
    }

    private void drawLevels(Canvas c) {
        p.setShader(new LinearGradient(0, T, 0, Bm, 0xD90B0A2A, 0x990B0A2A, Shader.TileMode.CLAMP));
        c.drawRect(L, T, R, Bm, p);
        p.setShader(null);
        header(c, Defs.WORLD_NAME[world].toUpperCase(Locale.US),
                (sandbox ? "SANDBOX  •  " : "") + "WORLD " + (world + 1) + "  •  " + worldStars(world) + " / 24");
        for (int i = 0; i < Defs.LEVELS_PER_WORLD; i++) {
            int lvl = world * Defs.LEVELS_PER_WORLD + i;
            Defs.LevelDef d = Defs.LEVELS[lvl];
            int col = i % 4, row = i / 4;
            float x = 80 + col * 372, y = 160 + row * 270;
            float enter = Math.min(1f, Math.max(0f, (1f - fade) * 1.6f - i * 0.05f));
            float s = (ui.pressed(B_LEVEL + i) ? 0.95f : 1f) * (0.86f + 0.14f * enter);
            c.save();
            c.scale(s, s, x + 172, y + 122);
            rf.set(x, y + 10, x + 344, y + 254);
            p.setColor(0x73000000);
            c.drawRoundRect(rf, 26, 26, p);
            rf.set(x - 5, y - 5, x + 349, y + 249);
            p.setColor(Ui.INK);
            c.drawRoundRect(rf, 30, 30, p);
            rf.set(x, y, x + 344, y + 244);
            p.setColor(0xFFFFF6E3);
            c.drawRoundRect(rf, 26, 26, p);
            c.save();
            path.reset();
            rf.set(x + 8, y + 8, x + 336, y + 176);
            path.addRoundRect(rf, 20, 20, Path.Direction.CW);
            c.clipPath(path);
            int[] t = Art.THEMES[d.theme];
            p.setShader(new LinearGradient(0, y + 8, 0, y + 150, t[0], t[1], Shader.TileMode.CLAMP));
            c.drawRect(rf, p);
            p.setShader(null);
            p.setColor(Defs.shade(t[5], 1.05f));
            c.drawRect(x + 8, y + 140, x + 336, y + 150, p);
            p.setColor(t[6]);
            c.drawRect(x + 8, y + 150, x + 336, y + 176, p);
            drawBuildingPreview(c, d, x + 40, y + 22, 264, 120, y + 146);
            c.restore();
            p.setColor(Ui.INK);
            c.drawCircle(x + 41, y + 41, 23, p);
            ui.textC(c, String.valueOf(lvl + 1), x + 41, y + 41, 26, 0xFFFFFFFF, 0);
            int st = stars(lvl);
            String nm = d.name.toUpperCase(Locale.US);
            float ns = nm.length() > 14 ? 21 : 25;
            ui.text(c, nm, x + 22, y + 210, ns, Ui.INK, 0, Paint.Align.LEFT);
            for (int j = 0; j < 3; j++) ui.star(c, x + 344 - 26 - (2 - j) * 30, y + 210, 13, j < st, 1, 0);
            if (st == 0 && !sandbox) {
                rf.set(x + 344 - 18 - 88, y + 22, x + 344 - 18, y + 56);
                p.setColor(Ui.INK);
                c.drawRoundRect(rf.left - 4, rf.top - 4, rf.right + 4, rf.bottom + 4, 21, 21, p);
                p.setColor(0xFFFF4B2B);
                c.drawRoundRect(rf, 17, 17, p);
                ui.textC(c, "NEW!", rf.centerX(), rf.centerY(), 22, 0xFFFFFFFF, 0);
            }
            c.restore();
            ui.hit(B_LEVEL + i, x, y, x + 344, y + 244);
        }
    }

    // ---------------------------------------------------------------- HUD

    private float barX0, barY, barW, barVisW;
    private static final float SLOT = 80, SLOT_GAP = 14;

    private void drawHud(Canvas c) {
        Defs.LevelDef def = Defs.LEVELS[level];
        ui.iconButton(c, B_PAUSE, L + 32, T + 24, 84, Ui.G_PAUSE, Ui.BLUE);
        ui.iconButton(c, B_RESTART, L + 132, T + 24, 84, Ui.G_RESTART, Ui.ORANGE);

        float d = game.destruction();
        ui.textC(c, (sandbox ? "SANDBOX  •  " : (level + 1) + ". ") + def.name.toUpperCase(Locale.US), 800, T + 30, 26, 0xFFFFFFFF, 5);
        ui.meter(c, 520, T + 62, 560, d, STAR_TH);
        ui.textC(c, Math.round(d * 100) + "% DESTROYED", 800, T + 128, 22, 0xFFFFFFFF, 4);

        ui.text(c, String.format(Locale.US, "%,d", game.score), R - 32, T + 50, 54, 0xFFFFE066, 7, Paint.Align.RIGHT);
        if (game.coins > 0) ui.pill(c, R - 32, T + 92, 0, "+" + game.coins, 0xFFFFE066, true);
        if (sandbox) {
            ui.text(c, "FREE PLAY", R - 32, T + 182, 26, 0xFFFFFFFF, 4, Paint.Align.RIGHT);
        } else {
            float sx = R - 32 - 13;
            for (int i = def.shots - 1; i >= 0; i--) {
                boolean has = i < shotsLeft;
                p.setColor(Ui.INK);
                c.drawCircle(sx, T + 182, 15, p);
                p.setColor(has ? 0xFFFF7A3C : 0x4DFFFFFF);
                c.drawCircle(sx, T + 182, 11, p);
                sx -= 34;
            }
            ui.text(c, "SHOTS", sx + 6, T + 182, 20, 0xFFFFFFFF, 4, Paint.Align.RIGHT);
        }

        // combo + banner
        if (game.combo >= 3 && game.time - game.lastBreak < GameWorld.COMBO_WINDOW + 0.6f) {
            float pop = 1f + game.comboFlash * 0.9f;
            c.save();
            c.rotate(-6, 800, 250);
            c.scale(pop, pop, 800, 250);
            ui.title(c, "COMBO x" + game.combo + "!", 800, 250, 64, 0xFFFFF39A, 0xFFFF9A1F, 0xFF7A3E00);
            c.restore();
        }
        if (game.bannerT > 0 && game.banner != null) {
            float t = 1.6f - game.bannerT;
            float s = t < 0.15f ? t / 0.15f * 1.25f : (t < 0.3f ? 1.25f - (t - 0.15f) / 0.15f * 0.25f : 1f);
            float a = Math.min(1f, game.bannerT * 3f);
            c.save();
            c.scale(s, s, 800, 330);
            ui.textC(c, game.banner, 800, 330, 48, Defs.withAlpha(0xFFFFFFFF, (int) (255 * a)), 7);
            c.restore();
        }
        if (game.canTrigger()) {
            String h = Defs.TAP_HINT[game.lastShot.type];
            if (h != null) {
                float pulse = 1f + (float) Math.sin(time * 10) * 0.06f;
                float w = ui.width(h, 32) + 50;
                c.save();
                c.rotate(3, 800, 420);
                c.scale(pulse, pulse, 800, 420);
                rf.set(800 - w / 2 - 4, 394, 800 + w / 2 + 4, 450);
                p.setColor(Ui.INK);
                c.drawRoundRect(rf, 28, 28, p);
                rf.set(800 - w / 2, 398, 800 + w / 2, 446);
                p.setColor(0xFF8A4DFF);
                c.drawRoundRect(rf, 24, 24, p);
                ui.textC(c, h, 800, 421, 32, 0xFFFFFFFF, 4);
                c.restore();
            }
        }

        // ammo bar
        int n = owned.size();
        barW = n * SLOT + (n - 1) * SLOT_GAP + 36;
        barVisW = Math.min(barW, (R - L) * 0.56f);
        float maxScroll = Math.max(0, barW - barVisW);
        barScroll = Math.max(0, Math.min(maxScroll, barScroll));
        barX0 = 800 - barVisW / 2;
        barY = Bm - 14 - (SLOT + 20);
        rf.set(barX0, barY, barX0 + barVisW, barY + SLOT + 20);
        p.setColor(0x9E120C26);
        c.drawRoundRect(rf, 60, 60, p);
        ui.ps.setColor(0x33FFFFFF);
        ui.ps.setStrokeWidth(3);
        c.drawRoundRect(rf, 60, 60, ui.ps);
        c.save();
        c.clipRect(barX0 + 6, barY - 30, barX0 + barVisW - 6, barY + SLOT + 40);
        float selX = -1;
        for (int i = 0; i < n; i++) {
            int t = owned.get(i);
            float cx = barX0 + 18 + SLOT / 2 + i * (SLOT + SLOT_GAP) - barScroll;
            float cy = barY + 10 + SLOT / 2;
            boolean sel = t == ammo;
            float bob = sel ? (float) Math.sin(time * 5) * 3 : 0;
            ui.ammoSlot(c, cx, cy, SLOT / 2 * (sel ? 1.06f : 1f), sel ? 1 : 0, t, art, bob);
            if (sel) selX = cx;
        }
        c.restore();
        if (maxScroll > 0) {
            if (barScroll > 2) chevron(c, barX0 - 24, barY + 10 + SLOT / 2, -1);
            if (barScroll < maxScroll - 2) chevron(c, barX0 + barVisW + 24, barY + 10 + SLOT / 2, 1);
        }
        ui.hit(-2, barX0, barY - 10, barX0 + barVisW, Bm);
        if (selX >= barX0 - 10 && selX <= barX0 + barVisW + 10) {
            String nm = Defs.AMMO_NAME[ammo].toUpperCase(Locale.US);
            float w = ui.width(nm, 26) + 34;
            float lx = Math.max(L + 20 + w / 2, Math.min(R - 20 - w / 2, selX));
            rf.set(lx - w / 2 - 4, barY - 56, lx + w / 2 + 4, barY - 12);
            p.setColor(Ui.INK);
            c.drawRoundRect(rf, 22, 22, p);
            rf.set(lx - w / 2, barY - 52, lx + w / 2, barY - 16);
            p.setColor(0xFFFFD23F);
            c.drawRoundRect(rf, 18, 18, p);
            ui.textC(c, nm, lx, barY - 34, 26, Ui.INK, 0);
        }

        if (level == 0 && !sandbox && shotsFired == 0 && !aiming && state == ST_AIM) {
            float a = 0.6f + 0.4f * (float) Math.sin(time * 4);
            ui.textC(c, "DRAG BACK ANYWHERE & RELEASE TO FIRE!", 800, 300, 40, Defs.withAlpha(0xFFFFFFFF, (int) (255 * a)), 6);
            ui.textC(c, "PICK YOUR PROJECTILE BELOW", 800, 352, 28, Defs.withAlpha(0xFFFFE066, (int) (255 * a)), 5);
        }
        if (state == ST_WAIT) ui.textC(c, "NO SHOTS LEFT...", 800, 220, 36, 0xEEFFFFFF, 5);
    }

    private void chevron(Canvas c, float x, float y, int dir) {
        ui.ps.setColor(Ui.INK);
        ui.ps.setStrokeWidth(14);
        path.reset();
        path.moveTo(x - 8 * dir, y - 16);
        path.lineTo(x + 8 * dir, y);
        path.lineTo(x - 8 * dir, y + 16);
        c.drawPath(path, ui.ps);
        ui.ps.setColor(0xFFFFFFFF);
        ui.ps.setStrokeWidth(7);
        c.drawPath(path, ui.ps);
    }

    private void drawPause(Canvas c) {
        ui.hits.clear();
        ui.scrim(c, L, T, R, Bm, 175);
        float top = 120;
        ui.panel(c, 800, top, 600, 520, "PAUSED", Ui.BLUE);
        ui.button(c, B_RESUME, 800, top + 130, "RESUME", 46, Ui.GREEN, 330);
        ui.button(c, B_RESTART, 800, top + 240, sandbox ? "RESET" : "RESTART", 40, Ui.ORANGE, 330);
        ui.button(c, B_LEVELS, 800, top + 340, "LEVELS", 40, Ui.BLUE, 330);
        toggle(c, B_SOUND, 590, top + 450, "SOUND", !sfx.muted);
        toggle(c, B_VIBE, 810, top + 450, "VIBRATION", vibeOn);
    }

    private void toggle(Canvas c, int id, float x, float y, String label, boolean on) {
        ui.text(c, label, x, y, 26, 0xFFFFFFFF, 0, Paint.Align.LEFT);
        float tx = x + ui.width(label, 26) + 14;
        rf.set(tx - 4, y - 26, tx + 88, y + 26);
        p.setColor(Ui.INK);
        c.drawRoundRect(rf, 26, 26, p);
        rf.set(tx, y - 22, tx + 84, y + 22);
        p.setColor(on ? 0xFF3BC44B : 0xFF4A3D86);
        c.drawRoundRect(rf, 22, 22, p);
        p.setColor(0xFFFFFFFF);
        c.drawCircle(on ? tx + 61 : tx + 23, y, 17, p);
        ui.hit(id, x - 10, y - 34, tx + 100, y + 34);
    }

    private void drawResult(Canvas c) {
        float appear = Math.min(1f, resultT * 3f);
        float ease = 1f - (1f - appear) * (1f - appear);
        ui.scrim(c, L, T, R, Bm, (int) (150 * ease));
        c.save();
        c.translate(0, (1f - ease) * 400);
        float top = 100, w = 760, h = 560;
        String title = resultStars == 3 ? "DEMOLISHED!" : (resultStars > 0 ? "NICE SMASH!" : "STILL STANDING");
        ui.panel(c, 800, top, w, h, title, resultStars > 0 ? Ui.ORANGE : Ui.GREY);
        for (int i = 0; i < 3; i++) {
            float x = 800 + (i - 1) * 150, y = top + (i == 1 ? 120 : 140);
            float r = i == 1 ? 62 : 52;
            float rot = (1 - i) * 10;
            ui.star(c, x, y, r, false, 1f, rot);
            if (i < starsPlayed) {
                float st = resultT - (0.55f + i * 0.4f);
                float pop = st < 0.18f ? 0.3f + st / 0.18f : (st < 0.3f ? 1.3f - (st - 0.18f) / 0.12f * 0.3f : 1f);
                if (st < 0.5f) ui.glow(c, x, y, r * 2.2f * Math.min(1, st * 4), 0x99FFE780);
                ui.star(c, x, y, r, true, pop, rot);
            }
        }
        ui.textC(c, Math.round(resultDestr * 100) + "% DESTROYED", 800, top + 236, 40, 0xFFFFFFFF, 6);
        rf.set(570, top + 270, 1030, top + 452);
        p.setColor(0x8C120B2A);
        c.drawRoundRect(rf, 24, 24, p);
        float shown = Math.min(1f, resultT / 1.4f);
        String[] a = {"SCORE", "COMBO BONUS", "COINS", "BEST"};
        int best = prefs.getInt("best" + level, 0);
        String[] b = {String.format(Locale.US, "%,d", (int) (resultScore * shown)), "+" + String.format(Locale.US, "%,d", resultCombo),
                "+" + (int) (coinsEarned * shown), newBest ? "NEW BEST!" : String.format(Locale.US, "%,d", best)};
        int[] col = {0xFFFFE066, 0xFF8FE3FF, 0xFFFFD23F, newBest ? 0xFF7CFF8A : 0xFFFFFFFF};
        for (int i = 0; i < 4; i++) {
            float y = top + 298 + i * 46;
            ui.text(c, a[i], 600, y, 28, 0xCCFFFFFF, 0, Paint.Align.LEFT);
            ui.text(c, b[i], 1000, y, 30, col[i], 0, Paint.Align.RIGHT);
        }
        float by = top + 478;
        ui.iconButton(c, B_LEVELS, 800 - 50 - 140, by, 100, Ui.G_GRID, Ui.BLUE);
        ui.iconButton(c, B_RETRY, 800 - 50, by, 100, Ui.G_RESTART, Ui.ORANGE);
        ui.iconButton(c, B_NEXT, 800 - 50 + 140, by, 100, Ui.G_NEXT, Ui.GREEN);
        c.restore();
        if (appear < 1f) ui.hits.clear();
    }

    // ---------------------------------------------------------------- Armory

    private ArrayList<Integer> armoryList() {
        ArrayList<Integer> l = new ArrayList<>();
        for (int i = 0; i < Defs.NUM_AMMO; i++) if (armoryTab == 0 || Defs.AMMO_CAT[i] == armoryTab) l.add(i);
        return l;
    }

    private void drawArmory(Canvas c) {
        p.setShader(new LinearGradient(0, T, 0, Bm, 0xFF2B1F5C, 0xFF140D33, Shader.TileMode.CLAMP));
        c.drawRect(L, T, R, Bm, p);
        p.setShader(null);
        c.save();
        c.rotate(time * 6, R - 380, 400);
        p.setColor(0x0AFFFFFF);
        for (int i = 0; i < 16; i++) {
            double a0 = i * Math.PI / 8, a1 = a0 + 0.2;
            path.reset();
            path.moveTo(R - 380, 400);
            path.lineTo(R - 380 + (float) Math.cos(a0) * 1400, 400 + (float) Math.sin(a0) * 1400);
            path.lineTo(R - 380 + (float) Math.cos(a1) * 1400, 400 + (float) Math.sin(a1) * 1400);
            path.close();
            c.drawPath(path, p);
        }
        c.restore();
        ui.iconButton(c, B_BACK, L + 32, T + 24, 84, Ui.G_BACK, Ui.ORANGE);
        ui.title(c, "ARMORY", L + 140 + ui.width("ARMORY", 64) / 2, T + 62, 64, 0xFFFFF39A, 0xFFFFB31F, 0xFF7A3E00);
        ui.pill(c, R - 32, T + 32, 0, String.format(Locale.US, "%,d", coins), 0xFFFFE066, true);
        String[] tabs = {"ALL", "HEAVY", "EXPLOSIVE", "SPECIAL"};
        float tx = L + 40;
        for (int i = 0; i < 4; i++) {
            float w = ui.width(tabs[i], 24) + 44;
            rf.set(tx - 4, T + 116, tx + w + 4, T + 166);
            p.setColor(Ui.INK);
            c.drawRoundRect(rf, 25, 25, p);
            rf.set(tx, T + 120, tx + w, T + 162);
            p.setColor(i == armoryTab ? 0xFFFFD23F : 0xFF3A2A78);
            c.drawRoundRect(rf, 21, 21, p);
            ui.textC(c, tabs[i], tx + w / 2, T + 141, 24, i == armoryTab ? Ui.INK : 0xFFFFFFFF, 0);
            ui.hit(B_TAB + i, tx, T + 110, tx + w, T + 172);
            tx += w + 14;
        }
        // grid
        ArrayList<Integer> list = armoryList();
        float gx = L + 40, gy = T + 190;
        float panelW = 620, panelX = R - 32 - panelW;
        int cols = Math.max(3, Math.min(5, (int) ((panelX - 20 - gx + 16) / 182)));
        int rows = (list.size() + cols - 1) / cols;
        float viewH = Bm - 16 - gy;
        float maxScroll = Math.max(0, rows * 172 - viewH + 10);
        gridScroll = Math.max(0, Math.min(maxScroll, gridScroll));
        c.save();
        c.clipRect(gx - 10, gy - 6, gx + cols * 182, Bm - 6);
        for (int j = 0; j < list.size(); j++) {
            int t = list.get(j);
            float x = gx + (j % cols) * 182, y = gy + (j / cols) * 172 - gridScroll;
            if (y > Bm || y + 160 < gy - 10) continue;
            boolean own = isOwned(t);
            boolean sel = t == armorySel;
            rf.set(x, y + 8, x + 166, y + 166);
            p.setColor(0x66000000);
            c.drawRoundRect(rf, 22, 22, p);
            rf.set(x - 4, y - 4, x + 170, y + 162);
            p.setColor(sel ? 0xFFFFD23F : Ui.INK);
            c.drawRoundRect(rf, 26, 26, p);
            rf.set(x, y, x + 166, y + 158);
            p.setShader(own ? new LinearGradient(0, y, 0, y + 158, 0xFF4E3D9A, 0xFF33266E, Shader.TileMode.CLAMP)
                    : new LinearGradient(0, y, 0, y + 158, 0xFF2A2050, 0xFF1E1640, Shader.TileMode.CLAMP));
            c.drawRoundRect(rf, 22, 22, p);
            p.setShader(null);
            float br = Ui.ammoRadius(t), kk = 40f / br;
            c.save();
            c.translate(x + 83, y + 58);
            c.scale(kk, -kk);
            if (!own) {
                c.saveLayerAlpha(-br * 1.6f, -br * 1.6f, br * 1.6f, br * 1.6f, 110);
                art.drawAmmo(c, t);
                c.restore();
            } else art.drawAmmo(c, t);
            c.restore();
            String nm = Defs.AMMO_NAME[t].toUpperCase(Locale.US);
            ui.textC(c, nm, x + 83, y + 112, nm.length() > 11 ? 17 : 20, 0xFFFFFFFF, 0);
            if (own) ui.textC(c, t == ammo ? "EQUIPPED" : "OWNED", x + 83, y + 138, 17, t == ammo ? 0xFFFFD23F : 0xFF7CFF8A, 0);
            else {
                String pr = String.format(Locale.US, "%,d", Defs.AMMO_PRICE[t]);
                float pw = ui.width(pr, 20) + 26;
                ui.coin(c, x + 83 - pw / 2 + 9, y + 138, 9);
                ui.text(c, pr, x + 83 - pw / 2 + 24, y + 138, 20, coins >= Defs.AMMO_PRICE[t] ? 0xFFFFE066 : 0xFFFF8A7A, 0, Paint.Align.LEFT);
            }
            ui.hit(B_ITEM + t, x, Math.max(y, gy), x + 166, y + 158);
        }
        c.restore();
        // detail panel
        int t = armorySel;
        float py = T + 150, ph = Math.min(530, Bm - 24 - py);
        rf.set(panelX - 6, py - 6, panelX + panelW + 6, py + ph + 6);
        p.setColor(Ui.INK);
        c.drawRoundRect(rf, 42, 42, p);
        rf.set(panelX, py, panelX + panelW, py + ph);
        p.setShader(new LinearGradient(0, py, 0, py + ph, 0xFF3A2A78, 0xFF231850, Shader.TileMode.CLAMP));
        c.drawRoundRect(rf, 36, 36, p);
        p.setShader(null);
        float cx = panelX + panelW / 2;
        ui.glow(c, cx, py + 120, 140, 0xAAC08CFF);
        float br = Ui.ammoRadius(t), kk = 88f / br;
        c.save();
        c.translate(cx, py + 120 + (float) Math.sin(time * 2) * 6);
        c.rotate((float) Math.sin(time * 1.3f) * 6);
        c.scale(kk, -kk);
        art.drawAmmo(c, t);
        c.restore();
        ui.textC(c, Defs.AMMO_NAME[t].toUpperCase(Locale.US), cx, py + 252, 50, 0xFFFFFFFF, 7);
        float ty = py + 300;
        for (String line : wrap(Defs.AMMO_DESC[t], 22, 520)) {
            ui.textC(c, line, cx, ty, 22, 0xCCFFFFFF, 0);
            ty += 28;
        }
        String[] sn = {"WEIGHT", "POWER", "CHAOS"};
        int[] sc2 = {0xFF5BC8FF, 0xFFFF7A3C, 0xFFB07CFF};
        float sy0 = py + ph - 170;
        for (int i = 0; i < 3; i++) {
            float y = sy0 + i * 34;
            ui.text(c, sn[i], panelX + 60, y, 22, 0xFFFFFFFF, 0, Paint.Align.LEFT);
            rf.set(panelX + 200, y - 9, panelX + 530, y + 9);
            p.setColor(0xCC120B2A);
            c.drawRoundRect(rf, 9, 9, p);
            rf.set(panelX + 200, y - 9, panelX + 200 + 330 * Defs.AMMO_STATS[t][i], y + 9);
            p.setColor(sc2[i]);
            c.drawRoundRect(rf, 9, 9, p);
        }
        float bcy = py + ph - 52;
        if (isOwned(t)) {
            ui.button(c, B_BUY, cx, bcy, t == ammo ? "EQUIPPED" : "EQUIP", 38, t == ammo ? Ui.GREY : Ui.GREEN, 300);
        } else {
            boolean can = coins >= Defs.AMMO_PRICE[t];
            ui.button(c, B_BUY, cx, bcy, (can ? "BUY  " : "NEED  ") + String.format(Locale.US, "%,d", Defs.AMMO_PRICE[t]), 38,
                    can ? Ui.YELLOW : Ui.GREY, 300);
        }
    }

    private ArrayList<String> wrap(String s, float size, float maxW) {
        ArrayList<String> out = new ArrayList<>();
        String cur = "";
        for (String w : s.split(" ")) {
            String tryS = cur.isEmpty() ? w : cur + " " + w;
            if (ui.width(tryS, size) > maxW && !cur.isEmpty()) {
                out.add(cur);
                cur = w;
            } else cur = tryS;
        }
        if (!cur.isEmpty()) out.add(cur);
        return out;
    }

    // ================================================================ input

    @Override
    public boolean onTouchEvent(MotionEvent e) {
        int action = e.getActionMasked();
        int idx = e.getActionIndex();
        float x = e.getX(idx), y = e.getY(idx);
        float dx = (x - ox) / k, dy = (y - oy) / k;
        switch (action) {
            case MotionEvent.ACTION_DOWN:
            case MotionEvent.ACTION_POINTER_DOWN: {
                if (action == MotionEvent.ACTION_POINTER_DOWN && (aiming || barDrag || gridDrag)) return true;
                int id = ui.find(dx, dy);
                if (id == -2 && screen == SC_GAME) {
                    barDrag = true;
                    barMoved = false;
                    dragX0 = dx;
                    scroll0 = barScroll;
                    return true;
                }
                if (screen == SC_ARMORY && id >= B_ITEM) {
                    gridDrag = true;
                    gridMoved = false;
                    dragY0 = dy;
                    scroll0 = gridScroll;
                    pendingItem = id;
                    return true;
                }
                if (id > 0) {
                    onButton(id);
                    return true;
                }
                if (screen == SC_ARMORY && dx < R - 680 && dy > T + 180) {
                    gridDrag = true;
                    gridMoved = false;
                    dragY0 = dy;
                    scroll0 = gridScroll;
                    pendingItem = -1;
                    return true;
                }
                if (screen == SC_GAME && !paused && !showResult) {
                    if (game.canTrigger()) {
                        if (game.trigger()) vibrate(30);
                        return true;
                    }
                    if (state == ST_AIM && !aiming) {
                        aiming = true;
                        aimId = e.getPointerId(idx);
                        tx0 = x;
                        ty0 = y;
                        pullX = pullY = 0;
                        sfx.play(Defs.S_STRETCH, 0.6f, 0.05f);
                    }
                }
                return true;
            }
            case MotionEvent.ACTION_MOVE: {
                if (aiming) {
                    int pi = e.findPointerIndex(aimId);
                    if (pi >= 0) updatePull(e.getX(pi), e.getY(pi));
                } else if (barDrag) {
                    float ddx = (e.getX(0) - ox) / k - dragX0;
                    if (Math.abs(ddx) > 14) barMoved = true;
                    if (barMoved) barScroll = scroll0 - ddx;
                } else if (gridDrag) {
                    float ddy = (e.getY(0) - oy) / k - dragY0;
                    if (Math.abs(ddy) > 14) gridMoved = true;
                    if (gridMoved) gridScroll = scroll0 - ddy;
                }
                return true;
            }
            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_POINTER_UP:
            case MotionEvent.ACTION_CANCEL: {
                if (aiming && e.getPointerId(idx) == aimId) {
                    updatePull(x, y);
                    if (action != MotionEvent.ACTION_CANCEL) fire();
                    aiming = false;
                    aimId = -1;
                } else if (barDrag) {
                    barDrag = false;
                    if (!barMoved && action != MotionEvent.ACTION_CANCEL) {
                        float rel = dx - barX0 - 18 + barScroll;
                        int slot = (int) Math.floor(rel / (SLOT + SLOT_GAP));
                        if (slot >= 0 && slot < owned.size() && state != ST_FLY) {
                            ammo = owned.get(slot);
                            prefs.edit().putInt("ammo", ammo).apply();
                            click();
                        } else if (slot >= 0 && slot < owned.size()) {
                            ammo = owned.get(slot);
                            prefs.edit().putInt("ammo", ammo).apply();
                            click();
                        }
                    }
                } else if (gridDrag) {
                    gridDrag = false;
                    if (!gridMoved && pendingItem >= B_ITEM && action != MotionEvent.ACTION_CANCEL) onButton(pendingItem);
                }
                return true;
            }
        }
        return true;
    }

    private int pendingItem = -1;

    private void updatePull(float x, float y) {
        float dx = (x - tx0) / sc * 0.85f, dy = -(y - ty0) / sc * 0.85f;
        float len = (float) Math.hypot(dx, dy);
        if (len > MAX_PULL) {
            dx *= MAX_PULL / len;
            dy *= MAX_PULL / len;
        }
        if (GameWorld.POUCH_Y + dy < 1.0f) dy = 1.0f - GameWorld.POUCH_Y;
        pullX = dx;
        pullY = dy;
    }

    private void fire() {
        float len = (float) Math.hypot(pullX, pullY);
        if (len < 0.35f || state != ST_AIM) return;
        float vx = -pullX * MAX_SPEED / MAX_PULL, vy = -pullY * MAX_SPEED / MAX_PULL;
        game.launch(ammo, pouchX(), pouchY(), vx, vy);
        if (!sandbox) shotsLeft--;
        shotsFired++;
        state = ST_FLY;
        stateTime = 0;
        vibrate(15);
    }

    private void onButton(int id) {
        ui.pressedId = id;
        ui.pressedT = 0.12f;
        click();
        if (id >= B_ITEM) {
            armorySel = id - B_ITEM;
            return;
        }
        if (id >= B_TAB && id < B_TAB + 10) {
            armoryTab = id - B_TAB;
            gridScroll = 0;
            return;
        }
        if (id >= B_LEVEL && id < B_LEVEL + 50) {
            startLevel(world * Defs.LEVELS_PER_WORLD + id - B_LEVEL);
            return;
        }
        if (id >= B_WORLD && id < B_WORLD + 10) {
            world = id - B_WORLD;
            go(SC_LEVELS);
            return;
        }
        switch (id) {
            case B_PLAY:
                sandbox = false;
                go(SC_WORLDS);
                break;
            case B_SANDBOX:
                sandbox = true;
                go(SC_WORLDS);
                break;
            case B_ARMORY:
                armoryReturn = screen;
                go(SC_ARMORY);
                break;
            case B_SOUND:
                sfx.muted = !sfx.muted;
                prefs.edit().putBoolean("muted", sfx.muted).apply();
                break;
            case B_VIBE:
                vibeOn = !vibeOn;
                prefs.edit().putBoolean("vibe", vibeOn).apply();
                if (vibeOn) vibrate(40);
                break;
            case B_BACK:
                if (screen == SC_LEVELS) go(SC_WORLDS);
                else if (screen == SC_ARMORY) go(armoryReturn);
                else go(SC_MENU);
                break;
            case B_PAUSE:
                paused = true;
                aiming = false;
                break;
            case B_RESUME:
                paused = false;
                break;
            case B_RESTART:
            case B_RETRY:
                startLevel(level);
                break;
            case B_LEVELS:
                go(SC_LEVELS);
                break;
            case B_NEXT:
                if (level + 1 < Defs.LEVELS.length) startLevel(level + 1);
                else go(SC_WORLDS);
                break;
            case B_BUY: {
                int t = armorySel;
                if (isOwned(t)) {
                    ammo = t;
                    prefs.edit().putInt("ammo", ammo).apply();
                } else if (coins >= Defs.AMMO_PRICE[t]) buy(t);
                else showToast("NOT ENOUGH COINS - SMASH MORE BUILDINGS!");
                break;
            }
        }
    }
}
