package com.slingsmash.game;

import org.jbox2d.callbacks.ContactImpulse;
import org.jbox2d.callbacks.ContactListener;
import org.jbox2d.collision.Manifold;
import org.jbox2d.collision.WorldManifold;
import org.jbox2d.collision.shapes.CircleShape;
import org.jbox2d.collision.shapes.PolygonShape;
import org.jbox2d.collision.shapes.Shape;
import org.jbox2d.common.Vec2;
import org.jbox2d.dynamics.Body;
import org.jbox2d.dynamics.BodyDef;
import org.jbox2d.dynamics.BodyType;
import org.jbox2d.dynamics.FixtureDef;
import org.jbox2d.dynamics.World;
import org.jbox2d.dynamics.contacts.Contact;

import java.util.ArrayList;
import java.util.Random;

/** Physics simulation, destruction, particles and scoring. Pure Java so it can be tested off-device. */
final class GameWorld implements ContactListener {

    interface Fx {
        void sound(int id, float vol, float pitchVar);

        void vibrate(int ms);
    }

    static final float STEP = 1f / 60f;
    static final float POUCH_X = 0f, POUCH_Y = 5.6f;
    static final float GRAVITY = -11f;
    static final float DAMAGE_K = 1.6f;

    static final class Block {
        Body body;
        int mat, seed;
        float w, h, area, weight;
        float[] verts;
        float hp, maxHp, pendingDmg, flash;
        float x0, y0, a0;
        boolean fragment, dead;
    }

    static final class Shot {
        Body body;
        int type;
        float age, stepE, totalE;
        boolean triggered, gone;
    }

    static final int P_CHUNK = 0, P_DUST = 1, P_SPARK = 2, P_FIRE = 3, P_SMOKE = 4, P_SHARD = 5, P_JUICE = 6;

    static final class Particle {
        float x, y, vx, vy, rot, vr, size, grow, life, max;
        int color, kind;
    }

    static final class FloatText {
        float x, y, life;
        String text;
        int color;
    }

    World world;
    final ArrayList<Block> blocks = new ArrayList<>();
    final ArrayList<Shot> shots = new ArrayList<>();
    final ArrayList<Particle> particles = new ArrayList<>();
    final ArrayList<FloatText> texts = new ArrayList<>();
    final Random rnd = new Random();
    private final WorldManifold wm = new WorldManifold();
    private final float[] impacts = new float[3 * 8];
    private int impactCount;
    private final Fx fx;

    float time, shake, slowmo, totalW, destroyedW;
    int score, blocksBroken;
    private float acc;
    private int seedCounter = 1;

    GameWorld(Fx fx) {
        this.fx = fx;
    }

    // ------------------------------------------------------------------ setup

    void load(Defs.LevelDef def) {
        world = new World(new Vec2(0, GRAVITY));
        world.setContactListener(this);
        world.setAllowSleep(true);
        blocks.clear();
        shots.clear();
        particles.clear();
        texts.clear();
        time = 0; shake = 0; slowmo = 0; acc = 0;
        score = 0; blocksBroken = 0; destroyedW = 0; totalW = 0;

        BodyDef gd = new BodyDef();
        gd.position.set(30, -5);
        Body ground = world.createBody(gd);
        PolygonShape gs = new PolygonShape();
        gs.setAsBox(140, 5);
        FixtureDef gf = new FixtureDef();
        gf.shape = gs;
        gf.friction = 0.9f;
        ground.createFixture(gf);

        if (def == null) return;
        for (Defs.Spec s : def.specs) {
            Block b = makeBlock(s.x, s.y, s.w, s.h, 0f, s.mat, s.verts, false, false);
            totalW += b.weight;
        }
    }

    private Block makeBlock(float x, float y, float w, float h, float angle, int mat, float[] verts,
                            boolean fragment, boolean awake) {
        BodyDef bd = new BodyDef();
        bd.type = BodyType.DYNAMIC;
        bd.position.set(x, y);
        bd.angle = angle;
        bd.awake = awake;
        Body body = world.createBody(bd);
        PolygonShape ps = new PolygonShape();
        float area;
        if (verts == null) {
            ps.setAsBox(w / 2f, h / 2f);
            area = w * h;
        } else {
            int n = verts.length / 2;
            Vec2[] v = new Vec2[n];
            for (int i = 0; i < n; i++) v[i] = new Vec2(verts[i * 2], verts[i * 2 + 1]);
            ps.set(v, n);
            area = polyArea(verts);
        }
        FixtureDef fd = new FixtureDef();
        fd.shape = ps;
        fd.density = Defs.MAT_DENSITY[mat];
        fd.friction = Defs.MAT_FRICTION[mat];
        fd.restitution = 0.03f;
        body.createFixture(fd);

        Block b = new Block();
        b.body = body;
        b.mat = mat;
        b.w = w; b.h = h; b.verts = verts;
        b.area = area;
        b.weight = area;
        b.maxHp = Defs.MAT_HP[mat] * clamp(0.55f + area * 0.45f, 0.6f, 2.4f);
        b.hp = b.maxHp;
        b.x0 = x; b.y0 = y; b.a0 = angle;
        b.fragment = fragment;
        b.seed = seedCounter++ * 7919;
        body.setUserData(b);
        blocks.add(b);
        return b;
    }

    static float polyArea(float[] v) {
        float a = 0;
        int n = v.length / 2;
        for (int i = 0; i < n; i++) {
            int j = (i + 1) % n;
            a += v[i * 2] * v[j * 2 + 1] - v[j * 2] * v[i * 2 + 1];
        }
        return Math.abs(a) / 2f;
    }

    // ------------------------------------------------------------------ shots

    Shot launch(int type, float x, float y, float vx, float vy) {
        BodyDef bd = new BodyDef();
        bd.type = BodyType.DYNAMIC;
        bd.position.set(x, y);
        bd.bullet = true;
        bd.angularVelocity = -vx * 0.12f;
        Body body = world.createBody(bd);
        Shape shape;
        float[] sz = Defs.AMMO_SIZE[type];
        switch (Defs.AMMO_SHAPE[type]) {
            case Defs.SH_CIRCLE: {
                CircleShape cs = new CircleShape();
                cs.m_radius = sz[0];
                shape = cs;
                break;
            }
            case Defs.SH_POLY: {
                float[] p = type == Defs.A_ANVIL ? Defs.ANVIL_POLY : Defs.BOULDER_POLY;
                int n = p.length / 2;
                Vec2[] v = new Vec2[n];
                for (int i = 0; i < n; i++) v[i] = new Vec2(p[i * 2], p[i * 2 + 1]);
                PolygonShape ps = new PolygonShape();
                ps.set(v, n);
                shape = ps;
                break;
            }
            default: {
                PolygonShape ps = new PolygonShape();
                ps.setAsBox(sz[0], sz[1]);
                shape = ps;
            }
        }
        FixtureDef fd = new FixtureDef();
        fd.shape = shape;
        fd.density = Defs.AMMO_DENSITY[type];
        fd.friction = 0.6f;
        fd.restitution = Defs.AMMO_RESTITUTION[type];
        body.createFixture(fd);
        body.setLinearVelocity(new Vec2(vx, vy));
        Shot s = new Shot();
        s.body = body;
        s.type = type;
        body.setUserData(s);
        shots.add(s);
        // keep the world tidy: remove very old projectiles
        int live = 0;
        for (Shot o : shots) if (!o.gone) live++;
        if (live > 7) {
            for (Shot o : shots) {
                if (!o.gone) {
                    removeShot(o, true);
                    break;
                }
            }
        }
        fx.sound(Defs.S_LAUNCH, 0.9f, 0.1f);
        if (type == Defs.A_CAR) fx.sound(Defs.S_HONK, 0.7f, 0.05f);
        return s;
    }

    private void removeShot(Shot s, boolean puff) {
        if (s.gone) return;
        s.gone = true;
        if (puff) {
            Vec2 p = s.body.getPosition();
            for (int i = 0; i < 6; i++) dust(p.x, p.y, 0xFFDDD6CC, 0.6f);
        }
        world.destroyBody(s.body);
    }

    // ------------------------------------------------------------------ update

    void update(float dt) {
        float scale = slowmo > 0 ? 0.35f : 1f;
        if (slowmo > 0) slowmo -= dt;
        float sdt = dt * scale;
        acc += sdt;
        int n = 0;
        while (acc >= STEP && n < 4) {
            impactCount = 0;
            world.step(STEP, 8, 3);
            time += STEP;
            afterStep();
            acc -= STEP;
            n++;
        }
        if (n == 4) acc = 0;
        updateParticles(sdt);
        shake = Math.max(0, shake - dt * 2.2f);
    }

    private void afterStep() {
        // impact effects
        for (int i = 0; i < impactCount; i++) {
            float x = impacts[i * 3], y = impacts[i * 3 + 1], e = impacts[i * 3 + 2];
            int puffs = Math.min(4, 1 + (int) (e / 60f));
            for (int k = 0; k < puffs; k++) dust(x, y, 0xFFE8DFD0, 0.35f + Math.min(0.5f, e / 400f));
            if (e > 150) shake = Math.min(1.2f, shake + e / 1500f);
        }

        // projectile specials
        for (int i = 0; i < shots.size(); i++) {
            Shot s = shots.get(i);
            if (s.gone) continue;
            s.age += STEP;
            float e = s.stepE;
            s.stepE = 0;
            Vec2 p = s.body.getPosition();
            if (e > 0) {
                s.totalE += e;
                if (s.type == Defs.A_TNT && !s.triggered && e > 2f) {
                    s.triggered = true;
                    float x = p.x, y = p.y;
                    removeShot(s, false);
                    explode(x, y, 6.0f, 55f);
                    continue;
                }
                if (s.type == Defs.A_MELON && !s.triggered && e > 4f) {
                    s.triggered = true;
                    float x = p.x, y = p.y;
                    removeShot(s, false);
                    splat(x, y);
                    continue;
                }
                if (s.type == Defs.A_PIANO && !s.triggered && e > 20f) {
                    s.triggered = true;
                    fx.sound(Defs.S_PIANO, 1f, 0.08f);
                } else if (e > 15f) {
                    boolean metal = s.type == Defs.A_ANVIL || s.type == Defs.A_WRECK || s.type == Defs.A_CAR || s.type == Defs.A_FRIDGE;
                    fx.sound(metal ? Defs.S_METAL : Defs.S_THUD, vol(e), 0.15f);
                }
            }
            if (p.x > 120 || p.x < -40 || p.y < -15) removeShot(s, false);
        }

        // damage and out of bounds
        for (int i = blocks.size() - 1; i >= 0; i--) {
            Block b = blocks.get(i);
            if (b.dead) continue;
            if (b.pendingDmg > 0) {
                float d = b.pendingDmg;
                b.pendingDmg = 0;
                b.hp -= d;
                b.flash = Math.min(1f, b.flash + d / b.maxHp + 0.2f);
                if (b.hp <= 0) {
                    breakBlock(b);
                    continue;
                } else if (d > b.maxHp * 0.15f) {
                    fx.sound(b.mat == Defs.STEEL ? Defs.S_METAL : (b.mat == Defs.GLASS || b.mat == Defs.ICE ? Defs.S_GLASS : Defs.S_THUD),
                            0.25f + 0.5f * Math.min(1f, d / b.maxHp), 0.2f);
                    for (int k = 0; k < 3; k++) chunk(b.body.getPosition().x, b.body.getPosition().y, b.mat, 0.6f);
                }
            }
            Vec2 p = b.body.getPosition();
            if (p.y < -6 || p.x > 120 || p.x < -40) {
                b.dead = true;
                destroyedW += b.weight;
                world.destroyBody(b.body);
            }
        }
        for (int i = blocks.size() - 1; i >= 0; i--) if (blocks.get(i).dead) blocks.remove(i);
        for (int i = shots.size() - 1; i >= 0; i--) if (shots.get(i).gone) shots.remove(i);
    }

    private static float vol(float e) {
        return clamp(e / 250f, 0.15f, 1f);
    }

    private void breakBlock(Block b) {
        if (b.dead) return;
        b.dead = true;
        blocksBroken++;
        Body body = b.body;
        Vec2 c = body.getWorldCenter();
        float px = c.x, py = c.y;
        float ang = body.getAngle();
        Vec2 v = body.getLinearVelocity();
        float vx = v.x, vy = v.y, av = body.getAngularVelocity();
        world.destroyBody(body);

        if (!b.fragment && b.verts == null && b.area >= 0.7f) {
            boolean alongW = b.w >= b.h;
            float fw = alongW ? b.w / 2f : b.w, fh = alongW ? b.h : b.h / 2f;
            float cs = (float) Math.cos(ang), sn = (float) Math.sin(ang);
            for (int k = -1; k <= 1; k += 2) {
                float lx = alongW ? k * b.w / 4f : 0, ly = alongW ? 0 : k * b.h / 4f;
                float wx = px + lx * cs - ly * sn, wy = py + lx * sn + ly * cs;
                Block f = makeBlock(wx, wy, fw * 0.94f, fh * 0.94f, ang, b.mat, null, true, true);
                f.weight = b.weight * 0.25f;
                f.hp = f.maxHp * 0.45f;
                float push = 0.8f + rnd.nextFloat();
                float dx = alongW ? cs : -sn, dy = alongW ? sn : cs;
                f.body.setLinearVelocity(new Vec2(vx + k * dx * push, vy + k * dy * push + 0.5f));
                f.body.setAngularVelocity(av + (rnd.nextFloat() - 0.5f) * 4f);
                f.flash = 1f;
            }
            destroyedW += b.weight * 0.5f;
        } else {
            destroyedW += b.weight;
        }

        int nChunks = (int) Math.min(26, 7 + b.area * 9);
        for (int i = 0; i < nChunks; i++) chunk(px, py, b.mat, 1f + b.area * 0.15f);
        int nDust = (int) Math.min(6, 2 + b.area * 2);
        for (int i = 0; i < nDust; i++) dust(px, py, b.mat == Defs.GLASS || b.mat == Defs.ICE ? 0xFFEFF8FF : 0xFFE3D9C8, 0.5f + b.area * 0.2f);

        int pts = Math.round(Defs.MAT_POINTS[b.mat] * Math.max(0.5f, b.area) / 10f) * 10;
        if (b.fragment) pts /= 2;
        score += pts;
        FloatText t = new FloatText();
        t.x = px;
        t.y = py + 0.4f;
        t.text = "+" + pts;
        t.life = 1.1f;
        t.color = b.mat == Defs.GLASS || b.mat == Defs.ICE ? 0xFF8FE3FF : (b.mat == Defs.STEEL ? 0xFFD8E4F0 : 0xFFFFE066);
        texts.add(t);

        fx.sound(Defs.MAT_BREAK_SOUND[b.mat], Math.min(1f, 0.45f + b.area * 0.25f), 0.2f);
        if (b.area > 2f) fx.vibrate(25);
    }

    void explode(float x, float y, float radius, float power) {
        for (Block b : blocks) {
            if (b.dead) continue;
            blast(b.body, x, y, radius, power);
            Vec2 c = b.body.getWorldCenter();
            float d = (float) Math.hypot(c.x - x, c.y - y);
            if (d < radius) b.pendingDmg += 650f * (1f - d / radius);
        }
        for (Shot s : shots) if (!s.gone) blast(s.body, x, y, radius, power * 0.6f);

        for (int i = 0; i < 28; i++) {
            Particle p = new Particle();
            float a = rnd.nextFloat() * 6.283f, sp = 2f + rnd.nextFloat() * 7f;
            p.x = x; p.y = y;
            p.vx = (float) Math.cos(a) * sp;
            p.vy = (float) Math.sin(a) * sp + 2f;
            p.size = 0.5f + rnd.nextFloat() * 0.9f;
            p.grow = 1.2f;
            p.life = p.max = 0.45f + rnd.nextFloat() * 0.4f;
            p.color = rnd.nextBoolean() ? 0xFFFFB13B : (rnd.nextBoolean() ? 0xFFFF6A1F : 0xFFFFF0A0);
            p.kind = P_FIRE;
            add(p);
        }
        for (int i = 0; i < 16; i++) {
            Particle p = new Particle();
            float a = rnd.nextFloat() * 6.283f, sp = 0.5f + rnd.nextFloat() * 3f;
            p.x = x + (rnd.nextFloat() - 0.5f);
            p.y = y + (rnd.nextFloat() - 0.5f);
            p.vx = (float) Math.cos(a) * sp;
            p.vy = (float) Math.sin(a) * sp + 1.5f;
            p.size = 0.8f + rnd.nextFloat();
            p.grow = 1.4f;
            p.life = p.max = 1.2f + rnd.nextFloat() * 0.9f;
            p.color = rnd.nextBoolean() ? 0xFF4A4A52 : 0xFF6C6A70;
            p.kind = P_SMOKE;
            add(p);
        }
        for (int i = 0; i < 26; i++) {
            Particle p = new Particle();
            float a = rnd.nextFloat() * 6.283f, sp = 8f + rnd.nextFloat() * 12f;
            p.x = x; p.y = y;
            p.vx = (float) Math.cos(a) * sp;
            p.vy = (float) Math.sin(a) * sp;
            p.size = 0.06f;
            p.life = p.max = 0.3f + rnd.nextFloat() * 0.4f;
            p.color = 0xFFFFE27A;
            p.kind = P_SPARK;
            add(p);
        }
        shake = 1.6f;
        slowmo = 0.45f;
        fx.sound(Defs.S_BOOM, 1f, 0.1f);
        fx.vibrate(160);
    }

    private void blast(Body body, float x, float y, float radius, float power) {
        Vec2 c = body.getWorldCenter();
        float dx = c.x - x, dy = c.y - y;
        float d = (float) Math.sqrt(dx * dx + dy * dy);
        if (d >= radius) return;
        if (d < 0.1f) { dx = 0; dy = 1; d = 1; }
        float f = (1f - d / radius) * power * (float) Math.sqrt(body.getMass());
        body.applyLinearImpulse(new Vec2(dx / d * f, dy / d * f + f * 0.25f), c, true);
    }

    private void splat(float x, float y) {
        for (int i = 0; i < 34; i++) {
            Particle p = new Particle();
            float a = rnd.nextFloat() * 3.1416f, sp = 2f + rnd.nextFloat() * 8f;
            p.x = x; p.y = y;
            p.vx = (float) Math.cos(a) * sp;
            p.vy = (float) Math.sin(a) * sp;
            p.size = 0.1f + rnd.nextFloat() * 0.25f;
            p.life = p.max = 0.8f + rnd.nextFloat() * 0.8f;
            int r = rnd.nextInt(10);
            p.color = r < 6 ? 0xFFFF4D6A : (r < 8 ? 0xFF3FA34D : (r < 9 ? 0xFF1E1E1E : 0xFFFF8FA0));
            p.kind = P_JUICE;
            add(p);
        }
        fx.sound(Defs.S_SPLAT, 1f, 0.1f);
        shake = Math.max(shake, 0.5f);
    }

    private void chunk(float x, float y, int mat, float force) {
        Particle p = new Particle();
        float a = rnd.nextFloat() * 6.283f, sp = (1.5f + rnd.nextFloat() * 5f) * force;
        p.x = x + (rnd.nextFloat() - 0.5f) * 0.6f;
        p.y = y + (rnd.nextFloat() - 0.5f) * 0.6f;
        p.vx = (float) Math.cos(a) * sp;
        p.vy = (float) Math.sin(a) * sp + 2.5f;
        p.rot = rnd.nextFloat() * 360f;
        p.vr = (rnd.nextFloat() - 0.5f) * 900f;
        boolean shard = mat == Defs.GLASS || mat == Defs.ICE;
        p.size = shard ? 0.1f + rnd.nextFloat() * 0.22f : 0.08f + rnd.nextFloat() * 0.24f;
        p.life = p.max = 0.9f + rnd.nextFloat() * 1.0f;
        p.color = Defs.shade(Defs.MAT_COLOR[mat], 0.7f + rnd.nextFloat() * 0.6f);
        p.kind = shard ? P_SHARD : P_CHUNK;
        add(p);
    }

    private void dust(float x, float y, int color, float size) {
        Particle p = new Particle();
        float a = rnd.nextFloat() * 6.283f, sp = 0.4f + rnd.nextFloat() * 1.6f;
        p.x = x; p.y = y;
        p.vx = (float) Math.cos(a) * sp;
        p.vy = (float) Math.sin(a) * sp + 0.4f;
        p.size = size * (0.6f + rnd.nextFloat() * 0.6f);
        p.grow = size * 1.3f;
        p.life = p.max = 0.6f + rnd.nextFloat() * 0.6f;
        p.color = color;
        p.kind = P_DUST;
        add(p);
    }

    private void add(Particle p) {
        if (particles.size() < 700) particles.add(p);
    }

    private void updateParticles(float dt) {
        for (int i = particles.size() - 1; i >= 0; i--) {
            Particle p = particles.get(i);
            p.life -= dt;
            if (p.life <= 0) {
                int last = particles.size() - 1;
                particles.set(i, particles.get(last));
                particles.remove(last);
                continue;
            }
            switch (p.kind) {
                case P_CHUNK: case P_SHARD: case P_JUICE: case P_SPARK:
                    p.vy += GRAVITY * 1.2f * dt;
                    break;
                case P_FIRE:
                    p.vx *= 1f - 3f * dt; p.vy *= 1f - 3f * dt; p.vy += 2f * dt;
                    break;
                default:
                    p.vx *= 1f - 1.5f * dt; p.vy *= 1f - 1.5f * dt; p.vy += 0.6f * dt;
            }
            p.x += p.vx * dt;
            p.y += p.vy * dt;
            p.rot += p.vr * dt;
            p.size += p.grow * dt;
            if (p.y < 0.04f && (p.kind == P_CHUNK || p.kind == P_SHARD || p.kind == P_JUICE)) {
                p.y = 0.04f;
                p.vy = -p.vy * 0.3f;
                p.vx *= 0.6f;
                p.vr *= 0.5f;
            }
        }
        for (int i = texts.size() - 1; i >= 0; i--) {
            FloatText t = texts.get(i);
            t.life -= dt;
            t.y += dt * 1.6f;
            if (t.life <= 0) texts.remove(i);
        }
        for (Block b : blocks) if (b.flash > 0) b.flash = Math.max(0, b.flash - dt * 4f);
    }

    // ------------------------------------------------------------------ state

    float destruction() {
        if (totalW <= 0) return 0;
        float d = destroyedW;
        for (Block b : blocks) {
            if (b.fragment) d += 0.5f * b.weight;
            else {
                Vec2 p = b.body.getPosition();
                float dx = p.x - b.x0, dy = p.y - b.y0;
                float da = Math.abs(b.body.getAngle() - b.a0);
                if (dx * dx + dy * dy > 1.0f || da > 0.5f) d += 0.5f * b.weight;
            }
        }
        return Math.min(1f, d / totalW);
    }

    boolean settled() {
        for (Block b : blocks) {
            if (!b.body.isAwake()) continue;
            Vec2 v = b.body.getLinearVelocity();
            if (v.x * v.x + v.y * v.y > 0.2f || Math.abs(b.body.getAngularVelocity()) > 0.4f) return false;
        }
        for (Shot s : shots) {
            if (s.gone || !s.body.isAwake()) continue;
            Vec2 v = s.body.getLinearVelocity();
            if (v.x * v.x + v.y * v.y > 0.3f) return false;
        }
        return true;
    }

    // ------------------------------------------------------------------ contacts

    @Override
    public void beginContact(Contact contact) {}

    @Override
    public void endContact(Contact contact) {}

    @Override
    public void preSolve(Contact c, Manifold oldManifold) {
        Manifold m = c.getManifold();
        if (m.pointCount == 0) return;
        Body ba = c.getFixtureA().getBody(), bb = c.getFixtureB().getBody();
        c.getWorldManifold(wm);
        float vn = 0, px = 0, py = 0;
        for (int i = 0; i < m.pointCount; i++) {
            Vec2 p = wm.points[i];
            Vec2 va = ba.getLinearVelocityFromWorldPoint(p);
            Vec2 vb = bb.getLinearVelocityFromWorldPoint(p);
            float d = (vb.x - va.x) * wm.normal.x + (vb.y - va.y) * wm.normal.y;
            if (d < vn) { vn = d; px = p.x; py = p.y; }
        }
        if (vn > -1.4f) return;
        float ma = ba.getMass(), mb = bb.getMass();
        float me = ma == 0 ? mb : (mb == 0 ? ma : ma * mb / (ma + mb));
        float e = 0.5f * me * vn * vn;
        Object ua = ba.getUserData(), ub = bb.getUserData();
        hit(ua, ub, e);
        hit(ub, ua, e);
        if (e > 25f && impactCount < 8) {
            impacts[impactCount * 3] = px;
            impacts[impactCount * 3 + 1] = py;
            impacts[impactCount * 3 + 2] = e;
            impactCount++;
        }
    }

    private void hit(Object self, Object other, float e) {
        if (self instanceof Block) {
            Block b = (Block) self;
            if (time < 0.4f) return;
            b.pendingDmg += e * DAMAGE_K * (other instanceof Shot ? 1.25f : 1f);
        } else if (self instanceof Shot) {
            ((Shot) self).stepE += e;
        }
    }

    @Override
    public void postSolve(Contact contact, ContactImpulse impulse) {}

    static float clamp(float v, float a, float b) {
        return v < a ? a : (v > b ? b : v);
    }
}
