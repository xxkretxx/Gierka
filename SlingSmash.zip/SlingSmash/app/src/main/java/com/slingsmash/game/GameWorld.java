package com.slingsmash.game;

import org.jbox2d.callbacks.ContactImpulse;
import org.jbox2d.callbacks.ContactListener;
import org.jbox2d.collision.Manifold;
import org.jbox2d.collision.WorldManifold;
import org.jbox2d.collision.shapes.CircleShape;
import org.jbox2d.collision.shapes.PolygonShape;
import org.jbox2d.collision.shapes.Shape;
import org.jbox2d.common.Vec2;
import org.jbox2d.dynamics.Body;
import org.jbox2d.dynamics.BodyDef;
import org.jbox2d.dynamics.BodyType;
import org.jbox2d.dynamics.FixtureDef;
import org.jbox2d.dynamics.World;
import org.jbox2d.dynamics.contacts.Contact;

import java.util.ArrayList;
import java.util.Random;

/** Physics simulation, destruction, specials, particles and scoring. Pure Java so it can be tested off-device. */
final class GameWorld implements ContactListener {

    interface Fx {
        void sound(int id, float vol, float pitchVar);

        void vibrate(int ms);
    }

    static final float STEP = 1f / 60f;
    static final float POUCH_X = 0f, POUCH_Y = 5.6f;
    static final float GRAVITY = -11f;
    static final float DAMAGE_K = 1.6f;
    static final float COMBO_WINDOW = 0.75f;

    static final class Block {
        Body body;
        int mat, seed;
        float w, h, area, weight;
        float[] verts;
        float hp, maxHp, pendingDmg, flash;
        float x0, y0, a0;
        boolean fragment, dead, frozen;
        int flags;
        Defs.Spec spec;
    }

    /** Recorded slow-motion replay of one shot. */
    static final class Clip {
        final ArrayList<Block[]> blocks = new ArrayList<>();
        final ArrayList<float[]> bt = new ArrayList<>();
        final ArrayList<int[]> st = new ArrayList<>();
        final ArrayList<float[]> sp = new ArrayList<>();
        float startD, gain;
    }

    static final class Shot {
        Body body;
        int type;
        float age, stepE, totalE, trailT, boost;
        boolean blasted;
        boolean triggered, gone, impacted;
    }

    static final int P_CHUNK = 0, P_DUST = 1, P_SPARK = 2, P_FIRE = 3, P_SMOKE = 4, P_SHARD = 5, P_JUICE = 6,
            P_TRAIL = 7, P_SNOW = 8, P_GLOW = 9, P_RING = 10;

    static final class Particle {
        float x, y, vx, vy, rot, vr, size, grow, life, max;
        int color, kind;
    }

    static final class FloatText {
        float x, y, life;
        String text;
        int color;
        float size = 1f;
    }

    World world;
    final ArrayList<Block> blocks = new ArrayList<>();
    final ArrayList<Shot> shots = new ArrayList<>();
    final ArrayList<Particle> particles = new ArrayList<>();
    final ArrayList<FloatText> texts = new ArrayList<>();
    final Random rnd = new Random();
    private final WorldManifold wm = new WorldManifold();
    private final float[] impacts = new float[3 * 8];
    private int impactCount;
    private final Fx fx;
    private final ArrayList<float[]> pendingBlasts = new ArrayList<>();
    private final ArrayList<float[]> pendingFreeze = new ArrayList<>();

    float time, shake, slowmo, totalW, destroyedW;
    int score, blocksBroken, coins, maxCombo, comboBonus;
    // combo
    int combo;
    float lastBreak = -10f, comboFlash;
    String banner;
    float bannerT;
    // black hole
    float vortexX, vortexY, vortexT;
    // level rules
    Defs.LevelDef def;
    Body groundBody, platform;
    float platformX0;
    float wind, dmgBoost = 1f, firstShotTime = -1f;
    private float quakeT, quakeLeft, regenT;
    float quakeShow;
    int coresTotal, coresLeft, targetsTotal;
    Block crown;
    float crownY0, protectTotal;
    boolean shieldsDown, bossDefeated;
    final ArrayList<Defs.Spec> regenQueue = new ArrayList<>();
    final ArrayList<Block> magnets = new ArrayList<>();
    // stats for missions
    final int[] statBroken = new int[Defs.NUM_MATS];
    int statExplosions, statFrozen, statGold, launchedCows, launchedSpecial, blastCombos;
    // replay
    Clip clip, bestClip;
    private int recStep;
    private float acc;
    private int seedCounter = 1;
    Shot lastShot;

    GameWorld(Fx fx) {
        this.fx = fx;
    }

    // ------------------------------------------------------------------ setup

    void load(Defs.LevelDef def) {
        this.def = def;
        world = new World(new Vec2(0, GRAVITY));
        world.setContactListener(this);
        world.setAllowSleep(true);
        blocks.clear();
        shots.clear();
        particles.clear();
        texts.clear();
        pendingBlasts.clear();
        pendingFreeze.clear();
        regenQueue.clear();
        magnets.clear();
        time = 0; shake = 0; slowmo = 0; acc = 0;
        score = 0; blocksBroken = 0; destroyedW = 0; totalW = 0; coins = 0;
        combo = 0; maxCombo = 0; comboBonus = 0; lastBreak = -10; banner = null; bannerT = 0; comboFlash = 0;
        vortexT = 0;
        lastShot = null;
        firstShotTime = -1;
        quakeT = 0; quakeLeft = 0; quakeShow = 0; regenT = 0;
        coresTotal = 0; coresLeft = 0; targetsTotal = 0; crown = null; protectTotal = 0;
        shieldsDown = false; bossDefeated = false;
        java.util.Arrays.fill(statBroken, 0);
        statExplosions = 0; statFrozen = 0; statGold = 0; launchedCows = 0; launchedSpecial = 0; blastCombos = 0;
        clip = null; bestClip = null; recStep = 0;
        wind = def == null ? 0 : def.wind;

        BodyDef gd = new BodyDef();
        gd.type = BodyType.KINEMATIC;
        gd.position.set(30, -5);
        groundBody = world.createBody(gd);
        PolygonShape gs = new PolygonShape();
        gs.setAsBox(140, 5);
        FixtureDef gf = new FixtureDef();
        gf.shape = gs;
        gf.friction = 0.9f;
        groundBody.createFixture(gf);
        platform = null;

        if (def == null) return;
        float yOff = 0;
        boolean awake = false;
        if (def.platformAmp > 0) {
            float minX = 1e9f, maxX = -1e9f;
            for (Defs.Spec s : def.specs) { minX = Math.min(minX, s.x - s.w / 2); maxX = Math.max(maxX, s.x + s.w / 2); }
            BodyDef pd = new BodyDef();
            pd.type = BodyType.KINEMATIC;
            pd.position.set((minX + maxX) / 2, 0.25f);
            platform = world.createBody(pd);
            PolygonShape ps = new PolygonShape();
            ps.setAsBox((maxX - minX) / 2 + 0.6f, 0.25f);
            FixtureDef pf = new FixtureDef();
            pf.shape = ps;
            pf.friction = 1f;
            platform.createFixture(pf);
            platformX0 = platform.getPosition().x;
            yOff = 0.5f;
            awake = true;
        }
        for (Defs.Spec s : def.specs) {
            Block b = makeBlock(s.x, s.y + yOff, s.w, s.h, 0f, s.mat, s.verts, false, awake);
            b.flags = s.flags;
            b.spec = s;
            if ((s.flags & Defs.F_PROTECT) != 0) protectTotal += b.weight;
            else if (s.mat != Defs.CROWN) totalW += b.weight;
            if (s.mat == Defs.CORE) coresTotal++;
            if ((s.flags & Defs.F_TARGET) != 0) targetsTotal++;
            if (s.mat == Defs.MAGNET) magnets.add(b);
            if (s.mat == Defs.CROWN) { crown = b; crownY0 = b.y0; }
        }
        coresLeft = coresTotal;
    }

    private Block makeBlock(float x, float y, float w, float h, float angle, int mat, float[] verts,
                            boolean fragment, boolean awake) {
        BodyDef bd = new BodyDef();
        bd.type = BodyType.DYNAMIC;
        bd.position.set(x, y);
        bd.angle = angle;
        bd.awake = awake;
        Body body = world.createBody(bd);
        PolygonShape ps = new PolygonShape();
        float area;
        if (verts == null) {
            ps.setAsBox(w / 2f, h / 2f);
            area = w * h;
        } else {
            int n = verts.length / 2;
            Vec2[] v = new Vec2[n];
            for (int i = 0; i < n; i++) v[i] = new Vec2(verts[i * 2], verts[i * 2 + 1]);
            ps.set(v, n);
            area = polyArea(verts);
        }
        FixtureDef fd = new FixtureDef();
        fd.shape = ps;
        fd.density = Defs.MAT_DENSITY[mat];
        fd.friction = Defs.MAT_FRICTION[mat];
        fd.restitution = Defs.MAT_RESTITUTION[mat];
        body.createFixture(fd);

        Block b = new Block();
        b.body = body;
        b.mat = mat;
        b.w = w; b.h = h; b.verts = verts;
        b.area = area;
        b.weight = area;
        b.maxHp = Defs.MAT_HP[mat] * clamp(0.55f + area * 0.45f, 0.6f, 2.4f);
        b.hp = b.maxHp;
        b.x0 = x; b.y0 = y; b.a0 = angle;
        b.fragment = fragment;
        b.seed = seedCounter++ * 7919;
        body.setUserData(b);
        blocks.add(b);
        return b;
    }

    static float polyArea(float[] v) {
        float a = 0;
        int n = v.length / 2;
        for (int i = 0; i < n; i++) {
            int j = (i + 1) % n;
            a += v[i * 2] * v[j * 2 + 1] - v[j * 2] * v[i * 2 + 1];
        }
        return Math.abs(a) / 2f;
    }

    // ------------------------------------------------------------------ shots

    Shot launch(int type, float x, float y, float vx, float vy) {
        Shot s = spawnShot(type, x, y, vx, vy);
        lastShot = s;
        if (firstShotTime < 0) firstShotTime = time;
        finishClip();
        clip = new Clip();
        clip.startD = destruction();
        recStep = 0;
        // keep the world tidy: remove very old projectiles
        int live = 0;
        for (Shot o : shots) if (!o.gone) live++;
        if (live > 8) {
            for (Shot o : shots) {
                if (!o.gone && o != s) {
                    removeShot(o, true);
                    break;
                }
            }
        }
        fx.sound(Defs.S_LAUNCH, 0.9f, 0.1f);
        if (type == Defs.A_CAR || type == Defs.A_BUS) fx.sound(Defs.S_HONK, 0.7f, 0.05f);
        if (type == Defs.A_COW) fx.sound(Defs.S_MOO, 0.9f, 0.08f);
        return s;
    }

    private Shot spawnShot(int type, float x, float y, float vx, float vy) {
        BodyDef bd = new BodyDef();
        bd.type = BodyType.DYNAMIC;
        bd.position.set(x, y);
        bd.bullet = true;
        bd.angularVelocity = type == Defs.A_ROCKET ? 0 : -vx * 0.12f;
        if (type == Defs.A_ROCKET) bd.angle = (float) Math.atan2(vy, vx);
        Body body = world.createBody(bd);
        Shape shape;
        float[] sz = Defs.AMMO_SIZE[type];
        switch (Defs.AMMO_SHAPE[type]) {
            case Defs.SH_CIRCLE: {
                CircleShape cs = new CircleShape();
                cs.m_radius = sz[0];
                shape = cs;
                break;
            }
            case Defs.SH_POLY: {
                float[] p = type == Defs.A_ANVIL ? Defs.ANVIL_POLY : Defs.BOULDER_POLY;
                int n = p.length / 2;
                Vec2[] v = new Vec2[n];
                for (int i = 0; i < n; i++) v[i] = new Vec2(p[i * 2], p[i * 2 + 1]);
                PolygonShape ps = new PolygonShape();
                ps.set(v, n);
                shape = ps;
                break;
            }
            default: {
                PolygonShape ps = new PolygonShape();
                ps.setAsBox(sz[0], sz[1]);
                shape = ps;
            }
        }
        FixtureDef fd = new FixtureDef();
        fd.shape = shape;
        fd.density = Defs.AMMO_DENSITY[type];
        fd.friction = type == Defs.A_TIRE ? 0.95f : 0.6f;
        fd.restitution = Defs.AMMO_RESTITUTION[type];
        body.createFixture(fd);
        body.setLinearVelocity(new Vec2(vx, vy));
        Shot s = new Shot();
        s.body = body;
        s.type = type;
        body.setUserData(s);
        shots.add(s);
        return s;
    }

    private void removeShot(Shot s, boolean puff) {
        if (s.gone) return;
        s.gone = true;
        if (puff) {
            Vec2 p = s.body.getPosition();
            for (int i = 0; i < 6; i++) dust(p.x, p.y, 0xFFDDD6CC, 0.6f);
        }
        world.destroyBody(s.body);
    }

    /** True while the last shot can still react to a tap. */
    boolean canTrigger() {
        Shot s = lastShot;
        return s != null && !s.gone && !s.triggered && Defs.tappable(s.type) && !s.impacted;
    }

    /** Player tapped while the projectile was flying. */
    boolean trigger() {
        if (!canTrigger()) return false;
        return triggerShot(lastShot);
    }

    /** Fires a specific shot's special ability (used by the combo planner's fuses). */
    boolean triggerShot(Shot s) {
        if (s == null || s.gone || s.triggered || !Defs.tappable(s.type)) return false;
        s.triggered = true;
        Vec2 p = s.body.getPosition();
        Vec2 v = s.body.getLinearVelocity();
        float x = p.x, y = p.y, vx = v.x, vy = v.y;
        switch (s.type) {
            case Defs.A_TNT:
                removeShot(s, false);
                explode(x, y, 6.0f, 55f);
                break;
            case Defs.A_CLUSTER: {
                removeShot(s, false);
                for (int i = 0; i < 4; i++) {
                    float spread = (i - 1.5f) * 2.2f;
                    Shot m = spawnShot(Defs.A_MINI, x + (i - 1.5f) * 0.3f, y, vx * 0.92f + spread * 0.4f, vy + spread);
                    m.triggered = true;
                }
                ring(x, y, 0xFFFFB13B, 2.5f);
                for (int i = 0; i < 10; i++) spark(x, y, 0xFFFFE27A, 8f);
                fx.sound(Defs.S_POP, 1f, 0.1f);
                break;
            }
            case Defs.A_ROCKET: {
                float len = (float) Math.sqrt(vx * vx + vy * vy);
                if (len < 0.1f) len = 0.1f;
                float sp = Math.max(30f, len * 1.6f);
                s.body.setLinearVelocity(new Vec2(vx / len * sp, vy / len * sp));
                s.boost = 1.6f;
                lastShot = null;
                ring(x, y, 0xFFFFB13B, 2f);
                fx.sound(Defs.S_ROCKET, 1f, 0.05f);
                break;
            }
            case Defs.A_FREEZE:
                removeShot(s, false);
                freeze(x, y, 6f);
                break;
            case Defs.A_HOLE:
                removeShot(s, false);
                startVortex(x, y);
                break;
        }
        return true;
    }

    // ------------------------------------------------------------------ update

    void update(float dt) {
        float scale = slowmo > 0 ? 0.35f : 1f;
        if (slowmo > 0) slowmo -= dt;
        float sdt = dt * scale;
        acc += sdt;
        int n = 0;
        while (acc >= STEP && n < 4) {
            impactCount = 0;
            preStep();
            world.step(STEP, 8, 3);
            time += STEP;
            afterStep();
            acc -= STEP;
            n++;
        }
        if (n == 4) acc = 0;
        updateParticles(sdt);
        shake = Math.max(0, shake - dt * 2.2f);
        if (bannerT > 0) bannerT -= dt;
        if (comboFlash > 0) comboFlash -= dt;
        if (time - lastBreak > COMBO_WINDOW + 0.6f) combo = 0;
        if (quakeShow > 0) quakeShow -= dt;
    }

    /** Forces applied every physics step: wind, magnets, quakes, moving platform, regrowth. */
    private void preStep() {
        if (wind != 0) {
            for (Shot s : shots) if (!s.gone) s.body.applyForceToCenter(new Vec2(s.body.getMass() * wind, 0));
        }
        for (Block m : magnets) {
            if (m.dead) continue;
            Vec2 mp = m.body.getWorldCenter();
            for (Shot s : shots) {
                if (s.gone || !isMetal(s.type)) continue;
                Vec2 c = s.body.getWorldCenter();
                float dx = mp.x - c.x, dy = mp.y - c.y, d = (float) Math.sqrt(dx * dx + dy * dy);
                if (d > 9f || d < 0.3f) continue;
                float f = s.body.getMass() * 70f / Math.max(1f, d);
                s.body.applyForceToCenter(new Vec2(dx / d * f, dy / d * f));
                if (rnd.nextFloat() < 0.3f) spark(c.x, c.y, 0xFFFF7A7A, 3f);
            }
        }
        if (platform != null) {
            float w = (float) (2 * Math.PI / def.platformPeriod);
            platform.setLinearVelocity(new Vec2(def.platformAmp * w * (float) Math.sin(w * time), 0));
        }
        if (def != null && def.quake > 0 && firstShotTime >= 0) {
            if (quakeLeft > 0) {
                quakeLeft -= STEP;
                float f = 2.3f, a = 0.07f, w = (float) (2 * Math.PI * f), tq = 1.6f - quakeLeft;
                groundBody.setLinearVelocity(new Vec2(a * w * (float) Math.cos(w * tq), 0));
                shake = Math.max(shake, 0.45f);
                if (rnd.nextFloat() < 0.5f) dust(-5 + rnd.nextFloat() * 55, 0.1f, 0xFFE3D9C8, 0.5f);
                if (quakeLeft <= 0) {
                    groundBody.setLinearVelocity(new Vec2(0, 0));
                    groundBody.setTransform(new Vec2(30, -5), 0);
                }
            } else {
                quakeT += STEP;
                if (quakeT > def.quake) {
                    quakeT = 0;
                    quakeLeft = 1.6f;
                    quakeShow = 1.8f;
                    for (Block b : blocks) b.body.setAwake(true);
                    fx.sound(Defs.S_STONE, 1f, 0.3f);
                    fx.vibrate(200);
                    showBanner("EARTHQUAKE!");
                }
            }
        }
        if (def != null && def.regen > 0 && (coresLeft > 0 || def.objective != Defs.O_CORES)) {
            regenT += STEP;
            if (regenT > def.regen) {
                regenT = 0;
                int n = 0;
                int healed = 0;
                for (Block hb : blocks) {
                    if (hb.dead || hb.hp >= hb.maxHp) continue;
                    hb.hp = Math.min(hb.maxHp, hb.hp + hb.maxHp * def.regenHeal);
                    hb.flash = 0.6f;
                    healed++;
                }
                if (healed > 0 && regenQueue.isEmpty()) showBanner("IT'S HEALING!");
                for (int i = regenQueue.size() - 1; i >= 0 && n < def.regenCount; i--) {
                    Defs.Spec sp = regenQueue.get(i);
                    if (spaceFree(sp)) {
                        regenQueue.remove(i);
                        Block nb = makeBlock(sp.x, sp.y, sp.w, sp.h, 0, sp.mat, sp.verts, false, false);
                        nb.spec = sp;
                        nb.flags = sp.flags;
                        nb.weight = 0;
                        nb.flash = 1f;
                        for (int k = 0; k < 6; k++) spark(sp.x, sp.y, 0xFF7CFFB0, 4f);
                        n++;
                    }
                }
                if (n > 0) {
                    showBanner("IT'S REGROWING!");
                    fx.sound(Defs.S_FREEZE, 0.6f, 0.2f);
                }
            }
        }
    }

    private boolean spaceFree(Defs.Spec sp) {
        for (Block b : blocks) {
            if (b.dead) continue;
            Vec2 p = b.body.getPosition();
            float r2 = (float) Math.hypot(b.w, b.h) / 2;
            if (Math.abs(p.x - sp.x) < sp.w / 2 + r2 - 0.05f && Math.abs(p.y - sp.y) < sp.h / 2 + r2 - 0.05f) {
                if (Math.abs(b.body.getAngle()) < 0.05f) {
                    if (Math.abs(p.x - sp.x) < (sp.w + b.w) / 2 - 0.02f && Math.abs(p.y - sp.y) < (sp.h + b.h) / 2 - 0.02f) return false;
                } else return false;
            }
        }
        for (Shot s : shots) {
            if (s.gone) continue;
            Vec2 p = s.body.getPosition();
            if (Math.abs(p.x - sp.x) < sp.w / 2 + 1.2f && Math.abs(p.y - sp.y) < sp.h / 2 + 1.2f) return false;
        }
        return true;
    }

    static boolean isMetal(int t) {
        return t == Defs.A_ANVIL || t == Defs.A_CAR || t == Defs.A_WRECK || t == Defs.A_FRIDGE || t == Defs.A_SAFE
                || t == Defs.A_BUS || t == Defs.A_CANNON || t == Defs.A_ROCKET;
    }

    // ------------------------------------------------------------------ replay recording

    private void record() {
        if (clip == null || clip.blocks.size() >= 240) return;
        if ((recStep++ & 1) != 0) return;
        int n = blocks.size();
        Block[] bs = new Block[n];
        float[] t = new float[n * 4];
        for (int i = 0; i < n; i++) {
            Block b = blocks.get(i);
            bs[i] = b;
            Vec2 p = b.body.getPosition();
            t[i * 4] = p.x; t[i * 4 + 1] = p.y; t[i * 4 + 2] = b.body.getAngle(); t[i * 4 + 3] = 1f - b.hp / b.maxHp;
        }
        int ns = 0;
        for (Shot s : shots) if (!s.gone) ns++;
        int[] types = new int[ns];
        float[] sp = new float[ns * 3];
        int k = 0;
        for (Shot s : shots) {
            if (s.gone) continue;
            Vec2 p = s.body.getPosition();
            types[k] = s.type;
            sp[k * 3] = p.x; sp[k * 3 + 1] = p.y; sp[k * 3 + 2] = s.body.getAngle();
            k++;
        }
        clip.blocks.add(bs);
        clip.bt.add(t);
        clip.st.add(types);
        clip.sp.add(sp);
    }

    /** Closes the current replay clip and keeps it if it was the most destructive one. */
    void finishClip() {
        if (clip == null) return;
        clip.gain = destruction() - clip.startD;
        if (clip.blocks.size() > 20 && (bestClip == null || clip.gain > bestClip.gain)) bestClip = clip;
        clip = null;
    }

    private void afterStep() {
        record();
        // impact effects
        for (int i = 0; i < impactCount; i++) {
            float x = impacts[i * 3], y = impacts[i * 3 + 1], e = impacts[i * 3 + 2];
            int puffs = Math.min(4, 1 + (int) (e / 60f));
            for (int k = 0; k < puffs; k++) dust(x, y, 0xFFE8DFD0, 0.35f + Math.min(0.5f, e / 400f));
            if (e > 150) shake = Math.min(1.2f, shake + e / 1500f);
        }

        // black hole
        if (vortexT > 0) updateVortex();

        // projectile specials
        for (int i = 0; i < shots.size(); i++) {
            Shot s = shots.get(i);
            if (s.gone) continue;
            s.age += STEP;
            float e = s.stepE;
            s.stepE = 0;
            Vec2 p = s.body.getPosition();
            Vec2 v = s.body.getLinearVelocity();
            float speed2 = v.x * v.x + v.y * v.y;
            // trails
            s.trailT -= STEP;
            if (!s.impacted && s.trailT <= 0 && speed2 > 25) {
                s.trailT = 0.045f;
                trail(p.x, p.y, s.type == Defs.A_METEOR || s.boost > 0 ? 0 : 1);
            }
            if (s.type == Defs.A_METEOR || s.boost > 0) {
                for (int k = 0; k < 2; k++) fire(p.x - v.x * 0.02f, p.y - v.y * 0.02f, 0.35f, 1f);
            }
            if (s.boost > 0) s.boost -= STEP;
            if (s.type == Defs.A_ROCKET && !s.impacted && speed2 > 1) {
                s.body.setTransform(s.body.getPosition(), (float) Math.atan2(v.y, v.x));
                s.body.setAngularVelocity(0);
            }
            if (e > 0) {
                s.totalE += e;
                float x = p.x, y = p.y;
                boolean first = !s.impacted && e > 2f;
                if (e > 2f) s.impacted = true;
                if (first && lastShot == s && !Defs.tappable(s.type)) lastShot = null;
                if (s.type == Defs.A_TNT && e > 2f) {
                    removeShot(s, false);
                    explode(x, y, 6.0f, 55f);
                    continue;
                }
                if ((s.type == Defs.A_MINI || s.type == Defs.A_CLUSTER) && e > 1.5f) {
                    removeShot(s, false);
                    explode(x, y, s.type == Defs.A_MINI ? 3.2f : 4.2f, s.type == Defs.A_MINI ? 28f : 40f);
                    continue;
                }
                if (s.type == Defs.A_ROCKET && e > 1.5f) {
                    removeShot(s, false);
                    explode(x, y, 4.2f, 45f);
                    continue;
                }
                if (s.type == Defs.A_METEOR && e > 4f) {
                    removeShot(s, false);
                    explode(x, y, 5.0f, 50f);
                    for (int k = 0; k < 20; k++) fire(x, y, 0.6f, 3f);
                    continue;
                }
                if (s.type == Defs.A_FREEZE && e > 1.5f && !s.triggered) {
                    removeShot(s, false);
                    freeze(x, y, 6f);
                    continue;
                }
                if (s.type == Defs.A_HOLE && e > 1.5f && !s.triggered) {
                    removeShot(s, false);
                    startVortex(x, y);
                    continue;
                }
                if (s.type == Defs.A_MELON && !s.triggered && e > 4f) {
                    s.triggered = true;
                    removeShot(s, false);
                    splat(x, y);
                    continue;
                }
                if (s.type == Defs.A_PIANO && !s.triggered && e > 20f) {
                    s.triggered = true;
                    fx.sound(Defs.S_PIANO, 1f, 0.08f);
                } else if (s.type == Defs.A_COW && first) {
                    fx.sound(Defs.S_MOO, 1f, 0.15f);
                } else if (e > 15f) {
                    boolean metal = s.type == Defs.A_ANVIL || s.type == Defs.A_WRECK || s.type == Defs.A_CAR
                            || s.type == Defs.A_FRIDGE || s.type == Defs.A_SAFE || s.type == Defs.A_BUS || s.type == Defs.A_CANNON;
                    fx.sound(metal ? Defs.S_METAL : Defs.S_THUD, vol(e), 0.15f);
                }
            }
            if (p.x > 120 || p.x < -40 || p.y < -15) removeShot(s, false);
        }

        // queued freeze / blasts (from TNT blocks)
        for (int i = 0; i < pendingFreeze.size(); i++) {
            float[] f = pendingFreeze.get(i);
            doFreeze(f[0], f[1], f[2]);
        }
        pendingFreeze.clear();
        for (int i = 0; i < pendingBlasts.size(); i++) {
            float[] f = pendingBlasts.get(i);
            explode(f[0], f[1], f[2], f[3]);
        }
        pendingBlasts.clear();

        // damage and out of bounds
        for (int i = blocks.size() - 1; i >= 0; i--) {
            if (i >= blocks.size()) continue;
            Block b = blocks.get(i);
            if (b.dead) continue;
            if (b.pendingDmg > 0) {
                float d = b.pendingDmg;
                b.pendingDmg = 0;
                if (b.mat == Defs.CROWN || (b.mat == Defs.SHIELD && coresLeft > 0)) {
                    if (b.mat == Defs.SHIELD && d > 20) { b.flash = 1f; fx.sound(Defs.S_METAL, 0.4f, 0.3f); }
                    continue;
                }
                b.hp -= d;
                b.flash = Math.min(1f, b.flash + d / b.maxHp + 0.2f);
                if (b.hp <= 0) {
                    breakBlock(b);
                    continue;
                } else if (d > b.maxHp * 0.15f) {
                    fx.sound(b.mat == Defs.STEEL ? Defs.S_METAL : (b.mat == Defs.GLASS || b.mat == Defs.ICE ? Defs.S_GLASS : Defs.S_THUD),
                            0.25f + 0.5f * Math.min(1f, d / b.maxHp), 0.2f);
                    for (int k = 0; k < 3; k++) chunk(b.body.getPosition().x, b.body.getPosition().y, b.mat, 0.6f);
                }
            }
            Vec2 p = b.body.getPosition();
            if (p.y < -6 || p.x > 120 || p.x < -40) {
                b.dead = true;
                if ((b.flags & Defs.F_PROTECT) == 0 && b.mat != Defs.CROWN) destroyedW += b.weight;
                world.destroyBody(b.body);
            }
        }
        for (int i = blocks.size() - 1; i >= 0; i--) if (blocks.get(i).dead) blocks.remove(i);
        for (int i = shots.size() - 1; i >= 0; i--) if (shots.get(i).gone) shots.remove(i);
    }

    private static float vol(float e) {
        return clamp(e / 250f, 0.15f, 1f);
    }

    private void breakBlock(Block b) {
        if (b.dead) return;
        b.dead = true;
        blocksBroken++;
        Body body = b.body;
        Vec2 c = body.getWorldCenter();
        float px = c.x, py = c.y;
        float ang = body.getAngle();
        Vec2 v = body.getLinearVelocity();
        float vx = v.x, vy = v.y, av = body.getAngularVelocity();
        world.destroyBody(body);

        statBroken[b.mat]++;
        if (!b.fragment && b.spec != null && def != null && def.regen > 0 && b.mat != Defs.CORE && b.weight > 0) regenQueue.add(b.spec);
        if (b.mat == Defs.CORE) {
            coresLeft--;
            showBanner(coresLeft > 0 ? "CORE DESTROYED!" : "BOSS DEFEATED!");
            explodeLater(px, py, 3.5f, 30f);
            if (coresLeft == 0) {
                bossDefeated = true;
                fx.sound(Defs.S_WIN, 1f, 0f);
                for (Block sb : blocks) if (sb.mat == Defs.SHIELD && !sb.dead) sb.pendingDmg += 1e10f;
                shieldsDown = true;
            }
        }
        if (b.mat == Defs.CRYSTAL) {
            for (Block o : blocks) {
                if (o.dead || o == b) continue;
                Vec2 oc = o.body.getWorldCenter();
                float d = (float) Math.hypot(oc.x - px, oc.y - py);
                if (d < 2.8f) o.pendingDmg += 260f * (1f - d / 2.8f) + 40f;
            }
            for (int i = 0; i < 16; i++) spark(px, py, 0xFFD6B8FF, 9f);
            ring(px, py, 0xFFC49BFF, 2.8f);
        }
        boolean special = b.mat == Defs.TNT || b.mat == Defs.GOLD || b.mat == Defs.CORE || b.mat == Defs.SHIELD || b.mat == Defs.CROWN;
        if (!special && !b.fragment && b.verts == null && b.area >= 0.7f) {
            boolean alongW = b.w >= b.h;
            float fw = alongW ? b.w / 2f : b.w, fh = alongW ? b.h : b.h / 2f;
            float cs = (float) Math.cos(ang), sn = (float) Math.sin(ang);
            for (int k = -1; k <= 1; k += 2) {
                float lx = alongW ? k * b.w / 4f : 0, ly = alongW ? 0 : k * b.h / 4f;
                float wx = px + lx * cs - ly * sn, wy = py + lx * sn + ly * cs;
                Block f = makeBlock(wx, wy, fw * 0.94f, fh * 0.94f, ang, b.mat, null, true, true);
                f.weight = b.weight * 0.25f;
                f.flags = b.flags & Defs.F_PROTECT;
                f.hp = f.maxHp * (b.frozen ? 0.2f : 0.45f);
                f.frozen = b.frozen;
                float push = 0.8f + rnd.nextFloat();
                float dx = alongW ? cs : -sn, dy = alongW ? sn : cs;
                f.body.setLinearVelocity(new Vec2(vx + k * dx * push, vy + k * dy * push + 0.5f));
                f.body.setAngularVelocity(av + (rnd.nextFloat() - 0.5f) * 4f);
                f.flash = 1f;
            }
            if ((b.flags & Defs.F_PROTECT) == 0) destroyedW += b.weight * 0.5f;
        } else if ((b.flags & Defs.F_PROTECT) == 0 && b.mat != Defs.CROWN) {
            destroyedW += b.weight;
        }

        int nChunks = (int) Math.min(26, 7 + b.area * 9);
        for (int i = 0; i < nChunks; i++) chunk(px, py, b.mat, 1f + b.area * 0.15f);
        int nDust = (int) Math.min(6, 2 + b.area * 2);
        for (int i = 0; i < nDust; i++) dust(px, py, b.mat == Defs.GLASS || b.mat == Defs.ICE ? 0xFFEFF8FF : 0xFFE3D9C8, 0.5f + b.area * 0.2f);

        // combo
        if (time - lastBreak < COMBO_WINDOW) combo++;
        else combo = 1;
        lastBreak = time;
        if (combo > maxCombo) maxCombo = combo;
        int pts = Math.round(Defs.MAT_POINTS[b.mat] * Math.max(0.5f, b.area) / 10f) * 10;
        if (b.fragment) pts /= 2;
        int bonus = combo >= 3 ? combo * 25 : 0;
        score += pts + bonus;
        comboBonus += bonus;
        if (combo >= 3) comboFlash = 0.35f;
        if (combo == 5) showBanner("SMASHING!");
        else if (combo == 10) showBanner("DEMOLITION!");
        else if (combo == 20) showBanner("TOTAL CHAOS!");
        else if (combo == 35) showBanner("UNSTOPPABLE!");
        else if (combo == 60) showBanner("GODLIKE!");

        FloatText t = new FloatText();
        t.x = px;
        t.y = py + 0.4f;
        t.text = "+" + pts;
        t.life = 1.1f;
        t.color = b.mat == Defs.GLASS || b.mat == Defs.ICE ? 0xFF8FE3FF : (b.mat == Defs.STEEL ? 0xFFD8E4F0 : 0xFFFFE066);
        texts.add(t);

        if (b.mat == Defs.GOLD) {
            statGold++;
            int c2 = Math.max(5, Math.round(b.area * 25));
            coins += c2;
            FloatText ct = new FloatText();
            ct.x = px;
            ct.y = py + 1.2f;
            ct.text = "+" + c2 + " COINS";
            ct.life = 1.6f;
            ct.size = 1.15f;
            ct.color = 0xFFFFD23F;
            texts.add(ct);
            for (int i = 0; i < 18; i++) spark(px, py, 0xFFFFE27A, 6f);
            fx.sound(Defs.S_COIN, 1f, 0.05f);
        } else if (b.mat == Defs.TNT) {
            pendingBlasts.add(new float[]{px, py, 4.5f, 40f});
        } else {
            fx.sound(Defs.MAT_BREAK_SOUND[b.mat], Math.min(1f, 0.45f + b.area * 0.25f), 0.2f);
        }
        if (b.area > 2f) fx.vibrate(25);
    }

    private void showBanner(String s) {
        banner = s;
        bannerT = 1.6f;
        fx.sound(Defs.S_STAR, 0.7f, 0.1f);
    }

    private void explodeLater(float x, float y, float r, float p) {
        pendingBlasts.add(new float[]{x, y, r, p});
    }

    void explode(float x, float y, float radius, float power) {
        statExplosions++;
        for (Block b : blocks) {
            if (b.dead) continue;
            blast(b.body, x, y, radius, power);
            Vec2 c = b.body.getWorldCenter();
            float d = (float) Math.hypot(c.x - x, c.y - y);
            if (d < radius) b.pendingDmg += 650f * (1f - d / radius);
        }
        for (Shot s : shots) {
            if (s.gone) continue;
            Vec2 sc = s.body.getWorldCenter();
            float sd = (float) Math.hypot(sc.x - x, sc.y - y);
            if (sd < radius) {
                blast(s.body, x, y, radius, power * 1.0f);
                if (!s.blasted && s.age > 0.05f) {
                    s.blasted = true;
                    s.impacted = false;
                    blastCombos++;
                    score += 750;
                    showBanner(blastCombos > 1 ? "CHAIN COMBO x" + blastCombos + "!" : "BLAST COMBO!");
                    FloatText t = new FloatText();
                    t.x = sc.x; t.y = sc.y + 1f; t.text = "+750 ROCKET JUMP"; t.life = 1.4f; t.size = 1.1f; t.color = 0xFFFF9A3C;
                    texts.add(t);
                }
            }
        }

        for (int i = 0; i < 28; i++) fire(x, y, 0.5f + rnd.nextFloat() * 0.9f, 7f);
        for (int i = 0; i < 16; i++) {
            Particle p = new Particle();
            float a = rnd.nextFloat() * 6.283f, sp = 0.5f + rnd.nextFloat() * 3f;
            p.x = x + (rnd.nextFloat() - 0.5f);
            p.y = y + (rnd.nextFloat() - 0.5f);
            p.vx = (float) Math.cos(a) * sp;
            p.vy = (float) Math.sin(a) * sp + 1.5f;
            p.size = 0.8f + rnd.nextFloat();
            p.grow = 1.4f;
            p.life = p.max = 1.2f + rnd.nextFloat() * 0.9f;
            p.color = rnd.nextBoolean() ? 0xFF4A4A52 : 0xFF6C6A70;
            p.kind = P_SMOKE;
            add(p);
        }
        for (int i = 0; i < 26; i++) spark(x, y, 0xFFFFE27A, 14f);
        ring(x, y, 0xFFFFE2A0, radius * 0.9f);
        Particle g = new Particle();
        g.x = x; g.y = y; g.size = radius * 0.6f; g.grow = radius * 1.5f; g.life = g.max = 0.35f; g.color = 0xFFFFF4C0; g.kind = P_GLOW;
        add(g);
        shake = 1.6f;
        slowmo = 0.45f;
        fx.sound(Defs.S_BOOM, 1f, 0.1f);
        fx.vibrate(160);
    }

    private void blast(Body body, float x, float y, float radius, float power) {
        Vec2 c = body.getWorldCenter();
        float dx = c.x - x, dy = c.y - y;
        float d = (float) Math.sqrt(dx * dx + dy * dy);
        if (d >= radius) return;
        if (d < 0.1f) { dx = 0; dy = 1; d = 1; }
        float f = (1f - d / radius) * power * (float) Math.sqrt(body.getMass());
        body.applyLinearImpulse(new Vec2(dx / d * f, dy / d * f + f * 0.25f), c, true);
    }

    void freeze(float x, float y, float r) {
        pendingFreeze.add(new float[]{x, y, r});
    }

    private void doFreeze(float x, float y, float r) {
        int n = 0;
        for (Block b : blocks) {
            if (b.dead) continue;
            Vec2 c = b.body.getWorldCenter();
            float d = (float) Math.hypot(c.x - x, c.y - y);
            if (d > r) continue;
            if (b.mat != Defs.TNT && b.mat != Defs.GOLD && b.mat != Defs.ICE && b.mat < Defs.RUBBER) {
                b.mat = Defs.ICE;
                b.frozen = true;
                b.maxHp = Defs.MAT_HP[Defs.ICE] * clamp(0.55f + b.area * 0.45f, 0.6f, 2.4f);
                b.hp = Math.min(b.hp, b.maxHp);
                b.flash = 1f;
                n++;
                statFrozen++;
            }
            b.body.setAwake(true);
            blast(b.body, x, y, r, 6f);
        }
        for (int i = 0; i < 46; i++) {
            Particle p = new Particle();
            float a = rnd.nextFloat() * 6.283f, sp = 2f + rnd.nextFloat() * 9f;
            p.x = x; p.y = y;
            p.vx = (float) Math.cos(a) * sp;
            p.vy = (float) Math.sin(a) * sp;
            p.rot = rnd.nextFloat() * 360;
            p.vr = (rnd.nextFloat() - 0.5f) * 400;
            p.size = 0.1f + rnd.nextFloat() * 0.18f;
            p.life = p.max = 0.8f + rnd.nextFloat() * 0.8f;
            p.color = rnd.nextBoolean() ? 0xFFFFFFFF : 0xFFBFEAFF;
            p.kind = P_SNOW;
            add(p);
        }
        ring(x, y, 0xFFBFEAFF, r);
        Particle g = new Particle();
        g.x = x; g.y = y; g.size = r * 0.5f; g.grow = r * 1.2f; g.life = g.max = 0.5f; g.color = 0xFFDDF6FF; g.kind = P_GLOW;
        add(g);
        shake = Math.max(shake, 0.7f);
        fx.sound(Defs.S_FREEZE, 1f, 0.05f);
        fx.vibrate(60);
        if (n > 0) {
            FloatText t = new FloatText();
            t.x = x; t.y = y + 1.5f; t.text = "FROZEN x" + n; t.life = 1.5f; t.size = 1.2f; t.color = 0xFFBFEAFF;
            texts.add(t);
        }
    }

    private void startVortex(float x, float y) {
        vortexX = x;
        vortexY = Math.max(1.5f, y);
        vortexT = 2.6f;
        fx.sound(Defs.S_VORTEX, 1f, 0f);
        fx.vibrate(80);
    }

    private void updateVortex() {
        vortexT -= STEP;
        float strength = 75f;
        Vec2 f = new Vec2();
        for (Block b : blocks) {
            if (b.dead) continue;
            pull(b.body, strength, f);
            Vec2 c = b.body.getWorldCenter();
            float d = (float) Math.hypot(c.x - vortexX, c.y - vortexY);
            if (d < 1.6f) b.pendingDmg += 9f;
        }
        for (Shot s : shots) if (!s.gone) pull(s.body, strength * 0.5f, f);
        for (int k = 0; k < 3; k++) {
            Particle p = new Particle();
            float a = rnd.nextFloat() * 6.283f, r = 2.5f + rnd.nextFloat() * 4f;
            p.x = vortexX + (float) Math.cos(a) * r;
            p.y = vortexY + (float) Math.sin(a) * r;
            float tx = -(float) Math.sin(a), ty = (float) Math.cos(a);
            p.vx = tx * 7f - (float) Math.cos(a) * 5f;
            p.vy = ty * 7f - (float) Math.sin(a) * 5f;
            p.size = 0.08f + rnd.nextFloat() * 0.1f;
            p.life = p.max = 0.6f;
            p.color = rnd.nextBoolean() ? 0xFFC49BFF : 0xFFFF7AE0;
            p.kind = P_SPARK;
            add(p);
        }
        shake = Math.max(shake, 0.25f);
        if (vortexT <= 0) {
            explode(vortexX, vortexY, 6.5f, 38f);
            ring(vortexX, vortexY, 0xFFC49BFF, 7f);
        }
    }

    private void pull(Body body, float strength, Vec2 tmp) {
        Vec2 c = body.getWorldCenter();
        float dx = vortexX - c.x, dy = vortexY - c.y;
        float d = (float) Math.sqrt(dx * dx + dy * dy);
        if (d > 11f || d < 0.05f) return;
        float k = strength * body.getMass() / Math.max(1.2f, d) * (1f - d / 12f);
        tmp.set(dx / d * k - dy / d * k * 0.35f, dy / d * k + dx / d * k * 0.35f + body.getMass() * 4f);
        body.applyForceToCenter(tmp);
    }

    private void splat(float x, float y) {
        for (int i = 0; i < 34; i++) {
            Particle p = new Particle();
            float a = rnd.nextFloat() * 3.1416f, sp = 2f + rnd.nextFloat() * 8f;
            p.x = x; p.y = y;
            p.vx = (float) Math.cos(a) * sp;
            p.vy = (float) Math.sin(a) * sp;
            p.size = 0.1f + rnd.nextFloat() * 0.25f;
            p.life = p.max = 0.8f + rnd.nextFloat() * 0.8f;
            int r = rnd.nextInt(10);
            p.color = r < 6 ? 0xFFFF4D6A : (r < 8 ? 0xFF3FA34D : (r < 9 ? 0xFF1E1E1E : 0xFFFF8FA0));
            p.kind = P_JUICE;
            add(p);
        }
        fx.sound(Defs.S_SPLAT, 1f, 0.1f);
        shake = Math.max(shake, 0.5f);
    }

    // ------------------------------------------------------------------ particles

    private void chunk(float x, float y, int mat, float force) {
        Particle p = new Particle();
        float a = rnd.nextFloat() * 6.283f, sp = (1.5f + rnd.nextFloat() * 5f) * force;
        p.x = x + (rnd.nextFloat() - 0.5f) * 0.6f;
        p.y = y + (rnd.nextFloat() - 0.5f) * 0.6f;
        p.vx = (float) Math.cos(a) * sp;
        p.vy = (float) Math.sin(a) * sp + 2.5f;
        p.rot = rnd.nextFloat() * 360f;
        p.vr = (rnd.nextFloat() - 0.5f) * 900f;
        boolean shard = mat == Defs.GLASS || mat == Defs.ICE;
        p.size = shard ? 0.1f + rnd.nextFloat() * 0.22f : 0.08f + rnd.nextFloat() * 0.24f;
        p.life = p.max = 0.9f + rnd.nextFloat() * 1.0f;
        p.color = Defs.shade(Defs.MAT_COLOR[mat], 0.7f + rnd.nextFloat() * 0.6f);
        p.kind = shard ? P_SHARD : P_CHUNK;
        add(p);
    }

    private void dust(float x, float y, int color, float size) {
        Particle p = new Particle();
        float a = rnd.nextFloat() * 6.283f, sp = 0.4f + rnd.nextFloat() * 1.6f;
        p.x = x; p.y = y;
        p.vx = (float) Math.cos(a) * sp;
        p.vy = (float) Math.sin(a) * sp + 0.4f;
        p.size = size * (0.6f + rnd.nextFloat() * 0.6f);
        p.grow = size * 1.3f;
        p.life = p.max = 0.6f + rnd.nextFloat() * 0.6f;
        p.color = color;
        p.kind = P_DUST;
        add(p);
    }

    private void fire(float x, float y, float size, float speed) {
        Particle p = new Particle();
        float a = rnd.nextFloat() * 6.283f, sp = rnd.nextFloat() * speed;
        p.x = x + (rnd.nextFloat() - 0.5f) * 0.3f;
        p.y = y + (rnd.nextFloat() - 0.5f) * 0.3f;
        p.vx = (float) Math.cos(a) * sp;
        p.vy = (float) Math.sin(a) * sp + 1f;
        p.size = size * (0.6f + rnd.nextFloat() * 0.7f);
        p.grow = 1.0f;
        p.life = p.max = 0.35f + rnd.nextFloat() * 0.4f;
        int r = rnd.nextInt(3);
        p.color = r == 0 ? 0xFFFFB13B : (r == 1 ? 0xFFFF6A1F : 0xFFFFF0A0);
        p.kind = P_FIRE;
        add(p);
    }

    private void spark(float x, float y, int color, float speed) {
        Particle p = new Particle();
        float a = rnd.nextFloat() * 6.283f, sp = speed * (0.4f + rnd.nextFloat() * 0.8f);
        p.x = x; p.y = y;
        p.vx = (float) Math.cos(a) * sp;
        p.vy = (float) Math.sin(a) * sp;
        p.size = 0.06f;
        p.life = p.max = 0.3f + rnd.nextFloat() * 0.4f;
        p.color = color;
        p.kind = P_SPARK;
        add(p);
    }

    private void trail(float x, float y, int style) {
        Particle p = new Particle();
        p.x = x; p.y = y;
        p.size = style == 1 ? 0.16f : 0.3f;
        p.life = p.max = style == 1 ? 1.4f : 0.6f;
        p.color = style == 1 ? 0xFFFFFFFF : 0xFF7A6A6A;
        p.kind = P_TRAIL;
        add(p);
    }

    private void ring(float x, float y, int color, float r) {
        Particle p = new Particle();
        p.x = x; p.y = y;
        p.size = r * 0.2f;
        p.grow = r * 2.2f;
        p.life = p.max = 0.45f;
        p.color = color;
        p.kind = P_RING;
        add(p);
    }

    private void add(Particle p) {
        if (particles.size() < 800) particles.add(p);
    }

    private void updateParticles(float dt) {
        for (int i = particles.size() - 1; i >= 0; i--) {
            Particle p = particles.get(i);
            p.life -= dt;
            if (p.life <= 0) {
                int last = particles.size() - 1;
                particles.set(i, particles.get(last));
                particles.remove(last);
                continue;
            }
            switch (p.kind) {
                case P_CHUNK: case P_SHARD: case P_JUICE: case P_SPARK: case P_SNOW:
                    p.vy += GRAVITY * (p.kind == P_SNOW ? 0.4f : 1.2f) * dt;
                    break;
                case P_FIRE:
                    p.vx *= 1f - 3f * dt; p.vy *= 1f - 3f * dt; p.vy += 2f * dt;
                    break;
                case P_TRAIL: case P_GLOW: case P_RING:
                    break;
                default:
                    p.vx *= 1f - 1.5f * dt; p.vy *= 1f - 1.5f * dt; p.vy += 0.6f * dt;
            }
            p.x += p.vx * dt;
            p.y += p.vy * dt;
            p.rot += p.vr * dt;
            p.size += p.grow * dt;
            if (p.y < 0.04f && (p.kind == P_CHUNK || p.kind == P_SHARD || p.kind == P_JUICE || p.kind == P_SNOW)) {
                p.y = 0.04f;
                p.vy = -p.vy * 0.3f;
                p.vx *= 0.6f;
                p.vr *= 0.5f;
            }
        }
        for (int i = texts.size() - 1; i >= 0; i--) {
            FloatText t = texts.get(i);
            t.life -= dt;
            t.y += dt * 1.6f;
            if (t.life <= 0) texts.remove(i);
        }
        for (Block b : blocks) if (b.flash > 0) b.flash = Math.max(0, b.flash - dt * 4f);
    }

    // ------------------------------------------------------------------ state

    float destruction() {
        if (totalW <= 0) return 0;
        float d = destroyedW;
        for (Block b : blocks) {
            if ((b.flags & Defs.F_PROTECT) != 0 || b.mat == Defs.CROWN) continue;
            if (b.fragment) d += 0.5f * b.weight;
            else {
                Vec2 p = b.body.getPosition();
                float dx = p.x - b.x0 - (platform != null ? platform.getPosition().x - platformX0 : 0), dy = p.y - b.y0;
                float da = Math.abs(b.body.getAngle() - b.a0);
                if (dx * dx + dy * dy > 1.0f || da > 0.5f) d += 0.5f * b.weight;
            }
        }
        return Math.min(1f, d / totalW);
    }

    // ------------------------------------------------------------------ objectives

    int targetsDown() {
        int alive = 0;
        for (Block b : blocks) {
            if (b.dead || (b.flags & Defs.F_TARGET) == 0 || b.fragment) continue;
            Vec2 p = b.body.getPosition();
            if (p.y > b.y0 - 1.5f) alive++;
        }
        return targetsTotal - alive;
    }

    boolean crownDown() {
        if (crown == null) return false;
        if (crown.dead) return true;
        Vec2 p = crown.body.getPosition();
        return (p.y < crownY0 - 1.2f && p.y < 1.2f) || p.y < crownY0 - 3f;
    }

    float neighborIntegrity() {
        if (protectTotal <= 0) return 1f;
        float alive = 0;
        for (Block b : blocks) {
            if ((b.flags & Defs.F_PROTECT) == 0 || b.dead || b.fragment) continue;
            Vec2 p = b.body.getPosition();
            float dx = p.x - b.x0, dy = p.y - b.y0;
            if (dx * dx + dy * dy < 0.6f && Math.abs(b.body.getAngle() - b.a0) < 0.35f) alive += b.weight;
        }
        return Math.min(1f, alive / protectTotal);
    }

    float timeLeft() {
        if (def == null || def.objective != Defs.O_TIME) return 0;
        if (firstShotTime < 0) return def.timeLimit;
        return Math.max(0, def.timeLimit - (time - firstShotTime));
    }

    /** 1 = objective complete, 0 = still possible, -1 = failed. */
    int objectiveState() {
        if (def == null) return 0;
        float d = destruction();
        switch (def.objective) {
            case Defs.O_CROWN: return crownDown() ? 1 : 0;
            case Defs.O_TARGETS: return targetsDown() >= targetsTotal ? 1 : 0;
            case Defs.O_PROTECT:
                if (neighborIntegrity() < 0.7f) return -1;
                return d >= 0.5f ? 1 : 0;
            case Defs.O_TIME:
                if (d >= 0.6f) return 1;
                return firstShotTime >= 0 && timeLeft() <= 0 ? -1 : 0;
            case Defs.O_CORES: return coresLeft <= 0 ? 1 : 0;
            default: return d >= 0.5f ? 1 : 0;
        }
    }

    String objectiveProgress() {
        if (def == null) return "";
        switch (def.objective) {
            case Defs.O_CROWN: return crownDown() ? "CROWN DOWN!" : "KNOCK DOWN THE CROWN";
            case Defs.O_TARGETS: return "TARGETS " + targetsDown() + " / " + targetsTotal;
            case Defs.O_PROTECT: return "NEIGHBOR SAFE " + Math.round(neighborIntegrity() * 100) + "%";
            case Defs.O_TIME: return "60% IN " + (int) Math.ceil(timeLeft()) + "s";
            case Defs.O_CORES: return "CORES " + (coresTotal - coresLeft) + " / " + coresTotal;
            default: return "DESTROY 50%";
        }
    }

    boolean settled() {
        if (vortexT > 0 || !pendingBlasts.isEmpty()) return false;
        for (Block b : blocks) {
            if (!b.body.isAwake()) continue;
            Vec2 v = b.body.getLinearVelocity();
            if (v.x * v.x + v.y * v.y > 0.2f || Math.abs(b.body.getAngularVelocity()) > 0.4f) return false;
        }
        for (Shot s : shots) {
            if (s.gone || !s.body.isAwake()) continue;
            Vec2 v = s.body.getLinearVelocity();
            if (v.x * v.x + v.y * v.y > 0.3f) return false;
        }
        return true;
    }

    /** Position of the most interesting flying projectile, or null. */
    Shot activeShot() {
        Shot best = null;
        for (Shot s : shots) {
            if (s.gone || s.age > 4f) continue;
            if (best == null || s.age < best.age) best = s;
        }
        return best;
    }

    // ------------------------------------------------------------------ contacts

    @Override
    public void beginContact(Contact contact) {}

    @Override
    public void endContact(Contact contact) {}

    @Override
    public void preSolve(Contact c, Manifold oldManifold) {
        Manifold m = c.getManifold();
        if (m.pointCount == 0) return;
        Body ba = c.getFixtureA().getBody(), bb = c.getFixtureB().getBody();
        c.getWorldManifold(wm);
        float vn = 0, px = 0, py = 0;
        for (int i = 0; i < m.pointCount; i++) {
            Vec2 p = wm.points[i];
            Vec2 va = ba.getLinearVelocityFromWorldPoint(p);
            Vec2 vb = bb.getLinearVelocityFromWorldPoint(p);
            float d = (vb.x - va.x) * wm.normal.x + (vb.y - va.y) * wm.normal.y;
            if (d < vn) { vn = d; px = p.x; py = p.y; }
        }
        if (vn > -1.4f) return;
        float ma = ba.getMass(), mb = bb.getMass();
        float me = ma == 0 ? mb : (mb == 0 ? ma : ma * mb / (ma + mb));
        float e = 0.5f * me * vn * vn;
        Object ua = ba.getUserData(), ub = bb.getUserData();
        hit(ua, ub, e);
        hit(ub, ua, e);
        if (e > 25f && impactCount < 8) {
            impacts[impactCount * 3] = px;
            impacts[impactCount * 3 + 1] = py;
            impacts[impactCount * 3 + 2] = e;
            impactCount++;
        }
    }

    private void hit(Object self, Object other, float e) {
        if (self instanceof Block) {
            Block b = (Block) self;
            if (time < 0.4f) return;
            b.pendingDmg += e * DAMAGE_K * (other instanceof Shot ? 1.25f * dmgBoost * (((Shot) other).blasted ? 2.2f : 1f) : 1f) * (b.frozen ? 1.6f : 1f) * Defs.MAT_IMPACT[b.mat];
            if (b.mat == Defs.RUBBER && e > 20 && other instanceof Shot) fx.sound(Defs.S_BOING, Math.min(1f, e / 200f), 0.15f);
        } else if (self instanceof Shot) {
            ((Shot) self).stepE += e;
        }
    }

    @Override
    public void postSolve(Contact contact, ContactImpulse impulse) {}

    static float clamp(float v, float a, float b) {
        return v < a ? a : (v > b ? b : v);
    }
}
