package com.slingsmash.game;

import java.util.Random;

/** Procedural buildings for Endless mode and the Daily Challenge. Only uses stable building patterns. */
final class Gen {
    private Gen() {}

    private static final String[] PREFIX = {"Wobbly", "Grand", "Crooked", "Mighty", "Tiny", "Secret", "Haunted", "Royal",
            "Rusty", "Shiny", "Lonely", "Crazy", "Ancient", "Neon", "Frosty", "Burning"};
    private static final String[] NOUN = {"Tower", "Fortress", "Mansion", "Warehouse", "Temple", "Palace", "Outpost",
            "Factory", "Citadel", "Bunker", "Castle", "Hotel", "Lighthouse", "Barn", "Arcade", "Keep"};

    /** d = difficulty, 0 (easy) .. 1.5 (brutal). */
    static Defs.LevelDef make(long seed, float d, boolean daily) {
        Random r = new Random(seed * 2654435761L + 17);
        int theme = r.nextInt(Defs.NUM_THEMES);
        Defs.B b = new Defs.B();
        int[] soft = {Defs.WOOD, Defs.GLASS, Defs.ICE, Defs.BRICK};
        int[] hard = {Defs.STONE, Defs.CONCRETE, Defs.STEEL, Defs.BRICK};
        float x = 24f + r.nextFloat() * 1.5f;
        float bestTop = -1, crownX = 0;
        int structures = 0;
        while (x < 40f && structures < 3) {
            float room = 44.5f - x;
            int kind = r.nextInt(5);
            int wall = r.nextFloat() < 0.35f + d * 0.4f ? hard[r.nextInt(hard.length)] : soft[r.nextInt(soft.length)];
            int slab = r.nextFloat() < 0.3f + d * 0.4f ? hard[r.nextInt(hard.length)] : Defs.WOOD;
            float top, w, cx;
            switch (kind) {
                case 0: { // stacked storeys
                    w = Math.min(room, 3.5f + r.nextFloat() * 3f);
                    int floors = 2 + r.nextInt(2 + (int) (d * 3));
                    float y = 0, ww = w;
                    for (int i = 0; i < floors; i++) {
                        float xx = x + (w - ww) / 2;
                        y = b.storey(xx, y, ww, 1.8f + r.nextFloat() * 0.8f, 0.35f + r.nextFloat() * 0.2f, wall, slab);
                        if (r.nextFloat() < 0.4f) ww = Math.max(2.4f, ww - 0.8f);
                    }
                    top = y;
                    cx = x + w / 2;
                    if (r.nextFloat() < 0.3f) b.box(x + w / 2 - 0.5f, 0, 1.0f, 0.9f, Defs.TNT);
                    break;
                }
                case 1: { // glass / fill floors
                    w = Math.min(room, 5f + r.nextFloat() * 3f);
                    int floors = 2 + r.nextInt(2 + (int) (d * 4));
                    int fill = r.nextFloat() < 0.6f ? Defs.GLASS : (r.nextFloat() < 0.5f ? Defs.ICE : Defs.CRYSTAL);
                    int col = r.nextFloat() < 0.15f * d ? Defs.RUBBER : (r.nextFloat() < 0.5f ? Defs.STEEL : Defs.CONCRETE);
                    float y = 0;
                    for (int i = 0; i < floors; i++) y = b.fillFloor(x, y, w, 2.1f, 0.4f, 3, col, fill, slab == Defs.WOOD ? Defs.CONCRETE : slab, 0.35f);
                    top = y;
                    cx = x + w / 2;
                    break;
                }
                case 2: { // pyramid
                    int rows = Math.min(3 + r.nextInt(3 + (int) (d * 2)), (int) (room / 1.2f));
                    if (rows < 2) rows = 2;
                    w = rows * 1.2f;
                    top = b.pyramid(x, 0, rows, 1.2f, 0.9f, r.nextFloat() < 0.5f ? Defs.STONE : Defs.BRICK);
                    cx = x + (rows - 1) * 0.6f + 0.6f;
                    break;
                }
                case 3: { // columns
                    int n = 2 + r.nextInt(3);
                    w = Math.min(room, n * 1.4f);
                    n = Math.max(1, (int) (w / 1.4f));
                    float first = 0;
                    for (int i = 0; i < n; i++) {
                        int h = 2 + r.nextInt(3 + (int) (d * 4));
                        float t = b.column(x + i * 1.4f, 0, 1.2f, 1.0f, h, i % 2 == 0 ? wall : slab);
                        if (i == 0) first = t;
                    }
                    top = first;
                    cx = x + 0.6f;
                    break;
                }
                default: { // castle wall with towers
                    w = Math.min(room, 6f + r.nextFloat() * 2f);
                    int h = 4 + r.nextInt(2 + (int) (d * 2));
                    float tw = 1.6f;
                    float tt = b.column(x, 0, tw, 1.0f, h, Defs.STONE);
                    b.column(x + w - tw, 0, tw, 1.0f, h, Defs.STONE);
                    int rows = Math.max(2, h - 2);
                    for (int row = 0; row < rows; row++) {
                        float xx = x + tw, y = row * 0.8f;
                        if (row % 2 == 1) { b.box(xx, y, 0.5f, 0.8f, Defs.STONE); xx += 0.5f; }
                        while (xx < x + w - tw - 0.01f) {
                            float bw = Math.min(1.0f, x + w - tw - xx);
                            b.box(xx, y, bw, 0.8f, row == 0 && r.nextFloat() < 0.15f ? Defs.TNT : (r.nextFloat() < 0.2f ? Defs.WOOD : Defs.STONE));
                            xx += bw;
                        }
                    }
                    top = tt;
                    cx = x + tw / 2;
                }
            }
            if (top > bestTop) { bestTop = top; crownX = cx; }
            if (r.nextFloat() < 0.35f && top < 12) b.box(cx - 0.4f, top, 0.8f, 0.5f, Defs.GOLD);
            x += w + 1.0f + r.nextFloat() * 1.5f;
            structures++;
        }
        int objective;
        float o = r.nextFloat();
        boolean hasGoldOnBest = false;
        for (Defs.Spec s : b.s) if (s.mat == Defs.GOLD && Math.abs(s.x - crownX) < 0.5f) hasGoldOnBest = true;
        if (o < 0.25f && !hasGoldOnBest) {
            objective = Defs.O_CROWN;
            b.crown(crownX, bestTop);
        } else if (o < 0.5f && b.s.size() > 6) {
            objective = Defs.O_TARGETS;
            for (int i = 0; i < 3; i++) b.s.get(r.nextInt(b.s.size())).flags |= Defs.F_TARGET;
        } else if (o < 0.62f) {
            objective = Defs.O_PROTECT;
            b.neighbor(15.8f);
        } else objective = Defs.O_DESTROY;
        String name = PREFIX[r.nextInt(PREFIX.length)] + " " + NOUN[r.nextInt(NOUN.length)];
        int shots = daily ? 5 : 4;
        Defs.LevelDef L = new Defs.LevelDef(name, theme, shots, b.s);
        if (objective != Defs.O_DESTROY) L.obj(objective);
        L.par(Math.max(2, shots - 2));
        if (r.nextFloat() < 0.25f + d * 0.3f) L.wind((r.nextFloat() - 0.5f) * (2f + d * 5f));
        if (d > 0.6f && r.nextFloat() < 0.25f) L.quake(9f + r.nextFloat() * 4f);
        return L;
    }
}
