package com.slingsmash.game;

import java.util.ArrayList;

/** A planned combo: launches and fuses scheduled on exact physics steps, so a plan always replays the same way. */
final class Plan {
    static final class Step {
        int ammo;
        float px = GameWorld.POUCH_X, py = GameWorld.POUCH_Y, vx, vy;
        int delayMs, fuseMs = 1200;
        GameWorld.Shot shot;
        boolean fired, fused;

        Step copy() {
            Step s = new Step();
            s.ammo = ammo;
            s.px = px;
            s.py = py;
            s.vx = vx;
            s.vy = vy;
            s.delayMs = delayMs;
            s.fuseMs = fuseMs;
            return s;
        }
    }

    interface Listener {
        void launched(Step s);

        void finished();
    }

    final ArrayList<Step> steps = new ArrayList<>();
    boolean running;
    private int start;

    static int ticks(int ms) {
        return Math.round(ms * 0.06f);
    }

    int launchTick(int i) {
        int t = 0;
        for (int j = 1; j <= i; j++) t += ticks(steps.get(j).delayMs);
        return t;
    }

    void begin(int startStep) {
        start = startStep;
        running = true;
        for (Step s : steps) {
            s.shot = null;
            s.fired = s.fused = false;
        }
    }

    /** Called from {@link GameWorld.StepHook}. */
    void onStep(GameWorld g, int step, Listener l) {
        if (!running) return;
        int rel = step - start;
        boolean pending = false;
        for (int i = 0; i < steps.size(); i++) {
            Step st = steps.get(i);
            int lt = launchTick(i);
            if (!st.fired) {
                if (rel >= lt) {
                    st.fired = true;
                    st.shot = g.launch(st.ammo, st.px, st.py, st.vx, st.vy);
                    if (l != null) l.launched(st);
                } else pending = true;
            }
            if (st.fired && !st.fused && Defs.tappable(st.ammo)) {
                if (rel >= lt + ticks(st.fuseMs)) {
                    st.fused = true;
                    g.triggerShot(st.shot);
                } else if (st.shot != null && !st.shot.gone) pending = true;
                else st.fused = true;
            }
        }
        if (!pending) {
            running = false;
            if (l != null) l.finished();
        }
    }

    /** Encodes as ammo, px, py, vx, vy, delayMs, fuseMs per step. */
    float[] encode() {
        float[] f = new float[steps.size() * 7];
        for (int i = 0; i < steps.size(); i++) {
            Step s = steps.get(i);
            int o = i * 7;
            f[o] = s.ammo;
            f[o + 1] = s.px;
            f[o + 2] = s.py;
            f[o + 3] = s.vx;
            f[o + 4] = s.vy;
            f[o + 5] = s.delayMs;
            f[o + 6] = s.fuseMs;
        }
        return f;
    }

    static ArrayList<Step> decode(float[] f) {
        ArrayList<Step> l = new ArrayList<>();
        if (f == null) return l;
        for (int o = 0; o + 6 < f.length; o += 7) {
            Step s = new Step();
            s.ammo = (int) f[o];
            s.px = f[o + 1];
            s.py = f[o + 2];
            s.vx = f[o + 3];
            s.vy = f[o + 4];
            s.delayMs = (int) f[o + 5];
            s.fuseMs = (int) f[o + 6];
            l.add(s);
        }
        return l;
    }
}
