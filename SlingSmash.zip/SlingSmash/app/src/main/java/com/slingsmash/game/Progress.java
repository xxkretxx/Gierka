package com.slingsmash.game;

import android.content.SharedPreferences;

import java.util.Calendar;
import java.util.Random;

/** All saved progress: coins, stars, unlocks, upgrades, skins, missions, stats, saves. */
final class Progress {
    final SharedPreferences p;
    private final Random rnd = new Random();

    static final int UPG_POWER = 0, UPG_AIM = 1, UPG_SHOT = 2;
    static final String[] UPG_NAME = {"Slingshot Power", "Aim Guide", "Extra Shot"};
    static final String[] UPG_DESC = {"+15% damage on every impact", "Longer trajectory preview", "+1 shot on every level"};
    static final int[] UPG_MAX = {3, 3, 2};
    static final int[][] UPG_COST = {{800, 1600, 3000}, {400, 900, 1800}, {2000, 4000}};
    static final int[] AIM_DOTS = {9, 14, 20, 28};

    // ---------------------------------------------------------------- missions
    static final int M_COUNT = 0, M_REACH = 1;
    static final String[] M_KEY = {"glass", "wood", "stone", "steel", "explosions", "combo", "threestar", "crowns", "bosses",
            "wave", "daily", "cows", "frozen", "gold", "shots", "earned", "versus", "built", "targets", "special"};
    static final int[] M_TYPE = {M_COUNT, M_COUNT, M_COUNT, M_COUNT, M_COUNT, M_REACH, M_COUNT, M_COUNT, M_COUNT,
            M_REACH, M_COUNT, M_COUNT, M_COUNT, M_COUNT, M_COUNT, M_COUNT, M_COUNT, M_COUNT, M_COUNT, M_COUNT};
    static final int[] M_BASE = {60, 80, 50, 15, 10, 12, 3, 2, 1, 4, 1, 5, 20, 5, 40, 800, 1, 1, 10, 8};
    static final String[] M_TEXT = {"Smash %d glass blocks", "Smash %d wooden blocks", "Smash %d stone or brick blocks",
            "Destroy %d steel blocks", "Cause %d explosions", "Reach a COMBO of x%d", "Get 3 stars on %d levels",
            "Knock down %d crowns", "Defeat %d boss", "Reach wave %d in Endless", "Complete %d Daily Challenge",
            "Launch %d cows", "Freeze %d blocks", "Smash %d gold bars", "Fire %d shots", "Earn %d coins",
            "Play %d Versus match", "Build & test %d buildings", "Destroy %d targets", "Use %d special projectiles"};

    static final class Reward {
        int coins, skin = -1, ammo = -1;
    }

    Progress(SharedPreferences p) {
        this.p = p;
        if (!p.contains("coins")) p.edit().putInt("coins", 500).apply();
        migrate();
        for (int i = 0; i < 3; i++) if (getI("m" + i + "k", -1) < 0) newMission(i);
    }

    private int getI(String k, int d) { return p.getInt(k, d); }

    private void putI(String k, int v) { p.edit().putInt(k, v).apply(); }

    /** v1 had 8 levels per world; v2 has 9 (boss added). */
    private void migrate() {
        if (p.getInt("ver", 1) >= 3) return;
        SharedPreferences.Editor e = p.edit();
        int[] st = new int[40], be = new int[40];
        for (int i = 0; i < 40; i++) { st[i] = p.getInt("stars" + i, 0); be[i] = p.getInt("best" + i, 0); }
        for (int i = 0; i < 45; i++) { e.putInt("stars" + i, 0); e.putInt("best" + i, 0); }
        for (int i = 0; i < 40; i++) {
            int n = (i / 8) * 9 + i % 8;
            // old stars were much easier: keep at most 2
            e.putInt("stars" + n, Math.min(2, st[i]));
            e.putInt("best" + n, be[i]);
        }
        e.putInt("ver", 3);
        e.apply();
    }

    // ---------------------------------------------------------------- coins
    int coins() { return getI("coins", 0); }

    void addCoins(int n) {
        putI("coins", coins() + n);
        if (n > 0) addStat("earned", n);
    }

    boolean spend(int n) {
        if (coins() < n) return false;
        putI("coins", coins() - n);
        return true;
    }

    // ---------------------------------------------------------------- ammo
    boolean owned(int t) {
        return Defs.AMMO_PRICE[t] == 0 || p.getString("owned", ",").contains("," + t + ",");
    }

    void unlockAmmo(int t) {
        if (owned(t)) return;
        String s = p.getString("owned", ",");
        if (!s.startsWith(",")) s = "," + s;
        if (!s.endsWith(",")) s = s + ",";
        p.edit().putString("owned", s + t + ",").apply();
    }

    /** Premium projectiles can be fired a limited number of times per level. */
    int usesPerLevel(int t) {
        if (Defs.AMMO_PRICE[t] == 0) return 99;
        return 1 + getI("au" + t, 0);
    }

    int ammoUpg(int t) { return getI("au" + t, 0); }

    int ammoUpgCost(int t) { return Defs.AMMO_PRICE[t] / 2 * (ammoUpg(t) + 1); }

    void incAmmoUpg(int t) { putI("au" + t, ammoUpg(t) + 1); }

    // ---------------------------------------------------------------- upgrades
    int upg(int i) { return getI("upg" + i, 0); }

    void incUpg(int i) { putI("upg" + i, upg(i) + 1); }

    int upgCost(int i) { return upg(i) >= UPG_MAX[i] ? -1 : UPG_COST[i][upg(i)]; }

    // ---------------------------------------------------------------- stars / unlocks
    int stars(int lvl) { return getI("stars" + lvl, 0); }

    int best(int lvl) { return getI("best" + lvl, 0); }

    void setResult(int lvl, int stars, int score) {
        SharedPreferences.Editor e = p.edit();
        if (stars > stars(lvl)) {
            if (stars == 3) addStat("threestar", 1);
            e.putInt("stars" + lvl, stars);
        }
        if (score > best(lvl)) e.putInt("best" + lvl, score);
        e.apply();
    }

    int worldStars(int w) {
        int s = 0;
        for (int i = 0; i < Defs.LEVELS_PER_WORLD; i++) s += stars(w * Defs.LEVELS_PER_WORLD + i);
        return s;
    }

    int totalStars() {
        int s = 0;
        for (int i = 0; i < Defs.LEVELS.length; i++) s += stars(i);
        return s;
    }

    boolean worldUnlocked(int w) { return totalStars() >= Defs.WORLD_REQ[w]; }

    boolean levelUnlocked(int lvl) {
        int w = Defs.worldOf(lvl);
        if (!worldUnlocked(w)) return false;
        return lvl % Defs.LEVELS_PER_WORLD == 0 || stars(lvl - 1) > 0;
    }

    // ---------------------------------------------------------------- skins
    boolean skinOwned(int i) { return i == 0 || p.getBoolean("skin" + i, false); }

    void unlockSkin(int i) { p.edit().putBoolean("skin" + i, true).apply(); }

    /** -1 = automatic (world skin when unlocked). */
    int skinChoice() { return getI("skinsel", -1); }

    void setSkinChoice(int i) { putI("skinsel", i); }

    int skinFor(int world) {
        int c = skinChoice();
        if (c >= 0 && skinOwned(c)) return c;
        int ws = world >= 1 && world <= 4 ? world : 0;
        return skinOwned(ws) ? ws : 0;
    }

    // ---------------------------------------------------------------- stats
    int stat(String k) { return getI("st_" + k, 0); }

    void addStat(String k, int n) {
        if (n == 0) return;
        putI("st_" + k, stat(k) + n);
    }

    void reach(String k, int v) {
        for (int i = 0; i < 3; i++) {
            int mk = getI("m" + i + "k", -1);
            if (mk >= 0 && M_KEY[mk].equals(k) && v > getI("m" + i + "v", 0)) putI("m" + i + "v", v);
        }
        if (v > stat("max_" + k)) putI("st_max_" + k, v);
    }

    // ---------------------------------------------------------------- missions
    private void newMission(int slot) {
        int done = getI("mdone", 0);
        int ptr = getI("mptr", rnd.nextInt(M_KEY.length));
        int k;
        int guard = 0;
        do {
            k = ptr % M_KEY.length;
            ptr += 1 + rnd.nextInt(3);
            guard++;
        } while ((k == getI("m" + ((slot + 1) % 3) + "k", -2) || k == getI("m" + ((slot + 2) % 3) + "k", -2)) && guard < 50);
        int tier = done / 3;
        int target = Math.round(M_BASE[k] * (1f + tier * 0.6f));
        if (M_TYPE[k] == M_REACH && k == 5) target = M_BASE[k] + tier * 4;
        if (M_TYPE[k] == M_REACH && k == 9) target = M_BASE[k] + tier * 2;
        if (k == 8 || k == 10 || k == 16 || k == 17) target = 1 + tier / 2;
        SharedPreferences.Editor e = p.edit();
        e.putInt("mptr", ptr);
        e.putInt("m" + slot + "k", k);
        e.putInt("m" + slot + "t", target);
        e.putInt("m" + slot + "b", stat(M_KEY[k]));
        e.putInt("m" + slot + "v", 0);
        e.putInt("m" + slot + "tier", tier);
        e.apply();
    }

    String missionText(int slot) {
        int k = getI("m" + slot + "k", 0);
        return String.format(java.util.Locale.US, M_TEXT[k], getI("m" + slot + "t", 1));
    }

    int missionTarget(int slot) { return getI("m" + slot + "t", 1); }

    int missionProgress(int slot) {
        int k = getI("m" + slot + "k", 0);
        if (M_TYPE[k] == M_REACH) return Math.min(missionTarget(slot), getI("m" + slot + "v", 0));
        return Math.min(missionTarget(slot), stat(M_KEY[k]) - getI("m" + slot + "b", 0));
    }

    boolean missionDone(int slot) { return missionProgress(slot) >= missionTarget(slot); }

    int missionsReady() {
        int n = 0;
        for (int i = 0; i < 3; i++) if (missionDone(i)) n++;
        return n;
    }

    Reward claimMission(int slot) {
        if (!missionDone(slot)) return null;
        int tier = getI("m" + slot + "tier", 0);
        putI("mdone", getI("mdone", 0) + 1);
        newMission(slot);
        return openChest(tier);
    }

    Reward openChest(int tier) {
        Reward r = new Reward();
        r.coins = 150 + tier * 80 + rnd.nextInt(101);
        float roll = rnd.nextFloat();
        if (roll < 0.35f) {
            int[] chestSkins = {5, 6, 7};
            int start = rnd.nextInt(3);
            for (int i = 0; i < 3; i++) {
                int s = chestSkins[(start + i) % 3];
                if (!skinOwned(s)) { r.skin = s; unlockSkin(s); break; }
            }
        }
        if (r.skin < 0 && roll < 0.6f) {
            int start = rnd.nextInt(Defs.NUM_AMMO);
            for (int i = 0; i < Defs.NUM_AMMO; i++) {
                int t = (start + i) % Defs.NUM_AMMO;
                if (!owned(t) && Defs.AMMO_PRICE[t] <= 3500) { r.ammo = t; unlockAmmo(t); break; }
            }
        }
        if (r.skin < 0 && r.ammo < 0) r.coins += 200;
        addCoins(r.coins);
        return r;
    }

    // ---------------------------------------------------------------- daily / endless
    static int today() {
        Calendar c = Calendar.getInstance();
        return c.get(Calendar.YEAR) * 10000 + (c.get(Calendar.MONTH) + 1) * 100 + c.get(Calendar.DAY_OF_MONTH);
    }

    int dailyBest() { return getI("daily_day", 0) == today() ? getI("daily_best", 0) : 0; }

    boolean dailyRewardClaimed() { return getI("daily_claim", 0) == today(); }

    /** Returns true if the first-clear reward of the day should be given. */
    boolean setDaily(int score, boolean cleared) {
        SharedPreferences.Editor e = p.edit();
        if (getI("daily_day", 0) != today()) { e.putInt("daily_day", today()); e.putInt("daily_best", 0); }
        if (score > dailyBest()) e.putInt("daily_best", score);
        boolean reward = cleared && !dailyRewardClaimed();
        if (reward) e.putInt("daily_claim", today());
        e.apply();
        if (reward) addStat("daily", 1);
        return reward;
    }

    int endlessBest() { return getI("endless_best", 0); }

    int endlessBestWave() { return getI("endless_wave", 0); }

    void setEndless(int score, int wave) {
        SharedPreferences.Editor e = p.edit();
        if (score > endlessBest()) e.putInt("endless_best", score);
        if (wave > endlessBestWave()) e.putInt("endless_wave", wave);
        e.apply();
    }

    // ---------------------------------------------------------------- builder saves
    String save(int slot) { return p.getString("build" + slot, ""); }

    void setSave(int slot, String code) { p.edit().putString("build" + slot, code).apply(); }

    boolean bool(String k, boolean d) { return p.getBoolean(k, d); }

    void setBool(String k, boolean v) { p.edit().putBoolean(k, v).apply(); }
}
