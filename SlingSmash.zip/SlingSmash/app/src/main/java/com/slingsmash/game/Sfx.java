package com.slingsmash.game;

import android.content.Context;
import android.media.AudioAttributes;
import android.media.SoundPool;
import android.os.SystemClock;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Random;

/** All sound effects are synthesised at start-up, so the game needs no audio files. */
final class Sfx {
    private static final int RATE = 22050;
    private final SoundPool pool;
    private final int[] ids = new int[Defs.NUM_SOUNDS];
    private final long[] last = new long[Defs.NUM_SOUNDS];
    private final Random rnd = new Random();
    volatile boolean muted;

    Sfx(final Context ctx) {
        AudioAttributes aa = new AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_GAME)
                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                .build();
        pool = new SoundPool.Builder().setMaxStreams(14).setAudioAttributes(aa).build();
        final File dir = ctx.getCacheDir();
        new Thread(new Runnable() {
            @Override
            public void run() {
                Random r = new Random(42);
                for (int i = 0; i < Defs.NUM_SOUNDS; i++) {
                    try {
                        File f = new File(dir, "sfx_v2_" + i + ".wav");
                        if (!f.exists()) writeWav(f, synth(i, r));
                        ids[i] = pool.load(f.getAbsolutePath(), 1);
                    } catch (Exception ignored) {
                    }
                }
            }
        }).start();
    }

    void play(int id, float vol, float pitchVar) {
        if (muted || id < 0 || id >= ids.length || ids[id] == 0) return;
        long now = SystemClock.uptimeMillis();
        if (now - last[id] < 55) return;
        last[id] = now;
        float rate = 1f + (rnd.nextFloat() * 2f - 1f) * pitchVar;
        rate = Math.max(0.5f, Math.min(2f, rate));
        vol = Math.max(0f, Math.min(1f, vol));
        pool.play(ids[id], vol, vol, 1, 0, rate);
    }

    void release() {
        pool.release();
    }

    // ---------------------------------------------------------------- synthesis

    private static float[] synth(int id, Random r) {
        switch (id) {
            case Defs.S_LAUNCH: {
                float[] b = buf(0.45f);
                float lp = 0, lp2 = 0;
                for (int i = 0; i < b.length; i++) {
                    float t = i / (float) b.length;
                    float fc = 300 + 2600 * t * (1 - t) * 4;
                    float a = a(fc);
                    lp += a * (noise(r) - lp);
                    lp2 += a * 0.5f * (lp - lp2);
                    float env = (float) Math.pow(Math.sin(Math.PI * t), 1.5);
                    b[i] = (lp - lp2 * 0.5f) * env;
                }
                return norm(b, 0.85f);
            }
            case Defs.S_WOOD: {
                float[] b = buf(0.4f);
                float lp = 0;
                double ph = 0;
                for (int i = 0; i < b.length; i++) {
                    float t = i / (float) RATE;
                    float f = 160 - 90 * Math.min(1, t * 8);
                    ph += 2 * Math.PI * f / RATE;
                    float thump = (float) Math.sin(ph) * (float) Math.exp(-t * 22);
                    float n = r.nextFloat() < 0.08f * (float) Math.exp(-t * 10) ? noise(r) * 3 : noise(r) * 0.2f;
                    lp += a(2200) * (n - lp);
                    b[i] = thump * 0.9f + lp * (float) Math.exp(-t * 9);
                }
                return norm(b, 0.9f);
            }
            case Defs.S_GLASS: {
                float[] b = buf(0.7f);
                float lp = 0;
                for (int i = 0; i < b.length; i++) {
                    float t = i / (float) RATE;
                    float n = noise(r);
                    lp += a(1800) * (n - lp);
                    b[i] = (n - lp) * 0.6f * (float) Math.exp(-t * 14);
                }
                for (int k = 0; k < 9; k++) {
                    float f = 2400 + r.nextFloat() * 4200, st = r.nextFloat() * 0.18f, amp = 0.15f + r.nextFloat() * 0.2f;
                    int s0 = (int) (st * RATE);
                    for (int i = s0; i < b.length; i++) {
                        float t = (i - s0) / (float) RATE;
                        b[i] += amp * (float) Math.sin(2 * Math.PI * f * t) * (float) Math.exp(-t * 18);
                    }
                }
                return norm(b, 0.8f);
            }
            case Defs.S_STONE: {
                float[] b = buf(0.6f);
                float lp = 0, lp2 = 0;
                double ph = 0;
                for (int i = 0; i < b.length; i++) {
                    float t = i / (float) RATE;
                    lp += a(700) * (noise(r) - lp);
                    lp2 += a(260) * (noise(r) - lp2);
                    ph += 2 * Math.PI * (70 - 30 * Math.min(1, t * 5)) / RATE;
                    b[i] = lp * (float) Math.exp(-t * 8) * 1.4f + lp2 * (float) Math.exp(-t * 4) * 1.6f
                            + (float) Math.sin(ph) * (float) Math.exp(-t * 16) * 0.8f;
                }
                return norm(b, 0.9f);
            }
            case Defs.S_METAL: {
                float[] b = buf(0.9f);
                float[] fr = {523, 1307, 2071, 2967, 3810};
                float[] dc = {4, 6, 8, 11, 15};
                float[] am = {0.5f, 0.35f, 0.25f, 0.15f, 0.1f};
                for (int i = 0; i < b.length; i++) {
                    float t = i / (float) RATE, v = 0;
                    for (int k = 0; k < fr.length; k++)
                        v += am[k] * (float) Math.sin(2 * Math.PI * fr[k] * t) * (float) Math.exp(-t * dc[k]);
                    v += noise(r) * 0.4f * (float) Math.exp(-t * 60);
                    b[i] = v;
                }
                return norm(b, 0.75f);
            }
            case Defs.S_BOOM: {
                float[] b = buf(1.6f);
                float lp = 0, lp2 = 0;
                double ph = 0;
                for (int i = 0; i < b.length; i++) {
                    float t = i / (float) RATE;
                    lp += a(900 * (float) Math.exp(-t * 2) + 120) * (noise(r) - lp);
                    lp2 += a(90) * (noise(r) - lp2);
                    ph += 2 * Math.PI * (60 - 30 * Math.min(1, t * 3)) / RATE;
                    float v = lp * 1.5f * (float) Math.exp(-t * 3) + lp2 * 4f * (float) Math.exp(-t * 2)
                            + (float) Math.sin(ph) * 0.9f * (float) Math.exp(-t * 6);
                    b[i] = (float) Math.tanh(v * 1.8f);
                }
                return norm(b, 0.95f);
            }
            case Defs.S_PIANO: {
                float[] b = buf(2.0f);
                float[] notes = {130.81f, 155.56f, 185.0f, 207.65f, 246.94f, 277.18f};
                for (float f : notes) {
                    for (int h = 1; h <= 4; h++) {
                        float amp = 0.3f / h;
                        float detune = 1 + (r.nextFloat() - 0.5f) * 0.004f;
                        for (int i = 0; i < b.length; i++) {
                            float t = i / (float) RATE;
                            b[i] += amp * (float) Math.sin(2 * Math.PI * f * h * detune * t)
                                    * (float) Math.exp(-t * (1.6f + h * 0.8f)) * Math.min(1, t * 400);
                        }
                    }
                }
                float lp = 0;
                for (int i = 0; i < b.length; i++) {
                    float t = i / (float) RATE;
                    lp += a(300) * (noise(r) - lp);
                    b[i] += lp * 3f * (float) Math.exp(-t * 12);
                }
                return norm(b, 0.9f);
            }
            case Defs.S_SPLAT: {
                float[] b = buf(0.45f);
                float lp = 0;
                double ph = 0;
                for (int i = 0; i < b.length; i++) {
                    float t = i / (float) RATE;
                    lp += a(1100) * (noise(r) - lp);
                    ph += 2 * Math.PI * (320 * Math.exp(-t * 9) + 60) / RATE;
                    b[i] = lp * 1.5f * (float) Math.exp(-t * 11) + (float) Math.sin(ph) * 0.7f * (float) Math.exp(-t * 14);
                }
                return norm(b, 0.9f);
            }
            case Defs.S_CLICK: {
                float[] b = buf(0.07f);
                for (int i = 0; i < b.length; i++) {
                    float t = i / (float) RATE, k = 1 - i / (float) b.length;
                    b[i] = (float) Math.sin(2 * Math.PI * (1200 - 500 * (1 - k)) * t) * k * k;
                }
                return norm(b, 0.6f);
            }
            case Defs.S_STAR: {
                float[] b = buf(0.9f);
                for (int i = 0; i < b.length; i++) {
                    float t = i / (float) RATE;
                    float env = (float) Math.exp(-t * 4.5f) * Math.min(1, t * 300);
                    b[i] = env * ((float) Math.sin(2 * Math.PI * 1568 * t) + 0.4f * (float) Math.sin(2 * Math.PI * 3136 * t)
                            + 0.2f * (float) Math.sin(2 * Math.PI * 2349 * t));
                }
                return norm(b, 0.7f);
            }
            case Defs.S_THUD: {
                float[] b = buf(0.22f);
                float lp = 0;
                double ph = 0;
                for (int i = 0; i < b.length; i++) {
                    float t = i / (float) RATE;
                    ph += 2 * Math.PI * (120 - 55 * Math.min(1, t * 10)) / RATE;
                    lp += a(500) * (noise(r) - lp);
                    b[i] = (float) Math.sin(ph) * (float) Math.exp(-t * 26) + lp * 1.5f * (float) Math.exp(-t * 35);
                }
                return norm(b, 0.9f);
            }
            case Defs.S_WIN: {
                float[] b = buf(1.3f);
                float[] notes = {523.25f, 659.25f, 783.99f, 1046.5f};
                for (int n = 0; n < notes.length; n++) {
                    int s0 = (int) (n * 0.13f * RATE);
                    for (int i = s0; i < b.length; i++) {
                        float t = (i - s0) / (float) RATE;
                        float env = (float) Math.exp(-t * (n == 3 ? 2.5f : 6f)) * Math.min(1, t * 200);
                        double w = 2 * Math.PI * notes[n] * t;
                        b[i] += env * (float) (Math.sin(w) + 0.3 * Math.sin(3 * w) + 0.15 * Math.sin(5 * w)) * 0.5f;
                    }
                }
                return norm(b, 0.75f);
            }
            case Defs.S_STRETCH: {
                float[] b = buf(0.3f);
                double ph = 0;
                float lp = 0;
                for (int i = 0; i < b.length; i++) {
                    float t = i / (float) b.length;
                    ph += (80 + 70 * t) / RATE;
                    float saw = (float) (2 * (ph - Math.floor(ph)) - 1);
                    lp += a(900) * (saw - lp);
                    b[i] = lp * (float) Math.sin(Math.PI * t);
                }
                return norm(b, 0.35f);
            }
            case Defs.S_HONK: {
                float[] b = buf(0.45f);
                for (int i = 0; i < b.length; i++) {
                    float t = i / (float) RATE;
                    float env = Math.min(1, t * 80) * Math.min(1, (0.45f - t) * 20);
                    double ph1 = 2 * Math.PI * 392 * t, ph2 = 2 * Math.PI * 494 * t;
                    float v = (float) (Math.signum(Math.sin(ph1)) * 0.5 + Math.signum(Math.sin(ph2)) * 0.5);
                    b[i] = v * env;
                }
                float lp = 0;
                for (int i = 0; i < b.length; i++) {
                    lp += a(1600) * (b[i] - lp);
                    b[i] = lp;
                }
                return norm(b, 0.55f);
            }
        }
        return buf(0.05f);
    }

    private static float[] buf(float sec) {
        return new float[(int) (sec * RATE)];
    }

    private static float a(float fc) {
        return (float) (1 - Math.exp(-2 * Math.PI * fc / RATE));
    }

    private static float noise(Random r) {
        return r.nextFloat() * 2f - 1f;
    }

    private static float[] norm(float[] b, float peak) {
        float m = 1e-6f;
        for (float v : b) m = Math.max(m, Math.abs(v));
        float k = peak / m;
        int fade = Math.min(b.length / 4, 200);
        for (int i = 0; i < b.length; i++) {
            b[i] *= k;
            if (i >= b.length - fade) b[i] *= (b.length - i) / (float) fade;
        }
        return b;
    }

    private static void writeWav(File f, float[] s) throws IOException {
        int n = s.length;
        byte[] d = new byte[44 + n * 2];
        put(d, 0, "RIFF");
        int32(d, 4, 36 + n * 2);
        put(d, 8, "WAVEfmt ");
        int32(d, 16, 16);
        int16(d, 20, 1);
        int16(d, 22, 1);
        int32(d, 24, RATE);
        int32(d, 28, RATE * 2);
        int16(d, 32, 2);
        int16(d, 34, 16);
        put(d, 36, "data");
        int32(d, 40, n * 2);
        for (int i = 0; i < n; i++) {
            int v = (int) (Math.max(-1f, Math.min(1f, s[i])) * 32767);
            d[44 + i * 2] = (byte) v;
            d[45 + i * 2] = (byte) (v >> 8);
        }
        File tmp = new File(f.getPath() + ".tmp");
        FileOutputStream o = new FileOutputStream(tmp);
        try {
            o.write(d);
        } finally {
            o.close();
        }
        if (!tmp.renameTo(f)) throw new IOException("rename");
    }

    private static void put(byte[] d, int o, String s) {
        for (int i = 0; i < s.length(); i++) d[o + i] = (byte) s.charAt(i);
    }

    private static void int32(byte[] d, int o, int v) {
        d[o] = (byte) v; d[o + 1] = (byte) (v >> 8); d[o + 2] = (byte) (v >> 16); d[o + 3] = (byte) (v >> 24);
    }

    private static void int16(byte[] d, int o, int v) {
        d[o] = (byte) v; d[o + 1] = (byte) (v >> 8);
    }
}
