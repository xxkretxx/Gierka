package com.slingsmash.game;

import android.content.res.AssetManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;

import java.io.InputStream;
import java.util.HashMap;

/** Pre-rendered 3D sprites (baked offline by tools3d). */
final class Sprites {
    private Sprites() {}

    private static final HashMap<String, Bitmap> BMP = new HashMap<>();
    private static final HashMap<String, float[]> RECT = new HashMap<>();
    private static final Paint PAINT = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG);
    private static final RectF DST = new RectF();

    static void load(AssetManager am) {
        for (int i = 0; i < SpriteData.NAMES.length; i++) {
            String n = SpriteData.NAMES[i];
            RECT.put(n, SpriteData.RECT[i]);
            try {
                InputStream in = am.open("spr/" + n + ".png");
                Bitmap b = BitmapFactory.decodeStream(in);
                in.close();
                if (b != null) BMP.put(n, b);
            } catch (Exception ignored) {
            }
        }
    }

    static boolean has(String n) {
        return BMP.containsKey(n);
    }

    static float[] rect(String n) {
        return RECT.get(n);
    }

    /** Draws a sprite in a y-up world canvas at its natural metric size, centred on the model origin. */
    static boolean drawWorld(Canvas c, String n, float scale, int alpha) {
        Bitmap b = BMP.get(n);
        if (b == null) return false;
        float[] r = RECT.get(n);
        c.save();
        c.scale(scale, -scale);
        DST.set(r[0], -r[3], r[1], -r[2]);
        PAINT.setAlpha(alpha);
        c.drawBitmap(b, null, DST, PAINT);
        c.restore();
        return true;
    }

    /** Draws a sprite in a y-down UI canvas so its model origin sits at (cx, cy), with given pixels per metre. */
    static boolean drawUi(Canvas c, String n, float cx, float cy, float ppm, int alpha) {
        Bitmap b = BMP.get(n);
        if (b == null) return false;
        float[] r = RECT.get(n);
        DST.set(cx + r[0] * ppm, cy - r[3] * ppm, cx + r[1] * ppm, cy - r[2] * ppm);
        PAINT.setAlpha(alpha);
        c.drawBitmap(b, null, DST, PAINT);
        return true;
    }

    /** Draws a sprite fitted (keeping aspect) into a box of given height, centred at (cx, cy) by its bounds. */
    static boolean drawFit(Canvas c, String n, float cx, float cy, float maxW, float maxH, int alpha) {
        Bitmap b = BMP.get(n);
        if (b == null) return false;
        float[] r = RECT.get(n);
        float w = r[1] - r[0], h = r[3] - r[2];
        float k = Math.min(maxW / w, maxH / h);
        DST.set(cx - w * k / 2, cy - h * k / 2, cx + w * k / 2, cy + h * k / 2);
        PAINT.setAlpha(alpha);
        c.drawBitmap(b, null, DST, PAINT);
        return true;
    }

    static float radius(String n) {
        float[] r = RECT.get(n);
        if (r == null) return 1;
        return Math.max(Math.max(-r[0], r[1]), Math.max(-r[2], r[3]));
    }
}
