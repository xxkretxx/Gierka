package com.slingsmash.game;

import android.graphics.Canvas;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RadialGradient;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.Typeface;

import java.util.ArrayList;

/** UI widgets drawn in "design space" (1600 x 720, matching the Figma file). */
final class Ui {
    static final int INK = 0xFF22123A;
    static final int[] GREEN = {0xFF5BE36A, 0xFF2FAE40, 0xFF1D7A2A};
    static final int[] ORANGE = {0xFFFFA45C, 0xFFFF7A3C, 0xFFB8471C};
    static final int[] BLUE = {0xFF8494FF, 0xFF5B6CFF, 0xFF3240B0};
    static final int[] YELLOW = {0xFFFFE780, 0xFFFFC93C, 0xFFB88600};
    static final int[] PURPLE = {0xFFB07CFF, 0xFF8A4DFF, 0xFF5A27B8};
    static final int[] RED = {0xFFFF7A6A, 0xFFF2443A, 0xFFA51E18};
    static final int[] GREY = {0xFF9A98B0, 0xFF6E6A8A, 0xFF45425E};

    static final int G_PAUSE = 1, G_BACK = 2, G_NEXT = 3, G_RESTART = 4, G_HOME = 5, G_GRID = 6, G_SOUND = 7, G_MUTE = 8,
            G_VIBE = 9, G_NOVIBE = 10, G_SHOP = 11, G_PLAY = 12, G_LOCK = 13,
            G_UNDO = 14, G_TRASH = 15, G_ERASE = 16, G_CAMERA = 17, G_CHECK = 18, G_HAMMER = 19;

    final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    final Paint ps = new Paint(Paint.ANTI_ALIAS_FLAG);
    final Paint tp = new Paint(Paint.ANTI_ALIAS_FLAG);
    final RectF rf = new RectF();
    final RectF rf2 = new RectF();
    final Path path = new Path();
    final ArrayList<float[]> hits = new ArrayList<>();
    int pressedId = -1;
    float pressedT;

    Ui(Typeface font) {
        tp.setTypeface(font);
        ps.setStyle(Paint.Style.STROKE);
        ps.setStrokeJoin(Paint.Join.ROUND);
        ps.setStrokeCap(Paint.Cap.ROUND);
    }

    void hit(int id, float l, float t, float r, float b) {
        hits.add(new float[]{id, l, t, r, b});
    }

    int find(float x, float y) {
        for (int i = hits.size() - 1; i >= 0; i--) {
            float[] h = hits.get(i);
            if (x >= h[1] && x <= h[3] && y >= h[2] && y <= h[4]) return (int) h[0];
        }
        return -1;
    }

    boolean pressed(int id) {
        return pressedId == id && pressedT > 0;
    }

    // ---------------------------------------------------------------- text

    float width(String s, float size) {
        tp.setTextSize(size);
        return tp.measureText(s);
    }

    /** Outlined text; y is the vertical centre of the cap height. */
    void text(Canvas c, String s, float x, float y, float size, int fill, float strokeW, Paint.Align align) {
        tp.setTextAlign(align);
        tp.setTextSize(size);
        float base = y + size * 0.36f;
        if (strokeW > 0) {
            tp.setStyle(Paint.Style.STROKE);
            tp.setStrokeWidth(strokeW * 2);
            tp.setStrokeJoin(Paint.Join.ROUND);
            tp.setColor(Defs.withAlpha(INK, fill >>> 24));
            c.drawText(s, x, base, tp);
        }
        tp.setStyle(Paint.Style.FILL);
        tp.setColor(fill);
        c.drawText(s, x, base, tp);
    }

    void textC(Canvas c, String s, float x, float y, float size, int fill, float strokeW) {
        text(c, s, x, y, size, fill, strokeW, Paint.Align.CENTER);
    }

    /** Big gradient title text with a coloured lip, like the logo. */
    void title(Canvas c, String s, float x, float y, float size, int top, int bottom, int lip) {
        tp.setTextAlign(Paint.Align.CENTER);
        tp.setTextSize(size);
        float base = y + size * 0.36f;
        tp.setStyle(Paint.Style.FILL);
        tp.setColor(0x66000000);
        c.drawText(s, x, base + size * 0.16f, tp);
        tp.setStyle(Paint.Style.STROKE);
        tp.setStrokeWidth(size * 0.12f);
        tp.setStrokeJoin(Paint.Join.ROUND);
        tp.setColor(lip);
        c.drawText(s, x, base + size * 0.07f, tp);
        tp.setColor(INK);
        c.drawText(s, x, base + size * 0.07f, tp);
        c.drawText(s, x, base, tp);
        tp.setStyle(Paint.Style.FILL);
        tp.setColor(lip);
        c.drawText(s, x, base + size * 0.07f, tp);
        tp.setShader(new LinearGradient(0, base - size * 0.72f, 0, base, top, bottom, Shader.TileMode.CLAMP));
        c.drawText(s, x, base, tp);
        tp.setShader(null);
    }

    // ---------------------------------------------------------------- buttons

    /** Chunky 3D button centred at (cx, cy). Returns its width. */
    float button(Canvas c, int id, float cx, float cy, String label, float size, int[] col, float minW) {
        float w = Math.max(minW, width(label, size) + size * 1.9f);
        float h = size * 1.2f + 32;
        rf.set(cx - w / 2, cy - h / 2, cx + w / 2, cy + h / 2);
        buttonRect(c, id, rf, label, size, col);
        return w;
    }

    void buttonRect(Canvas c, int id, RectF r, String label, float size, int[] col) {
        float s = pressed(id) ? 0.93f : 1f;
        c.save();
        c.scale(s, s, r.centerX(), r.centerY());
        drawBody(c, r, Math.min(26, r.height() * 0.32f), col);
        if (label != null) {
            tp.setTextAlign(Paint.Align.CENTER);
            tp.setTextSize(size);
            float base = r.centerY() - 2 + size * 0.36f;
            tp.setStyle(Paint.Style.STROKE);
            tp.setStrokeWidth(size * 0.24f);
            tp.setStrokeJoin(Paint.Join.ROUND);
            tp.setColor(INK);
            c.drawText(label, r.centerX(), base + 4, tp);
            c.drawText(label, r.centerX(), base, tp);
            tp.setStyle(Paint.Style.FILL);
            tp.setColor(col[2]);
            c.drawText(label, r.centerX(), base + 4, tp);
            tp.setColor(0xFFFFFFFF);
            c.drawText(label, r.centerX(), base, tp);
        }
        c.restore();
        hit(id, r.left, r.top, r.right, r.bottom + 10);
    }

    private void drawBody(Canvas c, RectF r, float rad, int[] col) {
        // drop shadow + lip
        rf2.set(r.left, r.top + 16, r.right, r.bottom + 16);
        p.setColor(0x55000000);
        c.drawRoundRect(rf2, rad, rad, p);
        rf2.set(r.left - 2.5f, r.top + 6.5f, r.right + 2.5f, r.bottom + 11.5f);
        p.setColor(INK);
        c.drawRoundRect(rf2, rad + 2, rad + 2, p);
        rf2.set(r.left, r.top + 9, r.right, r.bottom + 9);
        p.setColor(col[2]);
        c.drawRoundRect(rf2, rad, rad, p);
        // outline
        rf2.set(r.left - 4.5f, r.top - 4.5f, r.right + 4.5f, r.bottom + 4.5f);
        p.setColor(INK);
        c.drawRoundRect(rf2, rad + 4, rad + 4, p);
        p.setShader(new LinearGradient(0, r.top, 0, r.bottom, col[0], col[1], Shader.TileMode.CLAMP));
        c.drawRoundRect(r, rad, rad, p);
        p.setShader(null);
        // inner highlight + bottom shade
        p.setColor(0x66FFFFFF);
        rf2.set(r.left + rad * 0.45f, r.top + 4, r.right - rad * 0.45f, r.top + 4 + Math.min(10, r.height() * 0.14f));
        c.drawRoundRect(rf2, 5, 5, p);
        p.setColor(0x26000000);
        rf2.set(r.left + rad * 0.3f, r.bottom - Math.min(10, r.height() * 0.12f), r.right - rad * 0.3f, r.bottom - 2);
        c.drawRoundRect(rf2, 5, 5, p);
    }

    void iconButton(Canvas c, int id, float x, float y, float sz, int glyph, int[] col) {
        rf.set(x, y, x + sz, y + sz);
        float s = pressed(id) ? 0.92f : 1f;
        c.save();
        c.scale(s, s, rf.centerX(), rf.centerY());
        drawBody(c, rf, sz * 0.29f, col);
        glyph(c, glyph, rf.centerX(), rf.centerY() - 2, sz * 0.33f);
        c.restore();
        hit(id, x - 6, y - 6, x + sz + 6, y + sz + 14);
    }

    void glyph(Canvas c, int g, float x, float y, float s) {
        // shadow pass then white pass
        for (int pass = 0; pass < 2; pass++) {
            float oy = pass == 0 ? s * 0.12f : 0;
            int color = pass == 0 ? INK : 0xFFFFFFFF;
            p.setColor(color);
            ps.setColor(color);
            ps.setStrokeWidth(s * 0.36f);
            c.save();
            c.translate(0, oy);
            switch (g) {
                case G_PAUSE:
                    rf2.set(x - s * 0.62f, y - s * 0.8f, x - s * 0.14f, y + s * 0.8f);
                    c.drawRoundRect(rf2, s * 0.15f, s * 0.15f, p);
                    rf2.set(x + s * 0.14f, y - s * 0.8f, x + s * 0.62f, y + s * 0.8f);
                    c.drawRoundRect(rf2, s * 0.15f, s * 0.15f, p);
                    break;
                case G_BACK: case G_NEXT: {
                    float d = g == G_BACK ? 1 : -1;
                    path.reset();
                    path.moveTo(x + s * 0.35f * d, y - s * 0.75f);
                    path.lineTo(x - s * 0.4f * d, y);
                    path.lineTo(x + s * 0.35f * d, y + s * 0.75f);
                    c.drawPath(path, ps);
                    break;
                }
                case G_RESTART: {
                    // clockwise arc with an arrowhead at its end, pointing along the motion
                    float rr = s * 0.68f;
                    rf2.set(x - rr, y - rr, x + rr, y + rr);
                    path.reset();
                    path.addArc(rf2, -80, 300);
                    ps.setStrokeWidth(s * 0.3f + (pass == 0 ? s * 0.06f : 0));
                    c.drawPath(path, ps);
                    float ex = x + rr * (float) Math.cos(Math.toRadians(220)), ey = y + rr * (float) Math.sin(Math.toRadians(220));
                    // tangent for clockwise (screen) motion at angle a is (-sin a, cos a)
                    float tx = -(float) Math.sin(Math.toRadians(220)), ty = (float) Math.cos(Math.toRadians(220));
                    float nx = -ty, ny = tx, L = s * 0.55f, W2 = s * 0.42f;
                    path.reset();
                    path.moveTo(ex + tx * L, ey + ty * L);
                    path.lineTo(ex + nx * W2 - tx * 0.1f * s, ey + ny * W2 - ty * 0.1f * s);
                    path.lineTo(ex - nx * W2 - tx * 0.1f * s, ey - ny * W2 - ty * 0.1f * s);
                    path.close();
                    c.drawPath(path, p);
                    break;
                }
                case G_HOME:
                    path.reset();
                    path.moveTo(x - s * 0.85f, y);
                    path.lineTo(x, y - s * 0.8f);
                    path.lineTo(x + s * 0.85f, y);
                    path.lineTo(x + s * 0.6f, y);
                    path.lineTo(x + s * 0.6f, y + s * 0.75f);
                    path.lineTo(x - s * 0.6f, y + s * 0.75f);
                    path.lineTo(x - s * 0.6f, y);
                    path.close();
                    c.drawPath(path, p);
                    break;
                case G_GRID:
                    for (int i = 0; i < 2; i++)
                        for (int j = 0; j < 2; j++) {
                            float cx = x + (i - 0.5f) * s * 0.85f, cy = y + (j - 0.5f) * s * 0.85f;
                            rf2.set(cx - s * 0.33f, cy - s * 0.33f, cx + s * 0.33f, cy + s * 0.33f);
                            c.drawRoundRect(rf2, s * 0.12f, s * 0.12f, p);
                        }
                    break;
                case G_SOUND: case G_MUTE: {
                    path.reset();
                    path.moveTo(x - s * 0.95f, y - s * 0.32f);
                    path.lineTo(x - s * 0.5f, y - s * 0.32f);
                    path.lineTo(x - s * 0.05f, y - s * 0.8f);
                    path.lineTo(x - s * 0.05f, y + s * 0.8f);
                    path.lineTo(x - s * 0.5f, y + s * 0.32f);
                    path.lineTo(x - s * 0.95f, y + s * 0.32f);
                    path.close();
                    c.drawPath(path, p);
                    ps.setStrokeWidth(s * 0.22f);
                    if (g == G_SOUND) {
                        rf2.set(x - s * 0.3f, y - s * 0.55f, x + s * 0.6f, y + s * 0.55f);
                        c.drawArc(rf2, -55, 110, false, ps);
                        rf2.set(x - s * 0.3f, y - s * 0.95f, x + s * 1.0f, y + s * 0.95f);
                        c.drawArc(rf2, -50, 100, false, ps);
                    } else {
                        c.drawLine(x + s * 0.3f, y - s * 0.35f, x + s * 0.95f, y + s * 0.35f, ps);
                        c.drawLine(x + s * 0.95f, y - s * 0.35f, x + s * 0.3f, y + s * 0.35f, ps);
                    }
                    break;
                }
                case G_VIBE: case G_NOVIBE: {
                    rf2.set(x - s * 0.38f, y - s * 0.75f, x + s * 0.38f, y + s * 0.75f);
                    c.drawRoundRect(rf2, s * 0.15f, s * 0.15f, p);
                    ps.setStrokeWidth(s * 0.18f);
                    if (g == G_VIBE) {
                        c.drawLine(x - s * 0.7f, y - s * 0.4f, x - s * 0.7f, y + s * 0.4f, ps);
                        c.drawLine(x + s * 0.7f, y - s * 0.4f, x + s * 0.7f, y + s * 0.4f, ps);
                        c.drawLine(x - s * 0.98f, y - s * 0.22f, x - s * 0.98f, y + s * 0.22f, ps);
                        c.drawLine(x + s * 0.98f, y - s * 0.22f, x + s * 0.98f, y + s * 0.22f, ps);
                    } else {
                        ps.setStrokeWidth(s * 0.2f);
                        c.drawLine(x - s * 0.9f, y - s * 0.9f, x + s * 0.9f, y + s * 0.9f, ps);
                    }
                    break;
                }
                case G_SHOP:
                    path.reset();
                    path.moveTo(x - s * 0.8f, y - s * 0.3f);
                    path.lineTo(x + s * 0.8f, y - s * 0.3f);
                    path.lineTo(x + s * 0.62f, y + s * 0.8f);
                    path.lineTo(x - s * 0.62f, y + s * 0.8f);
                    path.close();
                    c.drawPath(path, p);
                    ps.setStrokeWidth(s * 0.2f);
                    rf2.set(x - s * 0.42f, y - s * 0.95f, x + s * 0.42f, y - 0.05f * s);
                    c.drawArc(rf2, 180, 180, false, ps);
                    break;
                case G_PLAY:
                    path.reset();
                    path.moveTo(x - s * 0.45f, y - s * 0.8f);
                    path.lineTo(x + s * 0.75f, y);
                    path.lineTo(x - s * 0.45f, y + s * 0.8f);
                    path.close();
                    c.drawPath(path, p);
                    break;
                case G_UNDO: {
                    float rr = s * 0.62f;
                    rf2.set(x - rr, y - rr * 0.8f, x + rr, y + rr * 1.2f);
                    path.reset();
                    path.addArc(rf2, 200, 250);
                    ps.setStrokeWidth(s * 0.3f + (pass == 0 ? s * 0.06f : 0));
                    c.drawPath(path, ps);
                    float ex = x + rr * (float) Math.cos(Math.toRadians(200)), ey = y + rr * 0.2f + rr * (float) Math.sin(Math.toRadians(200));
                    path.reset();
                    path.moveTo(ex - s * 0.5f, ey - s * 0.05f);
                    path.lineTo(ex + s * 0.25f, ey - s * 0.45f);
                    path.lineTo(ex + s * 0.25f, ey + s * 0.35f);
                    path.close();
                    c.drawPath(path, p);
                    break;
                }
                case G_TRASH:
                    rf2.set(x - s * 0.55f, y - s * 0.4f, x + s * 0.55f, y + s * 0.85f);
                    c.drawRoundRect(rf2, s * 0.12f, s * 0.12f, p);
                    rf2.set(x - s * 0.8f, y - s * 0.72f, x + s * 0.8f, y - s * 0.5f);
                    c.drawRoundRect(rf2, s * 0.08f, s * 0.08f, p);
                    rf2.set(x - s * 0.25f, y - s * 0.92f, x + s * 0.25f, y - s * 0.65f);
                    c.drawRoundRect(rf2, s * 0.08f, s * 0.08f, p);
                    break;
                case G_ERASE:
                    c.save();
                    c.rotate(-35, x, y);
                    rf2.set(x - s * 0.9f, y - s * 0.4f, x + s * 0.9f, y + s * 0.4f);
                    c.drawRoundRect(rf2, s * 0.15f, s * 0.15f, p);
                    if (pass == 1) {
                        p.setColor(0xFFFF7A9A);
                        rf2.set(x - s * 0.9f, y - s * 0.4f, x - s * 0.15f, y + s * 0.4f);
                        c.drawRoundRect(rf2, s * 0.15f, s * 0.15f, p);
                    }
                    c.restore();
                    break;
                case G_CAMERA:
                    rf2.set(x - s * 0.9f, y - s * 0.5f, x + s * 0.45f, y + s * 0.6f);
                    c.drawRoundRect(rf2, s * 0.18f, s * 0.18f, p);
                    path.reset();
                    path.moveTo(x + s * 0.5f, y + s * 0.05f);
                    path.lineTo(x + s * 0.95f, y - s * 0.4f);
                    path.lineTo(x + s * 0.95f, y + s * 0.5f);
                    path.close();
                    c.drawPath(path, p);
                    break;
                case G_CHECK:
                    path.reset();
                    path.moveTo(x - s * 0.7f, y);
                    path.lineTo(x - s * 0.15f, y + s * 0.55f);
                    path.lineTo(x + s * 0.75f, y - s * 0.6f);
                    c.drawPath(path, ps);
                    break;
                case G_HAMMER:
                    c.save();
                    c.rotate(-40, x, y);
                    rf2.set(x - s * 0.13f, y - s * 0.3f, x + s * 0.13f, y + s * 0.95f);
                    c.drawRoundRect(rf2, s * 0.1f, s * 0.1f, p);
                    rf2.set(x - s * 0.65f, y - s * 0.75f, x + s * 0.65f, y - s * 0.25f);
                    c.drawRoundRect(rf2, s * 0.12f, s * 0.12f, p);
                    c.restore();
                    break;
                case G_LOCK:
                    rf2.set(x - s * 0.62f, y - s * 0.1f, x + s * 0.62f, y + s * 0.8f);
                    p.setColor(pass == 0 ? INK : 0xFFFFD23F);
                    c.drawRoundRect(rf2, s * 0.15f, s * 0.15f, p);
                    ps.setColor(pass == 0 ? INK : 0xFFFFD23F);
                    ps.setStrokeWidth(s * 0.22f);
                    rf2.set(x - s * 0.38f, y - s * 0.75f, x + s * 0.38f, y + s * 0.1f);
                    c.drawArc(rf2, 180, 180, false, ps);
                    break;
            }
            c.restore();
        }
    }

    // ---------------------------------------------------------------- stars, coins, pills

    void star(Canvas c, float x, float y, float r, boolean filled, float scale, float rot) {
        if (scale <= 0.01f) return;
        path.reset();
        float ro = r * scale, ri = ro * 0.5f;
        for (int i = 0; i < 10; i++) {
            double a = -Math.PI / 2 + i * Math.PI / 5 + Math.toRadians(rot);
            float rr = i % 2 == 0 ? ro : ri;
            float px = x + (float) Math.cos(a) * rr, py = y + (float) Math.sin(a) * rr;
            if (i == 0) path.moveTo(px, py);
            else path.lineTo(px, py);
        }
        path.close();
        ps.setStrokeWidth(ro * 0.2f);
        ps.setColor(filled ? 0xFF7A3E00 : INK);
        c.drawPath(path, ps);
        if (filled) {
            p.setShader(new LinearGradient(0, y - ro, 0, y + ro, 0xFFFFF39A, 0xFFFFB31F, Shader.TileMode.CLAMP));
            c.drawPath(path, p);
            p.setShader(null);
            p.setColor(0x80FFFFFF);
            c.save();
            c.clipPath(path);
            c.drawCircle(x - ro * 0.2f, y - ro * 0.55f, ro * 0.45f, p);
            c.restore();
        } else {
            p.setColor(0x38FFFFFF);
            c.drawPath(path, p);
        }
    }

    void coin(Canvas c, float x, float y, float r) {
        p.setShader(new LinearGradient(0, y - r, 0, y + r, 0xFFFFE36B, 0xFFF2A100, Shader.TileMode.CLAMP));
        c.drawCircle(x, y, r, p);
        p.setShader(null);
        ps.setColor(0xFF7A3E00);
        ps.setStrokeWidth(r * 0.15f);
        c.drawCircle(x, y, r, ps);
        ps.setColor(0xFFC77B00);
        ps.setStrokeWidth(r * 0.14f);
        c.drawCircle(x, y, r * 0.6f, ps);
        p.setColor(0xFFC77B00);
        rf2.set(x - r * 0.14f, y - r * 0.33f, x + r * 0.14f, y + r * 0.33f);
        c.drawRoundRect(rf2, r * 0.1f, r * 0.1f, p);
    }

    /** Dark pill with a coin (icon=0) or star (icon=1). Anchored at the right edge if alignRight. Returns width. */
    float pill(Canvas c, float x, float y, int icon, String s, int textColor, boolean alignRight) {
        float h = 64, tw = width(s, 34);
        float w = 8 + 52 + 10 + tw + 24;
        float l = alignRight ? x - w : x;
        rf.set(l, y, l + w, y + h);
        p.setColor(0xB8120B2A);
        c.drawRoundRect(rf, h / 2, h / 2, p);
        ps.setColor(0x40FFFFFF);
        ps.setStrokeWidth(3);
        c.drawRoundRect(rf, h / 2, h / 2, ps);
        if (icon == 0) coin(c, l + 8 + 26, y + h / 2, 24);
        else star(c, l + 8 + 26, y + h / 2, 24, true, 1f, 0);
        text(c, s, l + 70, y + h / 2, 34, textColor, 4, Paint.Align.LEFT);
        return w;
    }

    // ---------------------------------------------------------------- panels

    void scrim(Canvas c, float l, float t, float r, float b, int alpha) {
        p.setColor(Defs.withAlpha(0xFF07051A, alpha));
        c.drawRect(l, t, r, b, p);
    }

    /** Purple panel with ribbon title. (cx, top) = centre x and top of panel. */
    void panel(Canvas c, float cx, float top, float w, float h, String title, int[] ribbon) {
        float l = cx - w / 2;
        rf.set(l, top + 16, l + w, top + h + 16);
        p.setColor(0x80000000);
        c.drawRoundRect(rf, 40, 40, p);
        rf.set(l - 7, top - 7, l + w + 7, top + h + 7);
        p.setColor(INK);
        c.drawRoundRect(rf, 46, 46, p);
        rf.set(l, top, l + w, top + h);
        p.setShader(new LinearGradient(0, top, 0, top + h, 0xFF3A2A78, 0xFF231850, Shader.TileMode.CLAMP));
        c.drawRoundRect(rf, 40, 40, p);
        p.setShader(null);
        p.setColor(0x33FFFFFF);
        rf2.set(l + 30, top + 6, l + w - 30, top + 14);
        c.drawRoundRect(rf2, 4, 4, p);
        if (title != null) {
            float rw = w * 0.8f;
            rf.set(cx - rw / 2, top - 46, cx + rw / 2, top + 46);
            drawBody(c, rf, 26, new int[]{Defs.shade(ribbon[1], 1.3f), ribbon[1], ribbon[2]});
            textC(c, title, cx, top - 2, 58, 0xFFFFFFFF, 6);
        }
    }

    void meter(Canvas c, float x, float y, float w, float frac, float[] th) {
        float h = 34;
        rf.set(x, y, x + w, y + h);
        p.setColor(0xD9120B2A);
        c.drawRoundRect(rf, h / 2, h / 2, p);
        ps.setColor(0x4DFFFFFF);
        ps.setStrokeWidth(3);
        c.drawRoundRect(rf, h / 2, h / 2, ps);
        if (frac > 0.003f) {
            float fw = Math.max(24, (w - 10) * frac);
            rf.set(x + 5, y + 5, x + 5 + fw, y + h - 5);
            p.setShader(new LinearGradient(x, 0, x + w, 0, 0xFFFFD23F, 0xFFFF4B2B, Shader.TileMode.CLAMP));
            c.drawRoundRect(rf, 12, 12, p);
            p.setShader(null);
            p.setColor(0x80FFFFFF);
            rf.set(x + 12, y + 8, x + fw - 2, y + 13);
            if (rf.width() > 4) c.drawRoundRect(rf, 3, 3, p);
        }
        for (float t : th) star(c, x + w * t, y + h / 2, 25, frac >= t, frac >= t ? 1.06f : 1f, 0);
    }

    /** Circular ammo slot. state: 0 default, 1 selected, 2 locked. */
    void ammoSlot(Canvas c, float cx, float cy, float r, int state, int type, Art art, float bob) {
        p.setColor(0x59000000);
        c.drawCircle(cx, cy + 6, r, p);
        p.setColor(INK);
        c.drawCircle(cx, cy, r + 5, p);
        p.setShader(state == 1 ? new LinearGradient(0, cy - r, 0, cy + r, 0xFFFFE780, 0xFFFFB31F, Shader.TileMode.CLAMP)
                : new LinearGradient(0, cy - r, 0, cy + r, 0xFF4A3D86, 0xFF2B2150, Shader.TileMode.CLAMP));
        c.drawCircle(cx, cy, r, p);
        p.setShader(null);
        p.setColor(state == 1 ? 0xFFFFF6D6 : 0xFF3F3470);
        c.drawCircle(cx, cy, r * 0.81f, p);
        p.setColor(0x30000000);
        c.drawCircle(cx, cy + r * 0.05f, r * 0.78f, p);
        p.setColor(state == 1 ? 0xFFFFF6D6 : 0xFF3F3470);
        c.drawCircle(cx, cy - r * 0.02f, r * 0.76f, p);
        float br = ammoRadius(type);
        float k = r * 0.58f / br;
        c.save();
        c.translate(cx, cy + bob);
        c.scale(k, -k);
        if (state == 2) {
            c.saveLayerAlpha(-br * 1.5f, -br * 1.5f, br * 1.5f, br * 1.5f, 70);
            art.drawAmmo(c, type);
            c.restore();
        } else art.drawAmmo(c, type);
        c.restore();
        if (state == 2) glyph(c, G_LOCK, cx + r * 0.1f, cy + r * 0.05f, r * 0.42f);
    }

    static float ammoRadius(int t) {
        float[] s = Defs.AMMO_SIZE[t];
        if (t == Defs.A_HOLE) return s[0] * 1.6f;
        if (t == Defs.A_BUS) return 2.2f;
        if (Defs.AMMO_SHAPE[t] == Defs.SH_BOX) return (float) Math.hypot(s[0], s[1]) * 0.92f;
        return s[0];
    }

    void glow(Canvas c, float x, float y, float r, int color) {
        p.setShader(new RadialGradient(x, y, r, color, color & 0x00FFFFFF, Shader.TileMode.CLAMP));
        c.drawCircle(x, y, r, p);
        p.setShader(null);
    }
}
