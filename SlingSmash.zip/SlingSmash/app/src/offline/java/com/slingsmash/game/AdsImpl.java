package com.slingsmash.game;

import android.app.Activity;

/** Build without an ad SDK: no videos, the game uses its own short wait timer instead. */
final class AdsImpl {
    private AdsImpl() {}

    static Ads create(Activity a) {
        return null;
    }
}
